#ifndef __DAZ_FMC_BLOCK_IO_H__
#define __DAZ_FMC_BLOCK_IO_H__

#include "../data_type.h"
#include "data_type.h"
#include "main.h"

void input_block(int src_x, int src_y, int blk_w, int blk_h,
    uint8 *Rin, uint8 *Gin, uint8 *Bin, FrameInfo *SrcFrame);

void output_block(int src_x, int src_y, int blk_w, int blk_h,
    uint8 *Rout, uint8 *Gout, uint8 *Bout, FrameInfo *TgtFrame);


#endif
