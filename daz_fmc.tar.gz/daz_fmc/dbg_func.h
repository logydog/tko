#ifndef __DAZ_FMC_DBG_FUNC_H__
#define __DAZ_FMC_DBG_FUNC_H__

#include "data_type.h"
#include "main.h"

void save_cfg_file(FrameInfo *SrcFrame, char *fname);
void save_raw_file(FrameInfo *SrcFrame, char *fname);
void dbg_print_pixel_data(void);
void dbg_dec_out_check(void);

void save_bstream_file_open(int8 *fname);
void save_bstream_file_close(void);
void save_bstream_file(uint8 *w_data, uint8 byte_cnt);

#endif
