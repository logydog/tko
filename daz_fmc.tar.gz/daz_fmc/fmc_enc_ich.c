/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

static uint8 R_enc_ich_buf[ICH_BUF_SIZE_Y][ICH_BUF_SIZE_X];
static uint8 G_enc_ich_buf[ICH_BUF_SIZE_Y][ICH_BUF_SIZE_X];
static uint8 B_enc_ich_buf[ICH_BUF_SIZE_Y][ICH_BUF_SIZE_X];


static uint8 pdec_ich_cand_R[8][BLK_SIZE];
static uint8 pdec_ich_cand_G[8][BLK_SIZE];
static uint8 pdec_ich_cand_B[8][BLK_SIZE];

static uint8 R_resd_enc_2x2[8][BLK_SIZE];
static uint8 G_resd_enc_2x2[8][BLK_SIZE];
static uint8 B_resd_enc_2x2[8][BLK_SIZE];

static uint8 R_pred_2x2[BLK_SIZE];
static uint8 G_pred_2x2[BLK_SIZE];
static uint8 B_pred_2x2[BLK_SIZE];

static uint8 R_abs_resd_2x2[BLK_SIZE];
static uint8 G_abs_resd_2x2[BLK_SIZE];
static uint8 B_abs_resd_2x2[BLK_SIZE];

static uint8 R_sign_resd_2x2[BLK_SIZE];
static uint8 G_sign_resd_2x2[BLK_SIZE];
static uint8 B_sign_resd_2x2[BLK_SIZE];

int8 dec_resd[4][4] =
{
	{0,  2,  4, -4},
	{0,  4,  8, -8},
	{0,  8, 16, -16},
	{0, 16, 32, -32}
};

uint8 fmc_dec_resd(uint8 enc_mode, uint8 enc_code, uint8 dec_pred)
{
	uint8 dec_out_8b;
	int16 dec_out_10b = (int16) dec_pred;

	dec_out_10b += dec_resd[enc_mode][enc_code];

	if(dec_out_10b > 255)
		dec_out_10b = 255;
	if(dec_out_10b < 0)
		dec_out_10b = 0;
	dec_out_8b = (uint8) dec_out_10b;

	return dec_out_8b;
}

void fmc_dec_ich(uint8 enc_mode, uint8 enc_idx, uint8 *enc_r, uint8 *enc_g, uint8 *enc_b,
				uint8 (*ich_buf_r)[ICH_BUF_SIZE_X], uint8 (*ich_buf_g)[ICH_BUF_SIZE_X], uint8 (*ich_buf_b)[ICH_BUF_SIZE_X],
				uint8 *dec_r, uint8 *dec_g, uint8 *dec_b)
{
    int i;
	dec_r[0] = ich_buf_r[0][enc_idx];
	dec_r[1] = ich_buf_r[0][enc_idx+1];
	dec_r[2] = ich_buf_r[1][enc_idx];
	dec_r[3] = ich_buf_r[1][enc_idx+1];

	dec_g[0] = ich_buf_g[0][enc_idx];
	dec_g[1] = ich_buf_g[0][enc_idx+1];
	dec_g[2] = ich_buf_g[1][enc_idx];
	dec_g[3] = ich_buf_g[1][enc_idx+1];

	dec_b[0] = ich_buf_b[0][enc_idx];
	dec_b[1] = ich_buf_b[0][enc_idx+1];
	dec_b[2] = ich_buf_b[1][enc_idx];
	dec_b[3] = ich_buf_b[1][enc_idx+1];

	for(i=0; i<BLK_SIZE; i++)
	{
		dec_r[i] = fmc_dec_resd(enc_mode, enc_r[i], dec_r[i]);
		dec_g[i] = fmc_dec_resd(enc_mode, enc_g[i], dec_g[i]);
		dec_b[i] = fmc_dec_resd(enc_mode, enc_b[i], dec_b[i]);
	}
}

void update_ich_buf(bool slice_start,
					uint8 (*R_buf)[ICH_BUF_SIZE_X], uint8 (*G_buf)[ICH_BUF_SIZE_X], uint8 (*B_buf)[ICH_BUF_SIZE_X],
					uint8 *R_prev_dec, uint8 *G_prev_dec, uint8 *B_prev_dec)
{
	int i, j;

	if(slice_start)
	{
		for(j=0; j<ICH_BUF_SIZE_Y; j++)
			for(i=0; i<ICH_BUF_SIZE_X; i++)
			{
				R_buf[j][i] = 0;
				G_buf[j][i] = 0;
				B_buf[j][i] = 0;
			}
	}
	else
	{
		copy_block(1, R_buf[0], R_buf[0]+2);
		copy_block(1, G_buf[0], G_buf[0]+2);
		copy_block(1, B_buf[0], B_buf[0]+2);

		copy_block(1, R_buf[1], R_buf[1]+2);
		copy_block(1, G_buf[1], G_buf[1]+2);
		copy_block(1, B_buf[1], B_buf[1]+2);

		for(i=1; i<6; i+=2)
		{
			copy_block(2, R_buf[0]+i, R_buf[0]+i+2);
			copy_block(2, G_buf[0]+i, G_buf[0]+i+2);
			copy_block(2, B_buf[0]+i, B_buf[0]+i+2);

			copy_block(2, R_buf[1]+i, R_buf[1]+i+2);
			copy_block(2, G_buf[1]+i, G_buf[1]+i+2);
			copy_block(2, B_buf[1]+i, B_buf[1]+i+2);
		}

		copy_block(2, R_buf[0]+7, R_prev_dec);
		copy_block(2, G_buf[0]+7, G_prev_dec);
		copy_block(2, B_buf[0]+7, B_prev_dec);

		copy_block(2, R_buf[1]+7, R_prev_dec+2);
		copy_block(2, G_buf[1]+7, G_prev_dec+2);
		copy_block(2, B_buf[1]+7, B_prev_dec+2);
	}
}

void ich_enc_pred(uint8 ich_idx, uint8 *pred2x2, uint8 (*ich_buf)[ICH_BUF_SIZE_X])
{
	pred2x2[0] = ich_buf[0][ich_idx];
	pred2x2[1] = ich_buf[0][ich_idx+1];
	pred2x2[2] = ich_buf[1][ich_idx];
	pred2x2[3] = ich_buf[1][ich_idx+1];
}

uint8 ich_enc_resd_coding(uint8 coding_mode, uint8 resd_abs, uint8 resd_sign, uint8 min_abs_resd)
{
	uint8 code;
	uint8 code0, code1;

	if(coding_mode == 0)
	{
		code0 = (resd_abs > 3) ? 2 :
				(resd_abs > 1) ? 1 : 0;
		code1 = (resd_abs > 1) ? 3 : 0;
	}
	else if(coding_mode == 1)
	{
		code0 = (resd_abs > 5) ? 2 :
				(resd_abs > 1) ? 1 : 0;
		code1 = (resd_abs > 3) ? 3 : 0;
	}
	else if(coding_mode == 2)
	{
		code0 = (resd_abs > 11) ? 2 :
				(resd_abs >  3) ? 1 : 0;
		code1 = (resd_abs >  7) ? 3 : 0;
	}
	else
	{
		code0 = (resd_abs > 23) ? 2 :
				(resd_abs >  7) ? 1 : 0;
		code1 = (resd_abs > 15) ? 3 : 0;
	}

	code = resd_sign ? code1: code0;

	return code;
}

void ich_enc_get_resd_value(uint8 *Vin2x2, uint8 *Vpred2x2, uint8 *Vresd_abs_2x2, uint8 *Vresd_sign_2x2)
{
	int i;
	for(i=0; i<BLK_SIZE; i++)
	{
		Vresd_abs_2x2[i] = get_abs_diff(Vin2x2[i], Vpred2x2[i]);
#if 1
		if(Vresd_abs_2x2[i] > 63)
			Vresd_abs_2x2[i] = 63;
#endif
		Vresd_sign_2x2[i] = (Vin2x2[i] < Vpred2x2[i]) ? 1 : 0;
	}
}

void ich_enc_get_resd_min_max(uint8 *Vresd_abs_2x2, uint8 *max_abs_resd, uint8 *min_abs_resd)
{
	int i;
	uint8 abs_resd;
	for(i=0; i<BLK_SIZE; i++)
	{
		abs_resd = Vresd_abs_2x2[i];

		if(abs_resd > *max_abs_resd)
			*max_abs_resd = abs_resd;

		if(abs_resd < *min_abs_resd)
			*min_abs_resd = abs_resd;
	}

}

uint8 ich_enc_get_resd_coding_mode(uint8 max_abs_resd)
{
	uint8 resd_coding_mode;

	if(max_abs_resd <= 6)
		resd_coding_mode = 0;
	else if(max_abs_resd <= 12)
		resd_coding_mode = 1;
	else if(max_abs_resd <= 24)
		resd_coding_mode = 2;
	else
		resd_coding_mode = 3;

	return resd_coding_mode;
}

uint8 fmc_enc_ich(uint8 ich_idx, int *diff_sum)
{
	int i;
	uint8 max_abs_resd = 0;
	uint8 min_abs_resd = 255;
	uint8 resd_mode;

	ich_enc_pred(ich_idx, R_pred_2x2, R_enc_ich_buf);
	ich_enc_pred(ich_idx, G_pred_2x2, G_enc_ich_buf);
	ich_enc_pred(ich_idx, B_pred_2x2, B_enc_ich_buf);

	ich_enc_get_resd_value(Rin2x2, R_pred_2x2, R_abs_resd_2x2, R_sign_resd_2x2);
	ich_enc_get_resd_value(Gin2x2, G_pred_2x2, G_abs_resd_2x2, G_sign_resd_2x2);
	ich_enc_get_resd_value(Bin2x2, B_pred_2x2, B_abs_resd_2x2, B_sign_resd_2x2);

	ich_enc_get_resd_min_max(R_abs_resd_2x2, &max_abs_resd, &min_abs_resd);
	ich_enc_get_resd_min_max(G_abs_resd_2x2, &max_abs_resd, &min_abs_resd);
	ich_enc_get_resd_min_max(B_abs_resd_2x2, &max_abs_resd, &min_abs_resd);

	resd_mode = ich_enc_get_resd_coding_mode(max_abs_resd);

	for(i=0; i<BLK_SIZE; i++)
	{
		R_resd_enc_2x2[ich_idx][i] = ich_enc_resd_coding(resd_mode, R_abs_resd_2x2[i], R_sign_resd_2x2[i], min_abs_resd);
		G_resd_enc_2x2[ich_idx][i] = ich_enc_resd_coding(resd_mode, G_abs_resd_2x2[i], G_sign_resd_2x2[i], min_abs_resd);
		B_resd_enc_2x2[ich_idx][i] = ich_enc_resd_coding(resd_mode, B_abs_resd_2x2[i], B_sign_resd_2x2[i], min_abs_resd);
	}

    fmc_dec_ich(resd_mode, ich_idx, R_resd_enc_2x2[ich_idx], G_resd_enc_2x2[ich_idx], B_resd_enc_2x2[ich_idx],
    			R_enc_ich_buf, G_enc_ich_buf, B_enc_ich_buf,
    			pdec_ich_cand_R[ich_idx], pdec_ich_cand_G[ich_idx], pdec_ich_cand_B[ich_idx]);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2,
    				pdec_ich_cand_R[ich_idx], pdec_ich_cand_G[ich_idx], pdec_ich_cand_B[ich_idx], diff_sum);

	return resd_mode;
}

uint8 fmc_ich_enc_dec_top(bool slice_start, int *diff_sum)
{
    int i;
	const int HST_N = 4;

    int df_sum[HST_N];
	uint8 mode[HST_N];

	update_ich_buf(slice_start,	R_enc_ich_buf, G_enc_ich_buf, B_enc_ich_buf,
					pdec_R, pdec_G, pdec_B);

	for(i=0; i<HST_N; i++)
    	mode[i] = fmc_enc_ich(i, df_sum+i);
    enc_ich_idx = get_min_idx_i32(HST_N, df_sum);
    enc_ich_mode = mode[enc_ich_idx];

    *diff_sum = df_sum[enc_ich_idx];

    copy_block(BLK_SIZE, enc_ich_R, R_resd_enc_2x2[enc_ich_idx]);
    copy_block(BLK_SIZE, enc_ich_G, G_resd_enc_2x2[enc_ich_idx]);
    copy_block(BLK_SIZE, enc_ich_B, B_resd_enc_2x2[enc_ich_idx]);

    copy_block(BLK_SIZE, pdec_ich_R, pdec_ich_cand_R[enc_ich_idx]);
    copy_block(BLK_SIZE, pdec_ich_G, pdec_ich_cand_G[enc_ich_idx]);
    copy_block(BLK_SIZE, pdec_ich_B, pdec_ich_cand_B[enc_ich_idx]);

    return (FMC_ENC_MODE_ICH0+enc_ich_idx);
}
