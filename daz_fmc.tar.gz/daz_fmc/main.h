
#ifndef __DAZZO_CMODEL_MAIN_H__
#define __DAZZO_CMODEL_MAIN_H__

#include "data_type.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifdef WIN32
#include <direct.h>
#endif
#include <errno.h>

#define Disable 0
#define Enable  1

#define T_Y_U_V	0
#define T_YUV		1
#define T_BMP		2

#define CHROMA420 1
#define CHROMA422 2
#define CHROMA444 3

#define T_FIELD 1
#define B_FIELD 2
#define FRAME 3

#define PIXEL_BITS 0


#ifdef __cplusplus
extern "C" {
#endif

typedef struct SourceInfo {
  char FileName[100];
  char VcHdFileName[100];
  unsigned int InType;
  int frame0;
  int nframes;
  int frame_w;
  int frame_h;
  unsigned int DisplayMode;
  int Size_Y;
  int Size_UV;
}SourceInfo;

typedef struct TargetInfo {
  char FileName[100];
  unsigned int OutType;
  int frame_w;
  int frame_h;
  int Size_Y;
  int Size_UV;
}TargetInfo;


typedef struct FrameInfo {
  int frame_w;
  int frame_h;
  unsigned int DisplayMode;
  int *y_data;
  int *u_data;
  int *v_data;
}FrameInfo;


extern SourceInfo SrcInfo;
extern TargetInfo TgtInfo;
extern FrameInfo SrcFrame;
extern FrameInfo TgtFrame;
extern FrameInfo OsdFrame;
extern char errortext[256];

extern void error(char *);
extern void * zero_malloc(size_t );
extern int init_FrameInfo(FrameInfo *, int );
extern void free_FrameInfo(FrameInfo *);
extern void frame_copy(FrameInfo*, FrameInfo*);

extern void ReadSourceFrame(int, FrameInfo *);
extern int WriteTargetFrame(int, int, char *, unsigned int, FrameInfo *);

typedef struct tagBmpFileHeader
{
	WORD bfType;
	DWORD bfSize;
	DWORD bfReserved;
	DWORD bfOffBits;
}tagBmpFileHeader;


typedef struct tagBmpInfoHeader
{
	DWORD biSize;
	DWORD biWidth;
	DWORD biHeight;
	WORD  biPlanes;
	WORD  biBitCount;
	DWORD biCompression;
	DWORD biSizeImage;
	DWORD biX;
	DWORD biY;
	DWORD biClrUsed;
	DWORD biClrImportant;
}tagBmpInfoHeader;


typedef struct BmpInfo {
    char			    FileName[256];
    tagBmpFileHeader    FileHeader;
    tagBmpInfoHeader    InfoHeader;
    int	    *data;
}BmpInfo;

void readparmfile (char * fname);

#ifdef __cplusplus
}
#endif


#endif
