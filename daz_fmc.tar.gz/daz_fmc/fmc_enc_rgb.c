/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

static uint8 pdec_rgb1_R[BLK_SIZE];
static uint8 pdec_rgb1_G[BLK_SIZE];
static uint8 pdec_rgb1_B[BLK_SIZE];

static uint8 pdec_rgb2_R[BLK_SIZE];
static uint8 pdec_rgb2_G[BLK_SIZE];
static uint8 pdec_rgb2_B[BLK_SIZE];

static uint8 pdec_rgb3_R[BLK_SIZE];
static uint8 pdec_rgb3_G[BLK_SIZE];
static uint8 pdec_rgb3_B[BLK_SIZE];

static uint8 pdec_rgb4_R[BLK_SIZE];
static uint8 pdec_rgb4_G[BLK_SIZE];
static uint8 pdec_rgb4_B[BLK_SIZE];

void fmc_dec_rgb1(uint8 *enc_data, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b)
{
    int i;
    for(i=0; i<BLK_SIZE; i++)
    {
        dec_r[i] = enc_data[0];
        dec_g[i] = enc_data[1];
        dec_b[i] = enc_data[2];
    }
}

void fmc_enc_rgb1(int *diff_sum)
{
    enc_rgb1[0] = R_mean;
    enc_rgb1[1] = G_mean;
    enc_rgb1[2] = B_mean;
    fmc_dec_rgb1(enc_rgb1, pdec_rgb1_R, pdec_rgb1_G, pdec_rgb1_B);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_rgb1_R, pdec_rgb1_G, pdec_rgb1_B, diff_sum);
}

void fmc_dec_rgb4(uint8 enc_qmode, uint8 *enc_data, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;

    for(i=0; i<4; i++)
    {
        dec_r[i] = round_dq(enc_data[i], rnb[i]);
        dec_g[i] = round_dq(enc_data[i+4], rnb[i+4]);
        dec_b[i] = round_dq(enc_data[i+8], rnb[i+8]);
    }


    for(i=0; i<4; i++)
    {
        switch(enc_qmode)
        {
            case 1:
                dec_r[i] += 192;
                dec_g[i] += 192;
                dec_b[i] += 192;
                break;
            case 3:
                dec_r[i] += 32;
                dec_g[i] += 32;
                dec_b[i] += 32;
                break;
            case 4:
                dec_r[i] += 64;
                dec_g[i] += 64;
                dec_b[i] += 64;
                break;
            case 5:
                dec_r[i] += 96;
                dec_g[i] += 96;
                dec_b[i] += 96;
                break;
            case 6:
                dec_r[i] += 128;
                dec_g[i] += 128;
                dec_b[i] += 128;
                break;
        }
    }
}

uint8 fmc_enc_rgb4(int *diff_sum)
{
    int i;

    enc_rgb4_qmode = (RGB_max < 64+24) ? 0 :
                     (RGB_min > 192-24) ? 1 :
                     (RGB_max < 128+16) ? 2 :
                     (RGB_min > 32-16 && RGB_max < 160+16) ? 3 :
                     (RGB_min > 64-16 && RGB_max < 192+16) ? 4 :
                     (RGB_min > 96-16 && RGB_max < 224+16) ? 5 :
                     (RGB_min > 128-16) ? 6 : 7;
    uint8 rgb_in[12];

    for(i=0; i<4; i++)
    {
        rgb_in[i] = Rin2x2[i];
        rgb_in[i+4] = Gin2x2[i];
        rgb_in[i+8] = Bin2x2[i];
    }

    uint8 rnb[8][12] =
    {
        {4,4,4,4, 4,4,4,4, 4,4,4,4},
        {4,4,4,4, 4,4,4,4, 4,4,4,4},
        {5,5,5,5, 5,5,5,5, 5,5,5,5},
        {5,5,5,5, 5,5,5,5, 5,5,5,5},
        {5,5,5,5, 5,5,5,5, 5,5,5,5},
        {5,5,5,5, 5,5,5,5, 5,5,5,5},
        {5,5,5,5, 5,5,5,5, 5,5,5,5},
        {6,6,6,6, 6,6,6,6, 6,6,6,6}
    };

    for(i=0; i<12; i++)
    {
        switch(enc_rgb4_qmode)
        {
            case 0:
                if(rgb_in[i] > 63)
                    rgb_in[i] = 63;
                break;
            case 1:
                if(rgb_in[i] < 192)
                    rgb_in[i] = 192;
                rgb_in[i] -= 192;
                break;
            case 2:
                if(rgb_in[i] > 127)
                    rgb_in[i] = 127;
                break;
            case 3:
                if(rgb_in[i] < 32)
                    rgb_in[i] = 32;
                else if(rgb_in[i] > 159)
                    rgb_in[i] = 159;

                rgb_in[i] -= 32;
                break;
            case 4:
                if(rgb_in[i] < 64)
                    rgb_in[i] = 64;
                else if(rgb_in[i] > 191)
                    rgb_in[i] = 191;

                rgb_in[i] -= 64;
                break;
            case 5:
                if(rgb_in[i] < 96)
                    rgb_in[i] = 96;
                else if(rgb_in[i] > 223)
                    rgb_in[i] = 223;

                rgb_in[i] -= 96;
                break;
            case 6:
                if(rgb_in[i] < 128)
                    rgb_in[i] = 128;
                rgb_in[i] -= 128;
                break;
        }
    }

    for(i=0; i<12; i++)
        enc_rgb4[i] = round_q(rgb_in[i], rnb[enc_rgb4_qmode][i]);

    fmc_dec_rgb4(enc_rgb4_qmode, enc_rgb4, pdec_rgb4_R, pdec_rgb4_G, pdec_rgb4_B, rnb[enc_rgb4_qmode]);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_rgb4_R, pdec_rgb4_G, pdec_rgb4_B, diff_sum);

    copy_block(12, rnb_rgb4, rnb[enc_rgb4_qmode]);
    return enc_rgb4_qmode;
}


void fmc_dec_rgb2(uint8 enc_bp_idx, uint8 *enc_r, uint8 *enc_g, uint8 *enc_b, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;
    uint8 dq_r[2];
    uint8 dq_g[2];
    uint8 dq_b[2];
    uint8 enc_bp[4];
    for(i=0; i<3; i++)
        enc_bp[i] = ((enc_bp_idx>>i) & 1);
    enc_bp[3] = 0;

    for(i=0; i<2; i++)
    {
        dq_r[i] = round_dq(enc_r[i], rnb[i]);
        dq_g[i] = round_dq(enc_g[i], rnb[2+i]);
        dq_b[i] = round_dq(enc_b[i], rnb[4+i]);
    }

    for(i=0; i<BLK_SIZE; i++)
    {
        dec_r[i] = enc_bp[i] ? dq_r[1] : dq_r[0];
        dec_g[i] = enc_bp[i] ? dq_g[1] : dq_g[0];
        dec_b[i] = enc_bp[i] ? dq_b[1] : dq_b[0];
    }
}

void fmc_enc_rgb2(int *diff_sum)
{
    int i;
    uint8 rnb[6] = {4,4, 4,4, 4,4};

    fmc_enc_2kc_get_color(Rin2x2, enc_Ybp2_idx, full_rgb2_R);
    fmc_enc_2kc_get_color(Gin2x2, enc_Ybp2_idx, full_rgb2_G);
    fmc_enc_2kc_get_color(Bin2x2, enc_Ybp2_idx, full_rgb2_B);

    for(i=0; i<2; i++)
    {
        enc_rgb2_R[i] = round_q(full_rgb2_R[i], rnb[i]);
        enc_rgb2_G[i] = round_q(full_rgb2_G[i], rnb[2+i]);
        enc_rgb2_B[i] = round_q(full_rgb2_B[i], rnb[4+i]);
    }

    fmc_dec_rgb2(enc_Ybp2_idx, enc_rgb2_R, enc_rgb2_G, enc_rgb2_B, pdec_rgb2_R, pdec_rgb2_G, pdec_rgb2_B, rnb);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_rgb2_R, pdec_rgb2_G, pdec_rgb2_B, diff_sum);

    copy_block(6, rnb_rgb2, rnb);
}


void fmc_dec_rgb3(uint8 idx, uint8 *enc_r, uint8 *enc_g, uint8 *enc_b, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    fmc_dec_3kc(idx, enc_r, dec_r, rnb);
    fmc_dec_3kc(idx, enc_g, dec_g, rnb+3);
    fmc_dec_3kc(idx, enc_b, dec_b, rnb+6);
}

void fmc_enc_rgb3(int *diff_sum)
{
    uint8 rnb[9] = {5,5,5, 5,5,5, 5,5,6};
    if(enc_Ybp3_idx < 2)
        rnb[8] = 5;

    fmc_enc_3kc(enc_Ybp3_idx, Rin2x2, enc_rgb3_R, rnb);
    fmc_enc_3kc(enc_Ybp3_idx, Gin2x2, enc_rgb3_G, rnb+3);
    fmc_enc_3kc(enc_Ybp3_idx, Bin2x2, enc_rgb3_B, rnb+6);

    fmc_dec_rgb3(enc_Ybp3_idx, enc_rgb3_R, enc_rgb3_G, enc_rgb3_B, pdec_rgb3_R, pdec_rgb3_G, pdec_rgb3_B, rnb);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_rgb3_R, pdec_rgb3_G, pdec_rgb3_B, diff_sum);

    copy_block(9, rnb_rgb3, rnb);
}

uint8 fmc_rgb_enc_dec_top(int *diff_sum)
{
    const uint8 mode_cnt = 4;
    int df_sum[mode_cnt];

    fmc_enc_rgb1(df_sum+0);
    fmc_enc_rgb2(df_sum+1);
    fmc_enc_rgb3(df_sum+2);
    fmc_enc_rgb4(df_sum+3);
    uint8 min_diff_idx = get_min_idx_i32(mode_cnt, df_sum);

    uint8 rgb_enc_mode;
    switch(min_diff_idx)
    {
        case 0:
            rgb_enc_mode = FMC_ENC_MODE_RGB1;
            copy_block(BLK_SIZE, pdec_rgb_R, pdec_rgb1_R);
            copy_block(BLK_SIZE, pdec_rgb_G, pdec_rgb1_G);
            copy_block(BLK_SIZE, pdec_rgb_B, pdec_rgb1_B);
            break;
        case 1:
            rgb_enc_mode = FMC_ENC_MODE_RGB2;
            copy_block(BLK_SIZE, pdec_rgb_R, pdec_rgb2_R);
            copy_block(BLK_SIZE, pdec_rgb_G, pdec_rgb2_G);
            copy_block(BLK_SIZE, pdec_rgb_B, pdec_rgb2_B);

            break;
        case 2:
            rgb_enc_mode = FMC_ENC_MODE_RGB3;
            copy_block(BLK_SIZE, pdec_rgb_R, pdec_rgb3_R);
            copy_block(BLK_SIZE, pdec_rgb_G, pdec_rgb3_G);
            copy_block(BLK_SIZE, pdec_rgb_B, pdec_rgb3_B);
            break;
        default:
            rgb_enc_mode = FMC_ENC_MODE_RGB4;
            copy_block(BLK_SIZE, pdec_rgb_R, pdec_rgb4_R);
            copy_block(BLK_SIZE, pdec_rgb_G, pdec_rgb4_G);
            copy_block(BLK_SIZE, pdec_rgb_B, pdec_rgb4_B);
            break;
    }

    *diff_sum = df_sum[min_diff_idx];
    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_rgb_R, pdec_rgb_G, pdec_rgb_B, diff_sum);

    return rgb_enc_mode;

}
