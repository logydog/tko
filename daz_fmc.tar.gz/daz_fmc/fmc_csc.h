#ifndef __DAZ_FMC_CSC_H__
#define __DAZ_FMC_CSC_H__

#include "../data_type.h"
#include "data_type.h"
#include "main.h"

void csc_table_init(void);
void rgb2ycbcr(int blk_size, uint8 *Rin, uint8 *Gin, uint8 *Bin,
    uint8 *Yin, uint8 *CBin, uint8 *CRin);
void ycbcr2rgb(int blk_size, uint8 *Rout, uint8 *Gout, uint8 *Bout,
    uint8 *Yout, uint8 *CBout, uint8 *CRout);


#endif
