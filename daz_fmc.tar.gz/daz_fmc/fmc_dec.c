/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

static uint8 R_dec_ich_buf[ICH_BUF_SIZE_Y][ICH_BUF_SIZE_X];
static uint8 G_dec_ich_buf[ICH_BUF_SIZE_Y][ICH_BUF_SIZE_X];
static uint8 B_dec_ich_buf[ICH_BUF_SIZE_Y][ICH_BUF_SIZE_X];

void write_enc_bs(uint8 enc_mode)
{
    int i;

    for(i=0; i<4; i++)
        fmc_bs.bs_byte[i] = BS_HDR_RESERVED;

    uint8 bp3;
    switch(enc_mode)
    {
        case FMC_ENC_MODE_YUV2:
            fmc_bs.yuv2.hdr = BS_HDR_YUV2;
            fmc_bs.yuv2.bp2 = enc_Ybp2_idx;
            fmc_bs.yuv2.y0 = enc_yuv2_Y[0];
            fmc_bs.yuv2.y1 = enc_yuv2_Y[1];
            fmc_bs.yuv2.cb = enc_yuv2_CB;
            fmc_bs.yuv2.cr = enc_yuv2_CR;
            break;

        case FMC_ENC_MODE_YUV3:
            fmc_bs.yuv3.hdr = BS_HDR_YUV3;
            fmc_bs.yuv3.y0 = enc_yuv3_Y[0];
            fmc_bs.yuv3.y1 = enc_yuv3_Y[1];
            fmc_bs.yuv3.cb = enc_yuv3_CB;
            fmc_bs.yuv3.cr = enc_yuv3_CR;

            bp3 = (enc_Ybp3_idx==0) ? 0 :
                (enc_Ybp3_idx==1) ? 1 :
                (enc_Ybp3_idx==2) ? 0 :
                (enc_Ybp3_idx==3) ? 1 :
                (enc_Ybp3_idx==4) ? 2 : 3;
            uint8 y2 = (enc_Ybp3_idx<2) ? (enc_yuv3_Y[2]<<1) : (enc_yuv3_Y[2]<<2);
            fmc_bs.yuv3.bp3_y2 = (y2 | bp3);
            fmc_bs.yuv3.bp3_1bit = (enc_Ybp3_idx<2);
            break;

        case FMC_ENC_MODE_YUV4:
            fmc_bs.yuv4.hdr = BS_HDR_YUV4;
            fmc_bs.yuv4.y0 = enc_yuv4_Y[0];
            fmc_bs.yuv4.y1 = enc_yuv4_Y[1];
            fmc_bs.yuv4.y2 = enc_yuv4_Y[2];
            fmc_bs.yuv4.y3 = enc_yuv4_Y[3];
            fmc_bs.yuv4.cb = enc_yuv4_CB;
            fmc_bs.yuv4.cr = enc_yuv4_CR;
            break;

        case FMC_ENC_MODE_RGB1:
            fmc_bs.rgb1.hdr = BS_HDR_RGB1;
            fmc_bs.rgb1.r = enc_rgb1[0];
            fmc_bs.rgb1.g = enc_rgb1[1];
            fmc_bs.rgb1.b = enc_rgb1[2];
            break;

        case FMC_ENC_MODE_RGB2:
            fmc_bs.rgb2.hdr = BS_HDR_RGB2;
            fmc_bs.rgb2.bp2 = enc_Ybp2_idx;
            fmc_bs.rgb2.r0 = enc_rgb2_R[0];
            fmc_bs.rgb2.r1 = enc_rgb2_R[1];
            fmc_bs.rgb2.g0 = enc_rgb2_G[0];
            fmc_bs.rgb2.g1 = enc_rgb2_G[1];
            fmc_bs.rgb2.b0 = enc_rgb2_B[0];
            fmc_bs.rgb2.b1 = enc_rgb2_B[1];
            break;

        case FMC_ENC_MODE_RGB3:
            fmc_bs.rgb3.hdr = BS_HDR_RGB3;
            fmc_bs.rgb3.r0 = enc_rgb3_R[0];
            fmc_bs.rgb3.r1 = enc_rgb3_R[1];
            fmc_bs.rgb3.r2 = enc_rgb3_R[2];
            fmc_bs.rgb3.g0 = enc_rgb3_G[0];
            fmc_bs.rgb3.g1 = enc_rgb3_G[1];
            fmc_bs.rgb3.g2 = enc_rgb3_G[2];
            fmc_bs.rgb3.b0 = enc_rgb3_B[0];
            fmc_bs.rgb3.b1 = enc_rgb3_B[1];

            bp3 = (enc_Ybp3_idx==0) ? 0 :
                (enc_Ybp3_idx==1) ? 1 :
                (enc_Ybp3_idx==2) ? 0 :
                (enc_Ybp3_idx==3) ? 1 :
                (enc_Ybp3_idx==4) ? 2 : 3;

            uint8 b2 = (enc_Ybp3_idx<2) ? (enc_rgb3_B[2]<<1) : (enc_rgb3_B[2]<<2);
            fmc_bs.rgb3.bp3_b2 = (b2 | bp3);
            fmc_bs.rgb3.bp3_1bit = (enc_Ybp3_idx<2);
            break;

        case FMC_ENC_MODE_RGB4:
            fmc_bs.rgb4.hdr = BS_HDR_RGB4;
            fmc_bs.rgb4.qmode = enc_rgb4_qmode;
            fmc_bs.rgb4.r0 = enc_rgb4[0];
            fmc_bs.rgb4.r1 = enc_rgb4[1];
            fmc_bs.rgb4.r2 = enc_rgb4[2];
            fmc_bs.rgb4.r3 = enc_rgb4[3];
            fmc_bs.rgb4.g0 = enc_rgb4[4];
            fmc_bs.rgb4.g1 = enc_rgb4[5];
            fmc_bs.rgb4.g2 = enc_rgb4[6];
            fmc_bs.rgb4.g3 = enc_rgb4[7];
            fmc_bs.rgb4.b0 = enc_rgb4[8];
            fmc_bs.rgb4.b1 = enc_rgb4[9];
            fmc_bs.rgb4.b2 = enc_rgb4[10];
            fmc_bs.rgb4.b3 = enc_rgb4[11];
            break;

        case FMC_ENC_MODE_GRAY3:
            fmc_bs.gray3.hdr = BS_HDR_GRAY3;
            fmc_bs.gray3.bp3 = enc_Ybp3_idx;
            fmc_bs.gray3.v0 = enc_gray3[0];
            fmc_bs.gray3.v1 = enc_gray3[1];
            fmc_bs.gray3.v2 = enc_gray3[2];
            break;

        case FMC_ENC_MODE_GRAY4:
            fmc_bs.gray4.hdr = BS_HDR_GRAY4;
            fmc_bs.gray4.quant = enc_gray4_quant;

            uint32 gray4_data;
            if(enc_gray4_quant)
            {
                gray4_data = 0;
                for(i=0; i<4; i++)
                    gray4_data |= ((uint32)enc_gray4[i] << (7*i));
            }
            else
            {
                gray4_data = enc_gray4_min;
                for(i=0; i<4; i++)
                    gray4_data |= ((uint32)enc_gray4[i] << (8+5*i));
            }
            fmc_bs.gray4.data = gray4_data;
            break;

        case FMC_ENC_MODE_ICH0:
        case FMC_ENC_MODE_ICH1:
        case FMC_ENC_MODE_ICH2:
        case FMC_ENC_MODE_ICH3:
        case FMC_ENC_MODE_ICH4:
        case FMC_ENC_MODE_ICH5:
        case FMC_ENC_MODE_ICH6:
        case FMC_ENC_MODE_ICH7:
            fmc_bs.ich.hdr = BS_HDR_ICH;
            fmc_bs.ich.idx = enc_ich_idx;
            fmc_bs.ich.mode = enc_ich_mode;
            fmc_bs.ich.r0 = enc_ich_R[0];
            fmc_bs.ich.r1 = enc_ich_R[1];
            fmc_bs.ich.r2 = enc_ich_R[2];
            fmc_bs.ich.r3 = enc_ich_R[3];
            fmc_bs.ich.g0 = enc_ich_G[0];
            fmc_bs.ich.g1 = enc_ich_G[1];
            fmc_bs.ich.g2 = enc_ich_G[2];
            fmc_bs.ich.g3 = enc_ich_G[3];
            fmc_bs.ich.b0 = enc_ich_B[0];
            fmc_bs.ich.b1 = enc_ich_B[1];
            fmc_bs.ich.b2 = enc_ich_B[2];
            fmc_bs.ich.b3 = enc_ich_B[3];
            break;

        case FMC_ENC_MODE_PAT0_2KC_2V:
            fmc_bs.pat0.hdr = BS_HDR_PAT0_2KC_2V;
            fmc_bs.pat0.v0 = enc_pat0_v0;
            fmc_bs.pat0.v1 = enc_pat0_v1;
            fmc_bs.pat0.kc0 = enc_pat0_kc0;
            fmc_bs.pat0.kc1 = enc_pat0_kc1;
            fmc_bs.pat0.p0 = enc_pat0_px_sel[0];
            fmc_bs.pat0.p1 = enc_pat0_px_sel[1];
            fmc_bs.pat0.p2 = enc_pat0_px_sel[2];
            break;

        case FMC_ENC_MODE_PAT1_CH_AB_C:
            fmc_bs.pat1.hdr = BS_HDR_PAT1_CH_AB_C;
            fmc_bs.pat1.ab_sel = enc_pat1_ab_sel;
            fmc_bs.pat1.c_sel = enc_pat1_c_sel;
            fmc_bs.pat1.data_1v = enc_pat1_1v;
            fmc_bs.pat1.quant_4v = enc_pat1_quant;

            uint16 pat1_data;
            if(enc_pat1_quant)
            {
                pat1_data = 0;
                for(i=0; i<4; i++)
                    pat1_data |= ((uint16)enc_pat1_4v[i] << (4*i));
            }
            else
            {
                pat1_data = enc_pat1_4v_min;
                for(i=0; i<4; i++)
                    pat1_data |= ((uint16)enc_pat1_4v[i] << (8+ 2*i));
            }

            fmc_bs.pat1.data_4v = pat1_data;
            break;

        case FMC_ENC_MODE_PAT2_2KC_GR_CLR:
            fmc_bs.pat2.hdr = BS_HDR_PAT2_GR_COLR;
            fmc_bs.pat2.bp2 = enc_Ybp2_idx;
            fmc_bs.pat2.p3_gray = enc_pat2_px3_gray;
            fmc_bs.pat2.gray = enc_pat2_gray;
            fmc_bs.pat2.r = enc_pat2_color[0];
            fmc_bs.pat2.g = enc_pat2_color[1];
            fmc_bs.pat2.b = enc_pat2_color[2];
            break;

        case FMC_ENC_MODE_PAT3_PZC1:
            fmc_bs.pat3.hdr = BS_HDR_PAT3_PZC1;
            fmc_bs.pat3.ch4v_sel = enc_pat3_ch4v_sel;
            fmc_bs.pat3.data_1v = enc_pat3_1v;
            fmc_bs.pat3.quant_4v = enc_pat3_4v_quant;

            uint32 pat3_data;
            if(enc_pat3_4v_quant)
            {
                pat3_data = 0;
                for(i=0; i<4; i++)
                    pat3_data |= ((uint32)enc_pat3_4v[i] << (5*i));
            }
            else
            {
                pat3_data = enc_pat3_4v_min;
                for(i=0; i<4; i++)
                    pat3_data |= ((uint32)enc_pat3_4v[i] << (8+ 3*i));
            }
            fmc_bs.pat3.data_4v = pat3_data;
            break;

        case FMC_ENC_MODE_PAT4_PZC2:
            fmc_bs.pat4.hdr = BS_HDR_PAT4_PZC2;
            fmc_bs.pat4.ch4v_sel = enc_pat4_ch4v_sel;
            fmc_bs.pat4.data_1v = enc_pat4_1v;
            fmc_bs.pat4.v0 = enc_pat4_4v[0];
            fmc_bs.pat4.v1 = enc_pat4_4v[1];
            fmc_bs.pat4.v2 = enc_pat4_4v[2];
            fmc_bs.pat4.v3 = enc_pat4_4v[3];
            break;

        case FMC_ENC_MODE_PAT5_PZC_RCBC:
            fmc_bs.pat5.hdr = BS_HDR_PAT5_PZC_RCBC;
            fmc_bs.pat5.bc_sel = enc_pat5_bc;
            fmc_bs.pat5.g0 = enc_pat5_g[0];
            fmc_bs.pat5.g1 = enc_pat5_g[1];
            fmc_bs.pat5.g2 = enc_pat5_g[2];
            fmc_bs.pat5.rb1 = enc_pat5_rb[1];
            fmc_bs.pat5.rb2 = enc_pat5_rb[2];

            bp3 = (enc_pat5_bp3_idx==0) ? 0 :
                    (enc_pat5_bp3_idx==1) ? 1 :
                    (enc_pat5_bp3_idx==2) ? 0 :
                    (enc_pat5_bp3_idx==3) ? 1 :
                    (enc_pat5_bp3_idx==4) ? 2 : 3;

            uint8 bp3_1b = (enc_pat5_bp3_idx==2 || enc_pat5_bp3_idx==3);
            uint8 rb0 = bp3_1b ? (enc_pat5_rb[0]<<1) : (enc_pat5_rb[0]<<2);
            fmc_bs.pat5.bp3_rb0 = (rb0 | bp3);
            fmc_bs.pat5.bp3_1bit = bp3_1b;
            break;

        default:
            break;
    }

#ifdef SAVE_RAW_FILE
    for(i=0; i<BSTREAM_BYTE_CNT; i++)
        bstream[i] = fmc_bs.bs_byte[i];
    save_bstream_file(bstream, BSTREAM_BYTE_CNT);
#endif

}

void dec_yuv2(fmc_enc_bs_yuv2 *bs)
{
    uint8 y[2] = {bs->y0, bs->y1};

    fmc_dec_yuv2(bs->bp2, y, bs->cb, bs->cr, Yout2x2, CBout2x2, CRout2x2, rnb_yuv2);
}

void dec_yuv3(fmc_enc_bs_yuv3 *bs)
{
    uint8 bp3_y2 = bs->bp3_y2;
    uint8 bp3_1b = (bp3_y2 & 1);
    uint8 bp3_2b = ((bp3_y2 & 3) + 2);
    uint8 y2_5b = ((bp3_y2>>1) & 0x1f);
    uint8 y2_4b = ((bp3_y2>>2) & 0x0f);

    uint8 bp3 = (bs->bp3_1bit) ? bp3_1b : bp3_2b;
    uint8 y2 = (bs->bp3_1bit) ? y2_5b : y2_4b;
    uint8 y[3] = {bs->y0, bs->y1, y2};

    fmc_dec_yuv3(bp3, y, bs->cb, bs->cr, Yout2x2, CBout2x2, CRout2x2, rnb_yuv3);
}

void dec_yuv4(fmc_enc_bs_yuv4 *bs)
{
    uint8 y[4] = {bs->y0, bs->y1, bs->y2, bs->y3};

    fmc_dec_yuv4(y, bs->cb, bs->cr, Yout2x2, CBout2x2, CRout2x2, rnb_yuv4);
}

void dec_rgb1(fmc_enc_bs_rgb1 *bs)
{
    uint8 enc_data[3] = {bs->r, bs->g, bs->b};
    fmc_dec_rgb1(enc_data, Rout2x2, Gout2x2, Bout2x2);
}

void dec_rgb2(fmc_enc_bs_rgb2 *bs)
{
    uint8 r[2] ={bs->r0, bs->r1};
    uint8 g[2] ={bs->g0, bs->g1};
    uint8 b[2] ={bs->b0, bs->b1};

    fmc_dec_rgb2(bs->bp2, r, g, b, Rout2x2, Gout2x2, Bout2x2, rnb_rgb2);
}

void dec_rgb3(fmc_enc_bs_rgb3 *bs)
{
    uint8 bp3_b2 = bs->bp3_b2;
    uint8 bp3_1b = (bp3_b2 & 1);
    uint8 bp3_2b = ((bp3_b2 & 3) + 2);
    uint8 b2_3b = ((bp3_b2>>1) & 7);
    uint8 b2_2b = ((bp3_b2>>2) & 3);

    uint8 bp3 = (bs->bp3_1bit) ? bp3_1b : bp3_2b;
    uint8 b2 = (bs->bp3_1bit) ? b2_3b : b2_2b;

    uint8 r[3] ={bs->r0, bs->r1, bs->r2};
    uint8 g[3] ={bs->g0, bs->g1, bs->g2};
    uint8 b[3] ={bs->b0, bs->b1, b2};

    fmc_dec_rgb3(bp3, r, g, b, Rout2x2, Gout2x2, Bout2x2, rnb_rgb3);
}

void dec_rgb4(fmc_enc_bs_rgb4 *bs)
{
    uint8 rgb[12] =
    {
        bs->r0,bs->r1,bs->r2,bs->r3,
        bs->g0,bs->g1,bs->g2,bs->g3,
        bs->b0,bs->b1,bs->b2,bs->b3
    };

    fmc_dec_rgb4(bs->qmode, rgb, Rout2x2, Gout2x2, Bout2x2, rnb_rgb4);
}

void dec_gray3(fmc_enc_bs_gray3 *bs)
{
    uint8 v[3] = {bs->v0, bs->v1, bs->v2};
    fmc_dec_gray3(bs->bp3, v, Rout2x2, Gout2x2, Bout2x2, rnb_gray3);
}

void dec_gray4(fmc_enc_bs_gray4 *bs)
{
    int i;
    uint8 v_data[4];

    uint8 quant = bs->quant;

    uint8 v_min = (bs->data & 0xff);
    if(quant)
    {
        for(i=0; i<4; i++)
            v_data[i] = ((bs->data >> (7*i)) & 0x7f);
    }
    else
    {
        for(i=0; i<4; i++)
            v_data[i] = ((bs->data >> (5*i+8)) & 0x1f);
    }

    fmc_dec_gray4(quant, v_min, v_data, Rout2x2, Gout2x2, Bout2x2, rnb_gray4);
}

void dec_ich(fmc_enc_bs_ich *bs)
{
    uint8 bs_r[4] = {bs->r0, bs->r1, bs->r2, bs->r3};
    uint8 bs_g[4] = {bs->g0, bs->g1, bs->g2, bs->g3};
    uint8 bs_b[4] = {bs->b0, bs->b1, bs->b2, bs->b3};


    fmc_dec_ich(bs->mode, bs->idx, bs_r, bs_g, bs_b,
				R_dec_ich_buf, G_dec_ich_buf, B_dec_ich_buf,
    			Rout2x2, Gout2x2, Bout2x2);
}

void dec_pat0(fmc_enc_bs_pat0_2kc_2v *bs)
{
    uint8 px_sel[3] = {bs->p0, bs->p1, bs->p2};
    fmc_dec_pat0_2kc_2v(bs->v0, bs->v1, bs->kc0, bs->kc1, px_sel, Rout2x2, Gout2x2, Bout2x2);
}

void dec_pat1(fmc_enc_bs_pat1_ab_c *bs)
{
    int i;
    uint8 quant = bs->quant_4v;
    uint8 min_4v = (bs->data_4v & 0xff);
    uint8 data_4v[4];
    if(quant)
    {
        for(i=0; i<4; i++)
            data_4v[i] = ((bs->data_4v >> (4*i)) & 0xf);
    }
    else
    {
        for(i=0; i<4; i++)
            data_4v[i] = ((bs->data_4v >> (8 + 2*i)) & 3);
    }

    fmc_dec_pat1_ch_ab_c(bs->ab_sel, bs->c_sel, bs->data_1v, bs->quant_4v, min_4v, data_4v,
        Rout2x2, Gout2x2, Bout2x2, rnb_pat1);
}

void dec_pat2(fmc_enc_bs_pat2_2kc_gr_col *bs)
{
    uint8 color[3] = {bs->r, bs->g, bs->b};
    fmc_dec_pat2_2kc_gray_color(bs->bp2, bs->p3_gray, bs->gray, color,
        Rout2x2, Gout2x2, Bout2x2, rnb_pat2);
}

void dec_pat3(fmc_enc_bs_pat3_pzc1 *bs)
{
    int i;
    uint8 quant = bs->quant_4v;
    uint8 min_4v = (bs->data_4v & 0xff);
    uint8 data_4v[4];
    if(quant)
    {
        for(i=0; i<4; i++)
            data_4v[i] = ((bs->data_4v >> (5*i)) & 0x1f);
    }
    else
    {
        for(i=0; i<4; i++)
            data_4v[i] = ((bs->data_4v >> (8 + 3*i)) & 7);
    }

    fmc_dec_pat3_pzc1(bs->ch4v_sel, bs->data_1v, quant, min_4v, data_4v,
        Rout2x2, Gout2x2, Bout2x2, rnb_pat3);
}

void dec_pat4(fmc_enc_bs_pat4_pzc2 *bs)
{
    uint8 data_4v[4] = {bs->v0, bs->v1, bs->v2, bs->v3};

    fmc_dec_pat4_pzc2(bs->ch4v_sel, bs->data_1v, data_4v, Rout2x2, Gout2x2, Bout2x2, rnb_pat4);
}

void dec_pat5(fmc_enc_bs_pat5_pzc_rcbc *bs)
{
    uint8 bp3_rb0 = bs->bp3_rb0;
    uint8 bp3_1b = (bp3_rb0 & 1) + 2;
    uint8 bp3_2b = (bp3_rb0 & 3);
    if(bp3_2b > 1)
        bp3_2b += 2;

    uint8 rb0_4b = ((bp3_rb0>>1) & 0xf);
    uint8 rb0_3b = ((bp3_rb0>>2) & 0x7);

    uint8 bp3 = (bs->bp3_1bit) ? bp3_1b : bp3_2b;
    uint8 rb0 = (bs->bp3_1bit) ? rb0_4b : rb0_3b;

    uint8 g[3] = {bs->g0, bs->g1, bs->g2};
    uint8 rb[3] = {rb0, bs->rb1, bs->rb2};

    fmc_dec_pat5_pzc_rcbc(bs->bc_sel, bp3, g, rb,
        Rout2x2, Gout2x2, Bout2x2, rnb_pat5);
}


void fmc_dec_top(bool slice_start)
{
	update_ich_buf(slice_start,	R_dec_ich_buf, G_dec_ich_buf, B_dec_ich_buf,
					Rout2x2, Gout2x2, Bout2x2);

    if(fmc_bs.yuv2.hdr == BS_HDR_YUV2)
        dec_yuv2(&(fmc_bs.yuv2));

    else if(fmc_bs.yuv3.hdr == BS_HDR_YUV3)
        dec_yuv3(&(fmc_bs.yuv3));

    else if(fmc_bs.yuv4.hdr == BS_HDR_YUV4)
        dec_yuv4(&(fmc_bs.yuv4));

    else if(fmc_bs.rgb1.hdr == BS_HDR_RGB1)
        dec_rgb1(&(fmc_bs.rgb1));

    else if(fmc_bs.rgb2.hdr == BS_HDR_RGB2)
        dec_rgb2(&(fmc_bs.rgb2));

    else if(fmc_bs.rgb3.hdr == BS_HDR_RGB3)
        dec_rgb3(&(fmc_bs.rgb3));

    else if(fmc_bs.rgb4.hdr == BS_HDR_RGB4)
        dec_rgb4(&(fmc_bs.rgb4));

    else if(fmc_bs.gray3.hdr == BS_HDR_GRAY3)
        dec_gray3(&(fmc_bs.gray3));

    else if(fmc_bs.gray4.hdr == BS_HDR_GRAY4)
        dec_gray4(&(fmc_bs.gray4));

    else if(fmc_bs.ich.hdr == BS_HDR_ICH)
        dec_ich(&(fmc_bs.ich));

    else if(fmc_bs.pat0.hdr == BS_HDR_PAT0_2KC_2V)
        dec_pat0(&(fmc_bs.pat0));

    else if(fmc_bs.pat1.hdr == BS_HDR_PAT1_CH_AB_C)
        dec_pat1(&(fmc_bs.pat1));

    else if(fmc_bs.pat2.hdr == BS_HDR_PAT2_GR_COLR)
        dec_pat2(&(fmc_bs.pat2));

    else if(fmc_bs.pat3.hdr == BS_HDR_PAT3_PZC1)
        dec_pat3(&(fmc_bs.pat3));

    else if(fmc_bs.pat4.hdr == BS_HDR_PAT4_PZC2)
        dec_pat4(&(fmc_bs.pat4));

    else if(fmc_bs.pat5.hdr == BS_HDR_PAT5_PZC_RCBC)
        dec_pat5(&(fmc_bs.pat5));


    if(fmc_bs.yuv2.hdr == BS_HDR_YUV2 || fmc_bs.yuv3.hdr == BS_HDR_YUV3 || fmc_bs.yuv4.hdr == BS_HDR_YUV4)
        ycbcr2rgb(BLK_SIZE, Rout2x2, Gout2x2, Bout2x2, Yout2x2, CBout2x2, CRout2x2);

}


