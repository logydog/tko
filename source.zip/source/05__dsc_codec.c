/***************************************************************************
*    Copyright (c) 2013, Broadcom Corporation
*    All rights reserved.
*
*  Statement regarding contribution of copyrighted materials to VESA:
*
*  This code is owned by Broadcom Corporation and is contributed to VESA
*  for inclusion and use in its VESA Display Stream Compression specification.
*  Accordingly, VESA is hereby granted a worldwide, perpetual, non-exclusive
*  license to revise, modify and create derivative works to this code and
*  VESA shall own all right, title and interest in and to any derivative
*  works authored by VESA.
*
*  Terms< and Conditions
*
*  Without limiting the foregoing, you agree that your use
*  of this software program does not convey any rights to you in any of
*  Broadcom�s patent and other intellectual property, and you
*  acknowledge that your use of this software may require that
*  you separately obtain patent or other intellectual property
*  rights from Broadcom or third parties.
*
*  Except as expressly set forth in a separate written license agreement
*  between you and Broadcom, if applicable:
*
*  1. TO THE MAXIMUM EXTENT PERMITTED BY LAW, THE SOFTWARE IS PROVIDED
*  "AS IS" AND WITH ALL FAULTS AND BROADCOM MAKES NO PROMISES,
*  REPRESENTATIONS OR WARRANTIES, EITHER EXPRESS, IMPLIED, STATUTORY, OR
*  OTHERWISE, WITH RESPECT TO THE SOFTWARE.  BROADCOM SPECIFICALLY
*  DISCLAIMS ANY AND ALL IMPLIED WARRANTIES OF TITLE, MERCHANTABILITY,
*  NONINFRINGEMENT, FITNESS FOR A PARTICULAR PURPOSE, LACK OF VIRUSES,
*  ACCURACY OR COMPLETENESS, QUIET ENJOYMENT, QUIET POSSESSION OR
*  CORRESPONDENCE TO DESCRIPTION. YOU ASSUME THE ENTIRE RISK ARISING
*  OUT OF USE OR PERFORMANCE OF THE SOFTWARE.
*
*  2. TO THE MAXIMUM EXTENT PERMITTED BY LAW, IN NO EVENT SHALL
*  BROADCOM OR ITS LICENSORS BE LIABLE FOR (i) CONSEQUENTIAL, INCIDENTAL,
*  SPECIAL, INDIRECT, OR EXEMPLARY DAMAGES WHATSOEVER ARISING OUT OF OR
*  IN ANY WAY RELATING TO YOUR USE OF OR INABILITY TO USE THE SOFTWARE EVEN
*  IF BROADCOM HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES; OR (ii)
*  ANY AMOUNT IN EXCESS OF THE AMOUNT ACTUALLY PAID FOR THE SOFTWARE ITSELF
*  OR U.S. $1, WHICHEVER IS GREATER. THESE LIMITATIONS SHALL APPLY
*  NOTWITHSTANDING ANY FAILURE OF ESSENTIAL PURPOSE OF ANY LIMITED REMEDY.
***************************************************************************/

/*! \file dsc_codec.c
 *    DSC codec
 *  \author Frederick Walls (fwalls@broadcom.com)
 *  \author Sandy MacInnis (macinnis@broadcom.com)
 *  \author and others at Broadcom
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>
#include <assert.h>
#include "07__dsc_utils.h"
#include "05__dsc_codec.h"
#include "dsc_types.h"
#include "08__multiplex.h"
#include "ppp.h"

//#define PRINTDEBUG
#define PRINT_DEBUG_VLC   0
#define PRINT_DEBUG_RC    0
#define PRINT_DEBUG_RECON 0

// Prototypes
int MapQpToQlevel(dsc_state_t *dsc_state, int qp, int CType);
int FindResidualSize(int eq);
int SampToLineBuf( dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int x, int CType, int slicenum);
void get_shifter_for_verilog(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int cpnt, int *shifter, int slicenum);

int mod_hPos_test;
//-----------------------------------------------------------------------------
// debug dumping

FILE *g_fp_dbg              = 0;


//-----------------------------------------------------------------------------
// The following are constants that are used in the code:
const int QuantDivisor[] = {1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096 };
const int QuantOffset[] = {0, 0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047 };
int qlevel_luma_8bpc[] = {0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 5, 6, 7 };
int qlevel_chroma_8bpc[] = {0, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 8, 8, 8 };
int qlevel_luma_10bpc[] = {0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 7, 8, 9 };
int qlevel_chroma_10bpc[] = {0, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 10, 10, 10 };
int qlevel_luma_12bpc[] = {0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 9, 10, 11 };
int qlevel_chroma_12bpc[] = {0, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 12, 12, 12 };

// ======================================================================================== begin
//! Map QP to quantization level
/*! \param dsc_state DSC state structure
    \param qp      QP to map
    \param cpnt    Component to map
    \return        Corresponding qlevel */
int MapQpToQlevel(dsc_state_t *dsc_state, int qp, int cpnt)
{
        int qlevel;

        // *MODEL NOTE* MN_MAP_QP_TO_QLEVEL
        if (cpnt == 0)
                qlevel = dsc_state->quantTableLuma[qp];
        else
                qlevel = dsc_state->quantTableChroma[qp];

        return (qlevel);
}


// ======================================================================================== begin
//! Get maximum residual size for a given component & quantization level
/*! \param dsc_state DSC state structure
        \param cpnt      Which component
        \param qp        Quantization parameter
        \return          Max residual size in bits */
int MaxResidualSize(dsc_state_t *dsc_state, int cpnt, int qp, int slicenum)
{
        int qlevel;

//ppp("     |05__000| # int MaxResidualSize \n");
        qlevel = MapQpToQlevel(dsc_state, qp, cpnt);

//ppp("     |05__001| <MaxResidualSize> g%d, qlevel=%d \n", dsc_state->groupCount, qlevel);
//ppp("     |05__002| <MaxResidualSize> g%d, cpntBitDepth[cpnt]=%d \n", dsc_state->groupCount, dsc_state->cpntBitDepth[cpnt]);
        return (dsc_state->cpntBitDepth[cpnt] - qlevel);
}

// ======================================================================================== begin
//! Get predicted size for unit (adjusted for QP changes)
/*! \param dsc_state DSC state structure
        \param cpnt      Which component
    \return          Predicted size for unit */
int GetQpAdjPredSize(dsc_state_t *dsc_state, int cpnt, int slicenum)
{
        int pred_size, max_size;
        int qlevel_old, qlevel_new;
        char c_cpnt;

        if(cpnt==0) c_cpnt='Y'; else if(cpnt==1) c_cpnt='U'; else c_cpnt='V';

        // *MODEL NOTE* MN_DSU_SIZE_PREDICTION
        pred_size = dsc_state->predictedSize[cpnt];

//ppp("     |05__003| <GetQpAdjPredSize> g%d, predictedSize[%c]=%d \n", dsc_state->groupCount, c_cpnt, dsc_state->predictedSize[cpnt]);
//ppp("     |05__004| <GetQpAdjPredSize> g%d, masterQp=%d \n", dsc_state->groupCount, dsc_state->masterQp);
//ppp("     |05__005| <GetQpAdjPredSize> g%d, prevMasterQp=%d \n", dsc_state->groupCount, dsc_state->prevMasterQp);
        //printf("%d\n", pred_size);
        qlevel_old = MapQpToQlevel(dsc_state, dsc_state->prevMasterQp, cpnt);
        qlevel_new = MapQpToQlevel(dsc_state, dsc_state->masterQp, cpnt);

        pred_size += qlevel_old - qlevel_new;

//ppp("     |05__006| <GetQpAdjPredSize> g%d, qlevel_old=%d \n", dsc_state->groupCount, qlevel_old);
//ppp("     |05__007| <GetQpAdjPredSize> g%d, qlevel_new=%d \n", dsc_state->groupCount, qlevel_new);
//ppp("     |05__008| <GetQpAdjPredSize> g%d, pred_size=%d \n", dsc_state->groupCount, pred_size);

        max_size = MaxResidualSize(dsc_state, cpnt, dsc_state->masterQp, slicenum);

//ppp("     |05__009| <GetQpAdjPredSize> g%d, max_size=%d \n", dsc_state->groupCount, max_size);

        pred_size = CLAMP(pred_size, 0, max_size-1);

//ppp("     |05__010| <GetQpAdjPredSize> g%d, pred_size=%d \n", dsc_state->groupCount, pred_size);

        return (pred_size);
}

void get_shifter_for_verilog(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int cpnt, int* shifter, int slicenum)
{
        unsigned int  _0to3_bytes;
        unsigned int  _4to7_bytes;
        unsigned int  first_3_bytes;
        unsigned int  last_2_bytes;
        int     read_ptr_byte;
        int     valid_position;
        char c_cpnt;

//      FILE *shifterlog = fopen("shifter_golden.txt","w");
        if(cpnt==0) c_cpnt='Y'; else if(cpnt==1) c_cpnt='U'; else c_cpnt='V';

        read_ptr_byte = dsc_state->shifter[cpnt].read_ptr/8;
        valid_position= dsc_state->shifter[cpnt].read_ptr%8;


        _0to3_bytes=0;
        _4to7_bytes=0;

//ppp("     |05__011| g%d, %c, # read_ptr_byte[%c]=%d \n",dsc_state->groupCount, c_cpnt, c_cpnt, read_ptr_byte);
        for (int i=0; i<4; ++i)
        {
                _0to3_bytes = _0to3_bytes + (dsc_state->shifter[cpnt].data[read_ptr_byte]<<(8*(3-i)));

                if(read_ptr_byte==(48+MAX_SE_SIZE+7)/8-1)   read_ptr_byte = 0;
                else                                        read_ptr_byte = read_ptr_byte + 1;
        }

//ppp("     |05__012| g%d, %c, # read_ptr_byte[%c]=%d \n",dsc_state->groupCount, c_cpnt, c_cpnt, read_ptr_byte);
        for (int i=0; i<4; ++i)
        {
                _4to7_bytes = _4to7_bytes + (dsc_state->shifter[cpnt].data[read_ptr_byte]<<(8*(3-i)));

                if(read_ptr_byte==(48+MAX_SE_SIZE+7)/8-1)   read_ptr_byte = 0;
                else                                        read_ptr_byte = read_ptr_byte + 1;
        }

        first_3_bytes =                                                                        (_0to3_bytes>>(   8-valid_position)) & 0xffffff;
        last_2_bytes  = (((_0to3_bytes&((1<<(8-valid_position))-1))<<(16-8+valid_position)) +  (_4to7_bytes>>(16+8-valid_position))) & 0xffff;

//ppp("     |05__013| g%d, %c, # dbg1=0x%04x \n",dsc_state->groupCount, c_cpnt, ((_0to3_bytes&((1<<(8-valid_position))-1))<<(16-8+valid_position)));
//ppp("     |05__014| g%d, %c, # dbg2=0x%04x \n",dsc_state->groupCount, c_cpnt, (_4to7_bytes>>(16+8-valid_position)));

//ppp("     |05__015| g%d, %c, # first_3_bytes=0x%06x \n",dsc_state->groupCount, c_cpnt, first_3_bytes);
//ppp("     |05__016| g%d, %c, # last_2_bytes =0x%04x \n",dsc_state->groupCount, c_cpnt, last_2_bytes);

//ppp("     |05__017| g%d, %c, # shifter[%c]=0x%06x%04x \n",dsc_state->groupCount, c_cpnt, c_cpnt, first_3_bytes, last_2_bytes);
  ppp("g%d,shifter[%c]=0x%06x%04x \n",dsc_state->groupCount, c_cpnt, first_3_bytes, last_2_bytes);


//      shifter[0] = first_3_bytes ;
//      shifter[1] = last_2_bytes  ;

}

// ======================================================================================== begin
//! Get the predicted sample value
/*! \param prevLine  Array of samples from previous (reconstructed) line
        \param currLine  Array of samples from current (reconstructed) line
        \param hPos      Horizontal position within slice of sample to predict
        \param predType  Prediction mode to use (PT_MAP or one of PT_BLOCK)
        \param qLevel    Quantization level for current component
        \param cpnt      Which component
        \return          Predicted sample value */
int SamplePredict(
        dsc_state_t *dsc_state,
        int* prevLine,          // reconstructed samples for previous line
        int* currLine,          // reconstructed samples for current line
        int hPos,               // horizontal position for sample to predict
        PRED_TYPE predType,     // predictor to use
        int qLevel,
        int cpnt,
        int slicenum)
{
        int a, b, c, d, e;
        int filt_b, filt_c, filt_d, filt_e;
        int blend_b, blend_c_prev, blend_c, blend_d, blend_e;
        int p;
        int bp_offset;
        int diff = 0;
        int h_offset_array_idx;
        char c_cpnt;

        if(cpnt==0) c_cpnt='Y'; else if(cpnt==1) c_cpnt='U'; else c_cpnt='V';

        h_offset_array_idx = (hPos / 3) * 3 + PADDING_LEFT;

        // organize samples into variable array defined in dsc spec
        c = prevLine[h_offset_array_idx-1]; // �� hPos=0, 1, 2, �� prevLine[-1]
        b = prevLine[h_offset_array_idx];   // �� hPos=0, 1, 2, �� prevLine[ 0]
        d = prevLine[h_offset_array_idx+1]; // �� hPos=0, 1, 2, �� prevLine[ 1]
        e = prevLine[h_offset_array_idx+2]; // �� hPos=0, 1, 2, �� prevLine[ 2]
        a = currLine[h_offset_array_idx-1]; // �� hPos=0, 1, 2, �� currLine[-1]

//ppp("     |05__018| <SamplePredict> g%d, currLine[%d]=%x \n", dsc_state->groupCount,h_offset_array_idx-1-5, currLine[h_offset_array_idx-1]);
        //**//
        //if (cpnt == 0)
        //        printf("%x\n", currLine[h_offset_array_idx - 1]);

#define FILT3(a,b,c) (((a)+2*(b)+(c)+2)>>2)
        filt_c = FILT3(prevLine[h_offset_array_idx-2], prevLine[h_offset_array_idx-1], prevLine[h_offset_array_idx  ]);
        filt_b = FILT3(prevLine[h_offset_array_idx-1], prevLine[h_offset_array_idx  ], prevLine[h_offset_array_idx+1]);
        filt_d = FILT3(prevLine[h_offset_array_idx  ], prevLine[h_offset_array_idx+1], prevLine[h_offset_array_idx+2]);
        filt_e = FILT3(prevLine[h_offset_array_idx+1], prevLine[h_offset_array_idx+2], prevLine[h_offset_array_idx+3]);

        //**//
        //printf("cpnt = %d, cpntbit=%d\n", cpnt,dsc_state->cpntBitDepth[cpnt]);
        //printf("hPos = %d, cpnt = %d , predType = %d\n", hPos,cpnt,predType);
        //**//

//ppp("     |05__019| <SamplePredict> g%d, c=%d \n", dsc_state->groupCount, c);
//ppp("     |05__020| <SamplePredict> g%d, b=%d \n", dsc_state->groupCount, b);
//ppp("     |05__021| <SamplePredict> g%d, d=%d \n", dsc_state->groupCount, d);
//ppp("     |05__022| <SamplePredict> g%d, e=%d \n", dsc_state->groupCount, e);
//ppp("     |05__023| <SamplePredict> g%d, a=%d \n", dsc_state->groupCount, a);

//ppp("     |05__024| <SamplePredict> g%d, filt_c=%d \n", dsc_state->groupCount, filt_c);
//ppp("     |05__025| <SamplePredict> g%d, filt_b=%d \n", dsc_state->groupCount, filt_b);
//ppp("     |05__026| <SamplePredict> g%d, filt_d=%d \n", dsc_state->groupCount, filt_d);
//ppp("     |05__027| <SamplePredict> g%d, filt_e=%d \n", dsc_state->groupCount, filt_e);

//ppp("     |05__028| <SamplePredict> g%d, predType=%d \n", dsc_state->groupCount, predType);

        switch (predType) {
        case PT_MAP/*0*/:    // MAP prediction
                // *MODEL NOTE* MN_MMAP
                diff = CLAMP(filt_c - c, -(QuantDivisor[qLevel]/2), QuantDivisor[qLevel]/2);
                blend_c_prev = c + diff;

  if(qLevel>100)
  {
//ppp("     |05__029| <SamplePredict> g%d, -(QuantDivisor[qLevel]/2)=%d, QuantDivisor[qLevel]/2=%d \n", dsc_state->groupCount, -(QuantDivisor[qLevel]/2), QuantDivisor[qLevel]/2);
//ppp("     |05__030| <SamplePredict> g%d, diff=%d, blend_c_prev=%d \n", dsc_state->groupCount, diff, blend_c_prev);
  }

                diff = CLAMP(filt_b - b, -(QuantDivisor[qLevel]/2), QuantDivisor[qLevel]/2);
                blend_b = b + diff;

  if(qLevel>100)
  {
//ppp("     |05__031| <SamplePredict> g%d, diff=%d, blend_b=%d \n", dsc_state->groupCount, diff, blend_b);
  }

                diff = CLAMP(filt_d - d, -(QuantDivisor[qLevel]/2), QuantDivisor[qLevel]/2);
                blend_d = d + diff;

  if(qLevel>100)
  {
//ppp("     |05__032| <SamplePredict> g%d, diff=%d, blend_d=%d \n", dsc_state->groupCount, diff, blend_d);
  }

                diff = CLAMP(filt_e - e, -(QuantDivisor[qLevel]/2), QuantDivisor[qLevel]/2);
                blend_e = e + diff;

  if(qLevel>100)
  {
//ppp("     |05__033| <SamplePredict> g%d, diff=%d, blend_e=%d \n", dsc_state->groupCount, diff, blend_e);
  }

                // Pixel on line above off the raster to the left gets same value as pixel below (ie., midpoint)
                if (hPos/SAMPLES_PER_UNIT == 0)
                        blend_c = a;
                else
                        blend_c = blend_c_prev;

  if(qLevel>100)
  {
//ppp("     |05__034| <SamplePredict> g%d, blend_c=%d \n", dsc_state->groupCount, blend_c);
  }

                if ((hPos % SAMPLES_PER_UNIT)==0)  // First pixel of group
                {

                        p = CLAMP(a + blend_b - blend_c, MIN(a, blend_b), MAX(a, blend_b));

//ppp("     |05__035| <SamplePredict> g%d, a+blend_b-blend_c=%d \n", dsc_state->groupCount, a + blend_b - blend_c);
//ppp("     |05__036| <SamplePredict> g%d, p=%d \n", dsc_state->groupCount, p);
//ppp("     |05__037| <SamplePredict> g%d, MIN(a, blend_b)=%d \n", dsc_state->groupCount, MIN(a, blend_b));
//ppp("     |05__038| <SamplePredict> g%d, MAX(a, blend_b)=%d \n", dsc_state->groupCount, MAX(a, blend_b));

                }
                else if ((hPos % SAMPLES_PER_UNIT)==1)   // Second pixel of group
                {
                        p = CLAMP(a + blend_d - blend_c + (dsc_state->quantizedResidual[cpnt][0] * QuantDivisor[qLevel]),
                                        MIN(MIN(a, blend_b), blend_d), MAX(MAX(a, blend_b), blend_d));

//ppp("     |05__039| <SamplePredict> g%d, a + blend_d - blend_c + qR[cpnt][0]*QD =%d \n", dsc_state->groupCount, a + blend_d - blend_c + (dsc_state->quantizedResidual[cpnt][0] * QuantDivisor[qLevel]));
//ppp("     |05__040| <SamplePredict> g%d, p=%d                             \n", dsc_state->groupCount, p                                          );
//ppp("     |05__041| <SamplePredict> g%d, a=%d                             \n", dsc_state->groupCount, a                                          );
//ppp("     |05__042| <SamplePredict> g%d, blend_d=%d                       \n", dsc_state->groupCount, blend_d                                    );
//ppp("     |05__043| <SamplePredict> g%d, blend_c=%d                       \n", dsc_state->groupCount, blend_c                                    );
//ppp("     |05__044| <SamplePredict> g%d, qR[cpnt][0]=%d                   \n", dsc_state->groupCount, dsc_state->quantizedResidual[cpnt][0]      );
//ppp("     |05__045| <SamplePredict> g%d, QuantDivisor[qLevel]=%d          \n", dsc_state->groupCount, QuantDivisor[qLevel]                       );
//ppp("     |05__046| <SamplePredict> g%d, MIN(MIN(a, blend_b), blend_d)=%d \n", dsc_state->groupCount, MIN(MIN(a, blend_b), blend_d)              );
//ppp("     |05__047| <SamplePredict> g%d, MAX(MAX(a, blend_b), blend_d)=%d \n", dsc_state->groupCount, MAX(MAX(a, blend_b), blend_d)              );

                }
                else    // Third pixel of group
                {
                        p = CLAMP(a + blend_e - blend_c + (dsc_state->quantizedResidual[cpnt][0] + dsc_state->quantizedResidual[cpnt][1])*QuantDivisor[qLevel],
                                                MIN(MIN(a,blend_b), MIN(blend_d, blend_e)), MAX(MAX(a,blend_b), MAX(blend_d, blend_e)));

//ppp("     |05__048| <SamplePredict> g%d, a + blend_e - blend_c + (qR[cpnt][0] + qR[cpnt][1])*QD =%d \n", dsc_state->groupCount, a + blend_e - blend_c + (dsc_state->quantizedResidual[cpnt][0] + dsc_state->quantizedResidual[cpnt][1])*QuantDivisor[qLevel]);
//ppp("     |05__049| <SamplePredict> g%d,  p=%d \n", dsc_state->groupCount,                                         p                                           );
//ppp("     |05__050| <SamplePredict> g%d,  a=%d \n", dsc_state->groupCount,                                         a                                           );
//ppp("     |05__051| <SamplePredict> g%d,  blend_e=%d \n", dsc_state->groupCount,                                   blend_e                                     );
//ppp("     |05__052| <SamplePredict> g%d,  blend_c=%d \n", dsc_state->groupCount,                                   blend_c                                     );
//ppp("     |05__053| <SamplePredict> g%d,  qR[cpnt][0]=%d \n", dsc_state->groupCount,                               dsc_state->quantizedResidual[cpnt][0]       );
//ppp("     |05__054| <SamplePredict> g%d,  qR[cpnt][1]=%d \n", dsc_state->groupCount,                               dsc_state->quantizedResidual[cpnt][1]       );
//ppp("     |05__055| <SamplePredict> g%d,  QuantDivisor[qLevel]=%d \n", dsc_state->groupCount,                      QuantDivisor[qLevel]                        );
//ppp("     |05__056| <SamplePredict> g%d,  MIN(MIN(a,blend_b), MIN(blend_d, blend_e))=%d \n", dsc_state->groupCount,MIN(MIN(a,blend_b), MIN(blend_d, blend_e))  );
//ppp("     |05__057| <SamplePredict> g%d,  MAX(MAX(a,blend_b), MAX(blend_d, blend_e))=%d \n", dsc_state->groupCount,MAX(MAX(a,blend_b), MAX(blend_d, blend_e))  );

                }
                break; ////////////////////////////////////////////////////////////////////////////////////////////

        case PT_LEFT/*1*/:
                p = a;    // First pixel of group
                if ((hPos % SAMPLES_PER_UNIT)==1)   // Second pixel of group
                {
                        p = CLAMP(a + (dsc_state->quantizedResidual[cpnt][0] * QuantDivisor[qLevel]), 0, (1<<dsc_state->cpntBitDepth[cpnt])-1);
//ppp("     |05__058| <SamplePredict> g%d, a + qR[cpnt][0]*QD=%d \n", dsc_state->groupCount, a + (dsc_state->quantizedResidual[cpnt][0] * QuantDivisor[qLevel]));
                }
                else if((hPos % SAMPLES_PER_UNIT)==2)  // Third pixel of group
                {
                        p = CLAMP(a + (dsc_state->quantizedResidual[cpnt][0] + dsc_state->quantizedResidual[cpnt][1])*QuantDivisor[qLevel], 0, (1<<dsc_state->cpntBitDepth[cpnt])-1);
//ppp("     |05__059| <SamplePredict> g%d, qR[%c][0]=%d \n", dsc_state->groupCount, c_cpnt, dsc_state->quantizedResidual[cpnt][0]  );
//ppp("     |05__060| <SamplePredict> g%d, qR[%c][1]=%d \n", dsc_state->groupCount, c_cpnt, dsc_state->quantizedResidual[cpnt][1]  );
//ppp("     |05__061| <SamplePredict> g%d, a+ (qR[cpnt][0]+qR[cpnt][1])*QD=%d \n", dsc_state->groupCount, a + (dsc_state->quantizedResidual[cpnt][0] + dsc_state->quantizedResidual[cpnt][1])*QuantDivisor[qLevel]);
                }

//ppp("     |05__062| <SamplePredict> g%d, p=%d \n", dsc_state->groupCount, p);
//ppp("     |05__063| <SamplePredict> g%d, a=%d \n", dsc_state->groupCount, a);
//ppp("     |05__064| <SamplePredict> g%d, qR[%c][0]=%d \n", dsc_state->groupCount, c_cpnt, dsc_state->quantizedResidual[cpnt][0]  );
//ppp("     |05__065| <SamplePredict> g%d, qR[%c][1]=%d \n", dsc_state->groupCount, c_cpnt, dsc_state->quantizedResidual[cpnt][1]  );
//ppp("     |05__066| <SamplePredict> g%d, QuantDivisor[qLevel]=%d \n", dsc_state->groupCount,                   QuantDivisor[qLevel]                 );
//ppp("     |05__067| <SamplePredict> g%d, (1<< dsc_state->cpntBitDepth[cpnt])-1=%d \n", dsc_state->groupCount,   (1<<dsc_state->cpntBitDepth[cpnt])-1 );

//ppp("     |05__068| <SamplePredict> g%d, QuantDivisor[qLevel]      =%x \n", dsc_state->groupCount, QuantDivisor[qLevel]                   );
                break; ////////////////////////////////////////////////////////////////////////////////////////////

        default:  // PT_BLOCK+ofs = BLOCK predictor, starts at -1
                // *MODEL NOTE* MN_BLOCK_PRED
                bp_offset = (int)predType - (int)PT_BLOCK/*2*/;
//ppp("     |05__069| <SamplePredict> g%d, bp_offset=%d \n", dsc_state->groupCount, bp_offset);
//ppp("     |05__070| <SamplePredict> g%d, predType=%d \n", dsc_state->groupCount,  (int)predType);

                p = currLine[MAX(hPos + PADDING_LEFT - 1 - bp_offset,0)];
//ppp("     |05__071| <SamplePredict> g%d, p=%d \n", dsc_state->groupCount, p);
                break; ////////////////////////////////////////////////////////////////////////////////////////////

        }

        return p;
}


// ======================================================================================== begin
//! Look up the pixel values for a given ICH index
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param entry     History index (0-31)
        \param p         Returned pixel value
        \param hPos      Horizontal position in slice (to determine upper pixels, if applicable)
        \param first_line_flag Set to 1 for first line (ie., disable upper pixels) */
void HistoryLookup(dsc_cfg_t *dsc_cfg, dsc_state_t* dsc_state, int entry, unsigned int *p, int hPos, int first_line_flag, int slicenum)
{
        int reserved;
        int hPos_center;
        int hPos_clamp;

        reserved = ICH_SIZE-ICH_PIXELS_ABOVE;

        hPos_center = (hPos/PIXELS_PER_GROUP)*PIXELS_PER_GROUP + (PIXELS_PER_GROUP/2);  // Center pixel of group as reference

        hPos_clamp = CLAMP(hPos_center, ICH_PIXELS_ABOVE/2, dsc_cfg->slice_width-1-(ICH_PIXELS_ABOVE/2));  // Keeps upper line history entries unique at left & right edge
//ppp("     |05__072| g%d, hPos_clamp=%d \n", dsc_state->groupCount, hPos_clamp);

        if (!first_line_flag && (entry >= reserved))
        {
                p[0] = dsc_state->prevLine[0][hPos_clamp+(entry-reserved)+PADDING_LEFT - (ICH_PIXELS_ABOVE/2)];
                p[1] = dsc_state->prevLine[1][hPos_clamp+(entry-reserved)+PADDING_LEFT - (ICH_PIXELS_ABOVE/2)];
                p[2] = dsc_state->prevLine[2][hPos_clamp+(entry-reserved)+PADDING_LEFT - (ICH_PIXELS_ABOVE/2)];
//ppp("     |05__073| g%d, prevLine[Y][%d]=%d \n", dsc_state->groupCount, hPos_clamp+(entry-reserved)+PADDING_LEFT-(ICH_PIXELS_ABOVE/2), dsc_state->prevLine[0][hPos_clamp+(entry-reserved)+PADDING_LEFT-(ICH_PIXELS_ABOVE/2)]);
//ppp("     |05__074| g%d, prevLine[U][%d]=%d \n", dsc_state->groupCount, hPos_clamp+(entry-reserved)+PADDING_LEFT-(ICH_PIXELS_ABOVE/2), dsc_state->prevLine[1][hPos_clamp+(entry-reserved)+PADDING_LEFT-(ICH_PIXELS_ABOVE/2)]);
//ppp("     |05__075| g%d, prevLine[V][%d]=%d \n", dsc_state->groupCount, hPos_clamp+(entry-reserved)+PADDING_LEFT-(ICH_PIXELS_ABOVE/2), dsc_state->prevLine[2][hPos_clamp+(entry-reserved)+PADDING_LEFT-(ICH_PIXELS_ABOVE/2)]);
        } else {
                p[0] = dsc_state->history.pixels[0][entry];
                p[1] = dsc_state->history.pixels[1][entry];
                p[2] = dsc_state->history.pixels[2][entry];
        }

}


// ======================================================================================== begin
//! Update the ICH state based on a reconstructed pixel
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param recon     A 3-element array containing the components of the reconstructed pixel */
void UpdateHistoryElement(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, unsigned int *recon, int slicenum)
{
        int hit, j;
        int loc;
        int cpnt;
        unsigned int ich_pixel[NUM_COMPONENTS];
        int reserved;

//ppp("     |05__076| # void UpdateHistoryElement \n");
        // *MODEL NOTE* MN_ICH_UPDATE

        reserved = (dsc_state->vPos==0) ? ICH_SIZE : (ICH_SIZE-ICH_PIXELS_ABOVE);  // space for UL, U, UR

        // Update the ICH with recon as the MRU
        hit = 0;
        loc = reserved-1;  // If no match, delete LRU

//ppp("     |05__077| <UPHE> g%d, vPos(grp)        = %d \n", dsc_state->groupCount, dsc_state->vPos);
//ppp("     |05__078| <UPHE> g%d, hPos(grp_end)    = %d \n", dsc_state->groupCount, dsc_state->hPos);
//ppp("     |05__079| <UPHE> g%d, loc              = %d \n", dsc_state->groupCount, loc                 );
        for (j=0; j<reserved; ++j)
        {
                if (!dsc_state->history.valid[j])  // Can replace any empty entry
                {
                        loc = j;
                        break; ////////////////////////////////////////////////////////////////////////////////////////////
                }

//ppp("     |05__080| <UPHE> g%d, dsc_state->hPos=%d\n", dsc_state->groupCount, dsc_state->hPos);
//ppp("     |05__081| <UPHE> g%d, ichSelected=%d\n", dsc_state->groupCount, dsc_state->ichSelected);
                HistoryLookup(dsc_cfg, dsc_state, j/*entry*/, ich_pixel/*p*/, dsc_state->hPos, (dsc_state->vPos==0)/*1st_line_flg*/, slicenum);  // Specific hPos within group is not critical
//ppp("     |05__082| <UPHE> g%d, ich_pixel[0]=%x \n", dsc_state->groupCount, ich_pixel[0]);
//ppp("     |05__083| <UPHE> g%d, ich_pixel[1]=%x \n", dsc_state->groupCount, ich_pixel[1]);
//ppp("     |05__084| <UPHE> g%d, ich_pixel[2]=%x \n", dsc_state->groupCount, ich_pixel[2]);
  // since hits against UL/U/UR don't have specific detection
                hit = 1;
                for (cpnt=0; cpnt<NUM_COMPONENTS; ++cpnt)
                {
                        if (ich_pixel[cpnt] != recon[cpnt])
                                hit = 0;

//ppp("     |05__085| <UPHE> g%d, cpnt=%d, ich_pixel[%d]=%x, recon[%d]=%x, hit=%d \n", dsc_state->groupCount, cpnt, cpnt, ich_pixel[cpnt], cpnt, recon[cpnt], hit);
                }

                if (hit && ((dsc_state->isEncoder && dsc_state->ichSelected) || (!dsc_state->isEncoder && dsc_state->prevIchSelected)))
                {
                        loc = j;

//ppp("     |05__086| # ****** FOR_UpdateHistoryElement BREAK1 ************ \n");
//ppp("     |05__087| # *************************************************** \n\n");
                        break;  // Found one ////////////////////////////////////////////////////////////////////////////////////////////
                }
//ppp("     |05__088| # ****** FOR_UpdateHistoryElement END *************** \n");
//ppp("     |05__089| # *************************************************** \n\n");
        }

//ppp("     |05__090| <UPHE> g%d, loc=%d \n", dsc_state->groupCount, loc);
        for (cpnt=0; cpnt<NUM_COMPONENTS; ++cpnt)
        {
                // Delete from current position (or delete LRU)
                for (j=loc; j>0; --j)
                {
                        dsc_state->history.pixels[cpnt][j] = dsc_state->history.pixels[cpnt][j-1];
                        dsc_state->history.valid[j] = dsc_state->history.valid[j-1];
                }

                // Insert as most recent
                dsc_state->history.pixels[cpnt][0] = recon[cpnt];
                dsc_state->history.valid[0] = 1;
        }
//ppp("     |05__091| <UPHE> g%d, history.pixels[cpnt=0][0]=%x \n", dsc_state->groupCount, dsc_state->history.pixels[0][0]);
//ppp("     |05__092| <UPHE> g%d, history.pixels[cpnt=1][0]=%x \n", dsc_state->groupCount, dsc_state->history.pixels[1][0]);
//ppp("     |05__093| <UPHE> g%d, history.pixels[cpnt=2][0]=%x \n", dsc_state->groupCount, dsc_state->history.pixels[2][0]);
}


// ======================================================================================== begin
//! Updates the IHC state using final reconstructed value
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param currLine  Reconstructed samples for current line
        \param sampModCnt Index of which pixel within group
        \param hPos      Horizontal position within slice (note that update uses pixels from one group prior)
        \param vPos      Vertical position within slice */
void UpdateICHistory(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int **currLine, int sampModCnt, int U_hPos, int vPos, int slicenum, FILE *gold_ICH)
{
        int i;
        int cpnt;
        unsigned int p[NUM_COMPONENTS];
        int hPos_prev_group;
        int dummy;

        if (ICH_BITS/*5*/==0)
                return;                 // Nothing to do if ICH disabled

        // Reset ICH at beginning of each line if multiple slices per line
        if (U_hPos==0)
        {
                if (vPos == 0)            // Beginning of slice
                {
                        for (i=0; i<ICH_SIZE; ++i)
                                dsc_state->history.valid[i] = 0;
//ppp("     |05__094| <UPICH> g%d, history.valid[31:0]=%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d \n", dsc_state->groupCount, dsc_state->history.valid[31], dsc_state->history.valid[30], dsc_state->history.valid[29], dsc_state->history.valid[28], dsc_state->history.valid[27], dsc_state->history.valid[26], dsc_state->history.valid[25], dsc_state->history.valid[24], dsc_state->history.valid[23], dsc_state->history.valid[22], dsc_state->history.valid[21], dsc_state->history.valid[20], dsc_state->history.valid[19], dsc_state->history.valid[18], dsc_state->history.valid[17], dsc_state->history.valid[16], dsc_state->history.valid[15], dsc_state->history.valid[14], dsc_state->history.valid[13], dsc_state->history.valid[12], dsc_state->history.valid[11], dsc_state->history.valid[10], dsc_state->history.valid[9], dsc_state->history.valid[8], dsc_state->history.valid[7], dsc_state->history.valid[6], dsc_state->history.valid[5], dsc_state->history.valid[4], dsc_state->history.valid[3], dsc_state->history.valid[2], dsc_state->history.valid[1], dsc_state->history.valid[0]);
                }
                else if (dsc_cfg->slice_width != dsc_cfg->pic_width)   // Multiple slices per line
                {
                        for (i=0; i<(ICH_SIZE - ICH_PIXELS_ABOVE); ++i)
                                dsc_state->history.valid[i] = 0;
//ppp("     |05__095| <UPICH> g%d, history.valid[31:0]=%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d \n", dsc_state->groupCount, dsc_state->history.valid[31], dsc_state->history.valid[30], dsc_state->history.valid[29], dsc_state->history.valid[28], dsc_state->history.valid[27], dsc_state->history.valid[26], dsc_state->history.valid[25], dsc_state->history.valid[24], dsc_state->history.valid[23], dsc_state->history.valid[22], dsc_state->history.valid[21], dsc_state->history.valid[20], dsc_state->history.valid[19], dsc_state->history.valid[18], dsc_state->history.valid[17], dsc_state->history.valid[16], dsc_state->history.valid[15], dsc_state->history.valid[14], dsc_state->history.valid[13], dsc_state->history.valid[12], dsc_state->history.valid[11], dsc_state->history.valid[10], dsc_state->history.valid[9], dsc_state->history.valid[8], dsc_state->history.valid[7], dsc_state->history.valid[6], dsc_state->history.valid[5], dsc_state->history.valid[4], dsc_state->history.valid[3], dsc_state->history.valid[2], dsc_state->history.valid[1], dsc_state->history.valid[0]);
                }
        }

//ppp("     |05__096| <UPICH> g%d, ICH_SIZE = %d \n", dsc_state->groupCount, ICH_SIZE);
//ppp("     |05__097| <UPICH> g%d, vPos = %d \n", dsc_state->groupCount, vPos);
//ppp("     |05__098| <UPICH> g%d, U_hPos = %d \n", dsc_state->groupCount, U_hPos);
//ppp("     |05__099| <UPICH> g%d, history.valid[31:0]=%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d \n", dsc_state->groupCount, dsc_state->history.valid[31], dsc_state->history.valid[30], dsc_state->history.valid[29], dsc_state->history.valid[28], dsc_state->history.valid[27], dsc_state->history.valid[26], dsc_state->history.valid[25], dsc_state->history.valid[24], dsc_state->history.valid[23], dsc_state->history.valid[22], dsc_state->history.valid[21], dsc_state->history.valid[20], dsc_state->history.valid[19], dsc_state->history.valid[18], dsc_state->history.valid[17], dsc_state->history.valid[16], dsc_state->history.valid[15], dsc_state->history.valid[14], dsc_state->history.valid[13], dsc_state->history.valid[12], dsc_state->history.valid[11], dsc_state->history.valid[10], dsc_state->history.valid[9], dsc_state->history.valid[8], dsc_state->history.valid[7], dsc_state->history.valid[6], dsc_state->history.valid[5], dsc_state->history.valid[4], dsc_state->history.valid[3], dsc_state->history.valid[2], dsc_state->history.valid[1], dsc_state->history.valid[0]);

        hPos_prev_group = U_hPos - PIXELS_PER_GROUP; // when U_hPos = 3,4,5
                                                     // ==> hPos_prev_group = 0,1,2

        if (hPos_prev_group < 0)
                return;                 // Current code doesn't update ICH for last group of each line -- probably not much correlation anyway

        // Get final reconstructed pixel value
        for (cpnt = 0; cpnt < NUM_COMPONENTS; ++cpnt) {
                p[cpnt] = currLine[cpnt][hPos_prev_group + PADDING_LEFT];  // when U_hPos=3,4,5, feeding-in pixels are
        }                                                                  // currLine[0,1,2], or say, recon_x 0~2

//ppp("     |05__100| <UPICH> g%d, p[Y][hPos=%d][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, hPos_prev_group, p[0], p[1], p[2]);

        // Update ICH accordingly
        UpdateHistoryElement(dsc_cfg, dsc_state, p/*recon*/, slicenum);
//ppp("     ----------------------------------------------------------- \n");
//ppp("     |05__101| <UPICH> g%d, h.valid[31:0]=%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d \n", dsc_state->groupCount, dsc_state->history.valid[31], dsc_state->history.valid[30], dsc_state->history.valid[29], dsc_state->history.valid[28], dsc_state->history.valid[27], dsc_state->history.valid[26], dsc_state->history.valid[25], dsc_state->history.valid[24], dsc_state->history.valid[23], dsc_state->history.valid[22], dsc_state->history.valid[21], dsc_state->history.valid[20], dsc_state->history.valid[19], dsc_state->history.valid[18], dsc_state->history.valid[17], dsc_state->history.valid[16], dsc_state->history.valid[15], dsc_state->history.valid[14], dsc_state->history.valid[13], dsc_state->history.valid[12], dsc_state->history.valid[11], dsc_state->history.valid[10], dsc_state->history.valid[9], dsc_state->history.valid[8], dsc_state->history.valid[7], dsc_state->history.valid[6], dsc_state->history.valid[5], dsc_state->history.valid[4], dsc_state->history.valid[3], dsc_state->history.valid[2], dsc_state->history.valid[1], dsc_state->history.valid[0]);
//ppp("     |05__102| <UPICH> g%d, vld=%d, history.pixels[00][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[0],  dsc_state->history.pixels[0][0] , dsc_state->history.pixels[1][0] , dsc_state->history.pixels[2][0] );
//ppp("     |05__103| <UPICH> g%d, vld=%d, history.pixels[01][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[1],  dsc_state->history.pixels[0][1] , dsc_state->history.pixels[1][1] , dsc_state->history.pixels[2][1] );
//ppp("     |05__104| <UPICH> g%d, vld=%d, history.pixels[02][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[2],  dsc_state->history.pixels[0][2] , dsc_state->history.pixels[1][2] , dsc_state->history.pixels[2][2] );
//ppp("     |05__105| <UPICH> g%d, vld=%d, history.pixels[03][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[3],  dsc_state->history.pixels[0][3] , dsc_state->history.pixels[1][3] , dsc_state->history.pixels[2][3] );
//ppp("     |05__106| <UPICH> g%d, vld=%d, history.pixels[04][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[4],  dsc_state->history.pixels[0][4] , dsc_state->history.pixels[1][4] , dsc_state->history.pixels[2][4] );
//ppp("     |05__107| <UPICH> g%d, vld=%d, history.pixels[05][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[5],  dsc_state->history.pixels[0][5] , dsc_state->history.pixels[1][5] , dsc_state->history.pixels[2][5] );
//ppp("     |05__108| <UPICH> g%d, vld=%d, history.pixels[06][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[6],  dsc_state->history.pixels[0][6] , dsc_state->history.pixels[1][6] , dsc_state->history.pixels[2][6] );
//ppp("     |05__109| <UPICH> g%d, vld=%d, history.pixels[07][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[7],  dsc_state->history.pixels[0][7] , dsc_state->history.pixels[1][7] , dsc_state->history.pixels[2][7] );
//ppp("     |05__110| <UPICH> g%d, vld=%d, history.pixels[08][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[8],  dsc_state->history.pixels[0][8] , dsc_state->history.pixels[1][8] , dsc_state->history.pixels[2][8] );
//ppp("     |05__111| <UPICH> g%d, vld=%d, history.pixels[09][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[9],  dsc_state->history.pixels[0][9] , dsc_state->history.pixels[1][9] , dsc_state->history.pixels[2][9] );
//ppp("     |05__112| <UPICH> g%d, vld=%d, history.pixels[10][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[10], dsc_state->history.pixels[0][10], dsc_state->history.pixels[1][10], dsc_state->history.pixels[2][10]);
//ppp("     |05__113| <UPICH> g%d, vld=%d, history.pixels[11][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[11], dsc_state->history.pixels[0][11], dsc_state->history.pixels[1][11], dsc_state->history.pixels[2][11]);
//ppp("     |05__114| <UPICH> g%d, vld=%d, history.pixels[12][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[12], dsc_state->history.pixels[0][12], dsc_state->history.pixels[1][12], dsc_state->history.pixels[2][12]);
//ppp("     |05__115| <UPICH> g%d, vld=%d, history.pixels[13][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[13], dsc_state->history.pixels[0][13], dsc_state->history.pixels[1][13], dsc_state->history.pixels[2][13]);
//ppp("     |05__116| <UPICH> g%d, vld=%d, history.pixels[14][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[14], dsc_state->history.pixels[0][14], dsc_state->history.pixels[1][14], dsc_state->history.pixels[2][14]);
//ppp("     |05__117| <UPICH> g%d, vld=%d, history.pixels[15][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[15], dsc_state->history.pixels[0][15], dsc_state->history.pixels[1][15], dsc_state->history.pixels[2][15]);
//ppp("     |05__118| <UPICH> g%d, vld=%d, history.pixels[16][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[16], dsc_state->history.pixels[0][16], dsc_state->history.pixels[1][16], dsc_state->history.pixels[2][16]);
//ppp("     |05__119| <UPICH> g%d, vld=%d, history.pixels[17][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[17], dsc_state->history.pixels[0][17], dsc_state->history.pixels[1][17], dsc_state->history.pixels[2][17]);
//ppp("     |05__120| <UPICH> g%d, vld=%d, history.pixels[18][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[18], dsc_state->history.pixels[0][18], dsc_state->history.pixels[1][18], dsc_state->history.pixels[2][18]);
//ppp("     |05__121| <UPICH> g%d, vld=%d, history.pixels[19][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[19], dsc_state->history.pixels[0][19], dsc_state->history.pixels[1][19], dsc_state->history.pixels[2][19]);
//ppp("     |05__122| <UPICH> g%d, vld=%d, history.pixels[20][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[20], dsc_state->history.pixels[0][20], dsc_state->history.pixels[1][20], dsc_state->history.pixels[2][20]);
//ppp("     |05__123| <UPICH> g%d, vld=%d, history.pixels[21][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[21], dsc_state->history.pixels[0][21], dsc_state->history.pixels[1][21], dsc_state->history.pixels[2][21]);
//ppp("     |05__124| <UPICH> g%d, vld=%d, history.pixels[22][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[22], dsc_state->history.pixels[0][22], dsc_state->history.pixels[1][22], dsc_state->history.pixels[2][22]);
//ppp("     |05__125| <UPICH> g%d, vld=%d, history.pixels[23][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[23], dsc_state->history.pixels[0][23], dsc_state->history.pixels[1][23], dsc_state->history.pixels[2][23]);
//ppp("     |05__126| <UPICH> g%d, vld=%d, history.pixels[24][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[24], dsc_state->history.pixels[0][24], dsc_state->history.pixels[1][24], dsc_state->history.pixels[2][24]);
//ppp("     |05__127| <UPICH> g%d, vld=%d, history.pixels[25][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[25], dsc_state->history.pixels[0][25], dsc_state->history.pixels[1][25], dsc_state->history.pixels[2][25]);
//ppp("     |05__128| <UPICH> g%d, vld=%d, history.pixels[26][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[26], dsc_state->history.pixels[0][26], dsc_state->history.pixels[1][26], dsc_state->history.pixels[2][26]);
//ppp("     |05__129| <UPICH> g%d, vld=%d, history.pixels[27][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[27], dsc_state->history.pixels[0][27], dsc_state->history.pixels[1][27], dsc_state->history.pixels[2][27]);
//ppp("     |05__130| <UPICH> g%d, vld=%d, history.pixels[28][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[28], dsc_state->history.pixels[0][28], dsc_state->history.pixels[1][28], dsc_state->history.pixels[2][28]);
//ppp("     |05__131| <UPICH> g%d, vld=%d, history.pixels[29][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[29], dsc_state->history.pixels[0][29], dsc_state->history.pixels[1][29], dsc_state->history.pixels[2][29]);
//ppp("     |05__132| <UPICH> g%d, vld=%d, history.pixels[30][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[30], dsc_state->history.pixels[0][30], dsc_state->history.pixels[1][30], dsc_state->history.pixels[2][30]);
//ppp("     |05__133| <UPICH> g%d, vld=%d, history.pixels[31][Y,U,V]=%d,%d,%d \n", dsc_state->groupCount, dsc_state->history.valid[31], dsc_state->history.pixels[0][31], dsc_state->history.pixels[1][31], dsc_state->history.pixels[2][31]);
  fppp(gold_ICH, "g%d,s%d,ICH.valid[31:0]=%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d_%d%d%d%d ", dsc_state->groupCount, slicenum, dsc_state->history.valid[31], dsc_state->history.valid[30], dsc_state->history.valid[29], dsc_state->history.valid[28], dsc_state->history.valid[27], dsc_state->history.valid[26], dsc_state->history.valid[25], dsc_state->history.valid[24], dsc_state->history.valid[23], dsc_state->history.valid[22], dsc_state->history.valid[21], dsc_state->history.valid[20], dsc_state->history.valid[19], dsc_state->history.valid[18], dsc_state->history.valid[17], dsc_state->history.valid[16], dsc_state->history.valid[15], dsc_state->history.valid[14], dsc_state->history.valid[13], dsc_state->history.valid[12], dsc_state->history.valid[11], dsc_state->history.valid[10], dsc_state->history.valid[9], dsc_state->history.valid[8], dsc_state->history.valid[7], dsc_state->history.valid[6], dsc_state->history.valid[5], dsc_state->history.valid[4], dsc_state->history.valid[3], dsc_state->history.valid[2], dsc_state->history.valid[1], dsc_state->history.valid[0]);
  fppp(gold_ICH, "p[Y,U,V]=%04d,%04d,%04d ", p[0], p[1], p[2]);
  if(dsc_state->history.valid[0]){
  fppp(gold_ICH, "[e00][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][0], dsc_state->history.pixels[1][0], dsc_state->history.pixels[2][0]);
  dummy=0;
  }
  if(dsc_state->history.valid[1]){
  fppp(gold_ICH, "[e01][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][1], dsc_state->history.pixels[1][1], dsc_state->history.pixels[2][1]);
  dummy=0;
  }
  if(dsc_state->history.valid[2]){
  fppp(gold_ICH, "[e02][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][2], dsc_state->history.pixels[1][2], dsc_state->history.pixels[2][2]);
  dummy=0;
  }
  if(dsc_state->history.valid[3]){
  fppp(gold_ICH, "[e03][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][3], dsc_state->history.pixels[1][3], dsc_state->history.pixels[2][3]);
  dummy=0;
  }
  if(dsc_state->history.valid[4]){
  fppp(gold_ICH, "[e04][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][4], dsc_state->history.pixels[1][4], dsc_state->history.pixels[2][4]);
  dummy=0;
  }
  if(dsc_state->history.valid[5]){
  fppp(gold_ICH, "[e05][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][5], dsc_state->history.pixels[1][5], dsc_state->history.pixels[2][5]);
  dummy=0;
  }
  if(dsc_state->history.valid[6]){
  fppp(gold_ICH, "[e06][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][6], dsc_state->history.pixels[1][6], dsc_state->history.pixels[2][6]);
  dummy=0;
  }
  if(dsc_state->history.valid[7]){
  fppp(gold_ICH, "[e07][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][7], dsc_state->history.pixels[1][7], dsc_state->history.pixels[2][7]);
  dummy=0;
  }
  if(dsc_state->history.valid[8]){
  fppp(gold_ICH, "[e08][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][8], dsc_state->history.pixels[1][8], dsc_state->history.pixels[2][8]);
  dummy=0;
  }
  if(dsc_state->history.valid[9]){
  fppp(gold_ICH, "[e09][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][9], dsc_state->history.pixels[1][9], dsc_state->history.pixels[2][9]);
  dummy=0;
  }
  if(dsc_state->history.valid[10]){
  fppp(gold_ICH, "[e10][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][10],dsc_state->history.pixels[1][10], dsc_state->history.pixels[2][10]);
  dummy=0;
  }
  if(dsc_state->history.valid[11]){
  fppp(gold_ICH, "[e11][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][11],dsc_state->history.pixels[1][11], dsc_state->history.pixels[2][11]);
  dummy=0;
  }
  if(dsc_state->history.valid[12]){
  fppp(gold_ICH, "[e12][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][12],dsc_state->history.pixels[1][12], dsc_state->history.pixels[2][12]);
  dummy=0;
  }
  if(dsc_state->history.valid[13]){
  fppp(gold_ICH, "[e13][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][13],dsc_state->history.pixels[1][13], dsc_state->history.pixels[2][13]);
  dummy=0;
  }
  if(dsc_state->history.valid[14]){
  fppp(gold_ICH, "[e14][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][14],dsc_state->history.pixels[1][14], dsc_state->history.pixels[2][14]);
  dummy=0;
  }
  if(dsc_state->history.valid[15]){
  fppp(gold_ICH, "[e15][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][15],dsc_state->history.pixels[1][15], dsc_state->history.pixels[2][15]);
  dummy=0;
  }
  if(dsc_state->history.valid[16]){
  fppp(gold_ICH, "[e16][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][16],dsc_state->history.pixels[1][16], dsc_state->history.pixels[2][16]);
  dummy=0;
  }
  if(dsc_state->history.valid[17]){
  fppp(gold_ICH, "[e17][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][17],dsc_state->history.pixels[1][17], dsc_state->history.pixels[2][17]);
  dummy=0;
  }
  if(dsc_state->history.valid[18]){
  fppp(gold_ICH, "[e18][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][18],dsc_state->history.pixels[1][18], dsc_state->history.pixels[2][18]);
  dummy=0;
  }
  if(dsc_state->history.valid[19]){
  fppp(gold_ICH, "[e19][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][19],dsc_state->history.pixels[1][19], dsc_state->history.pixels[2][19]);
  dummy=0;
  }
  if(dsc_state->history.valid[20]){
  fppp(gold_ICH, "[e20][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][20],dsc_state->history.pixels[1][20], dsc_state->history.pixels[2][20]);
  dummy=0;
  }
  if(dsc_state->history.valid[21]){
  fppp(gold_ICH, "[e21][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][21],dsc_state->history.pixels[1][21], dsc_state->history.pixels[2][21]);
  dummy=0;
  }
  if(dsc_state->history.valid[22]){
  fppp(gold_ICH, "[e22][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][22],dsc_state->history.pixels[1][22], dsc_state->history.pixels[2][22]);
  dummy=0;
  }
  if(dsc_state->history.valid[23]){
  fppp(gold_ICH, "[e23][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][23],dsc_state->history.pixels[1][23], dsc_state->history.pixels[2][23]);
  dummy=0;
  }
  if(dsc_state->history.valid[24]){
  fppp(gold_ICH, "[e24][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][24],dsc_state->history.pixels[1][24], dsc_state->history.pixels[2][24]);
  dummy=0;
  }
  if(dsc_state->history.valid[25]&&vPos==0){
  fppp(gold_ICH, "[e25][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][25],dsc_state->history.pixels[1][25], dsc_state->history.pixels[2][25]);
  dummy=0;
  }
  if(dsc_state->history.valid[26]&&vPos==0){
  fppp(gold_ICH, "[e26][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][26],dsc_state->history.pixels[1][26], dsc_state->history.pixels[2][26]);
  dummy=0;
  }
  if(dsc_state->history.valid[27]&&vPos==0){
  fppp(gold_ICH, "[e27][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][27],dsc_state->history.pixels[1][27], dsc_state->history.pixels[2][27]);
  dummy=0;
  }
  if(dsc_state->history.valid[28]&&vPos==0){
  fppp(gold_ICH, "[e28][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][28],dsc_state->history.pixels[1][28], dsc_state->history.pixels[2][28]);
  dummy=0;
  }
  if(dsc_state->history.valid[29]&&vPos==0){
  fppp(gold_ICH, "[e29][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][29],dsc_state->history.pixels[1][29], dsc_state->history.pixels[2][29]);
  dummy=0;
  }
  if(dsc_state->history.valid[30]&&vPos==0){
  fppp(gold_ICH, "[e30][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][30],dsc_state->history.pixels[1][30], dsc_state->history.pixels[2][30]);
  dummy=0;
  }
  if(dsc_state->history.valid[31]&&vPos==0){
  fppp(gold_ICH, "[e31][Y,U,V]=%d,%d,%d ", dsc_state->history.pixels[0][31],dsc_state->history.pixels[1][31], dsc_state->history.pixels[2][31]);
  dummy=0;
  }
  fppp(gold_ICH, "\n");
}

// ======================================================================================== begin
//! Returns midpoint prediction predictor
/*! \param dsc_state DSC state structure
        \param cpnt      Component index
        \param qlevel    Current quantization level */
int FindMidpoint(dsc_state_t *dsc_state, int cpnt, int qlevel, int slicenum)
{
        int range;
        char c_cpnt;

        if(cpnt==0) c_cpnt='Y'; else if(cpnt==1) c_cpnt='U'; else c_cpnt='V';

        // *MODEL NOTE* MN_MIDPOINT_PRED
        range = 1<<dsc_state->cpntBitDepth[cpnt];

//ppp("     |05__134| g%d, range=%d \n", dsc_state->groupCount, range);

//ppp("     |05__135| g%d, range/2=%d \n", dsc_state->groupCount, range/2);
//ppp("     |05__136| g%d, leftRecon[%c] =%d \n", dsc_state->groupCount, c_cpnt, dsc_state->leftRecon[cpnt]);
//ppp("     |05__137| g%d, 1 < < qlevel =%d \n", dsc_state->groupCount, 1<<qlevel);

        return (range/2 + (dsc_state->leftRecon[cpnt]%(1<<qlevel)));
}


// ======================================================================================== begin
//! Function to decide block vs. MAP & which block prediction vector to use for the next line
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param cpnt      Component index
        \param currLine  Current line's reconstructed samples
        \param hPos      Horizontal position in slice
        \param recon_x   Current reconstructed sample value */
void BlockPredSearch_Y(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int **currLine, int mod_hPos, int B_recon_x, int B_recon_x_prev, int slicenum)
{
        int i, j;
        int candidate_vector;  // a value of 0 maps to -1, 2 maps to -3, etc.
        int B_pred_x;
        int new_B_pred_x;
        int pixel_mod_cnt;
        int cursamp;
        int pixdiff_pre;
        int pixdiff;
        int pixdiff2_pre;
        int pixdiff2;
        int modified_abs_diff;
        int new_B_recon_x;
        int Y = 0, U = 1, V = 2;

        //printf("mod_hPos = %d , cpnt = %d , predType = %d\n", mod_hPos, cpnt, dsc_state->prevLinePred[mod_hPos / PRED_BLK_SIZE]);
        // This function runs right after a reconstructed value is determined and computes the best predictor to use for the NEXT line.
        // An implementation could run the block prediction search at any time after that up until the point at which the selection is needed.
        // *MODEL NOTE* MN_BP_SEARCH

        if (mod_hPos == 0)
        {
                // Reset prediction accumulators every line
                dsc_state->bpCount = 0;

                for (i=0; i<NUM_COMPONENTS; ++i)
                {
                        for (j=0; j<BP_SIZE/*3*/; ++j)
                        {
                                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                                        dsc_state->lastErr[i/*cpnt*/][j/*BP_SIZE*/][candidate_vector] = 0;
                        }
                }
        }

        // Last edge count check - looks at absolute differences between adjacent pixels
        //   - Don't use block prediction if the content is basically flat
        pixdiff_pre = SampToLineBuf(dsc_cfg, dsc_state, B_recon_x/*x*/, Y/*cpnt*/, slicenum) -
                      SampToLineBuf(dsc_cfg, dsc_state, B_recon_x_prev, Y/*cpnt*/, slicenum);

//ppp("     |05__138| mod_hPos=%d, <BlockPredSearch_Y> B_recon_x=%d\n", mod_hPos, B_recon_x);
//ppp("     |05__139| mod_hPos=%d, <BlockPredSearch_Y> B_recon_x_prev=%d\n", mod_hPos, B_recon_x_prev);

        pixdiff = ABS(pixdiff_pre);

//ppp("     |05__140| mod_hPos=%d, <BlockPredSearch_Y> pixdiff=%d\n", mod_hPos, pixdiff);

        dsc_state->edgeDetected = 0;

        if (pixdiff > (BP_EDGE_STRENGTH << (dsc_cfg->bits_per_component-8)))
        {
                dsc_state->edgeDetected = 1;
//ppp("     |05__141| mod_hPos=%d, <BlockPredSearch_Y> edgeDetected in Y=1\n", mod_hPos);
        }
        else
        {
                dsc_state->edgeDetected = dsc_state->edgeDetected;
//ppp("     |05__142| mod_hPos=%d, <BlockPredSearch_Y> edgeDetected in Y=0\n", mod_hPos);
        }

        // The BP
        cursamp = (mod_hPos/PRED_BLK_SIZE/*3*/) % BP_SIZE/*3*/;

//ppp("     |05__143| mod_hPos=%d, <BlockPredSearch_Y> cursamp=%d\n", mod_hPos, cursamp);

        pixel_mod_cnt = mod_hPos % PRED_BLK_SIZE/*3*/;

//ppp("     |05__144| mod_hPos=%d, <BlockPredSearch_Y> pixel_mod_cnt=%d\n", mod_hPos, pixel_mod_cnt);

        for ( candidate_vector=0; candidate_vector<BP_RANGE/*10*/; candidate_vector++ )
        {
                if ( pixel_mod_cnt == 0 ) {                     // predErr is summed over PRED_BLK_SIZE pixels
                        dsc_state->predErr[Y][candidate_vector] = 0;
                }

                B_pred_x = currLine[Y][MAX(mod_hPos + PADDING_LEFT - 1 - candidate_vector, 0)];


                // HW uses previous line's reconstructed samples, which may be bit-reduced
                new_B_pred_x  = SampToLineBuf(dsc_cfg, dsc_state, B_pred_x/*x*/ , Y/*cpnt*/, slicenum);
                new_B_recon_x = SampToLineBuf(dsc_cfg, dsc_state, B_recon_x/*x*/, Y/*cpnt*/, slicenum);

//ppp("     |05__145| mod_hPos=%d, <BlockPredSearch_Y> new_B_pred_x=%x\n", mod_hPos, new_B_pred_x);
//ppp("     |05__146| mod_hPos=%d, <BlockPredSearch_Y> new_B_recon_x=%x\n", mod_hPos, new_B_recon_x);

                pixdiff2_pre = new_B_recon_x - new_B_pred_x;
                pixdiff2 = ABS(pixdiff2_pre);
                modified_abs_diff = MIN(pixdiff2>>(dsc_state->cpntBitDepth[Y] - 7), 0x3f);

//ppp("     |05__147| mod_hPos=%d, <BlockPredSearch_Y> mad[%d]=%d\n", mod_hPos, candidate_vector, modified_abs_diff);

                //printf("%x\n", modified_abs_diff);                                                            //
                // ABS differences are clamped to 6 bits each, predErr for 3 pixels is 8 bits                   //
                dsc_state->predErr[Y][candidate_vector] += modified_abs_diff;                                   //

//ppp("     |05__148| mod_hPos=%d, <BlockPredSearch_Y> dsc_state->predErr[Y][%d]=%d\n", mod_hPos, candidate_vector, dsc_state->predErr[Y][candidate_vector]);

        } // for END


//ppp("     |05__149| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][0]=%d \n", mod_hPos, dsc_state->predErr[0][0]);
//ppp("     |05__150| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][1]=%d \n", mod_hPos, dsc_state->predErr[0][1]);
//ppp("     |05__151| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][2]=%d \n", mod_hPos, dsc_state->predErr[0][2]);
//ppp("     |05__152| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][3]=%d \n", mod_hPos, dsc_state->predErr[0][3]);
//ppp("     |05__153| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][4]=%d \n", mod_hPos, dsc_state->predErr[0][4]);
//ppp("     |05__154| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][5]=%d \n", mod_hPos, dsc_state->predErr[0][5]);
//ppp("     |05__155| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][6]=%d \n", mod_hPos, dsc_state->predErr[0][6]);
//ppp("     |05__156| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][7]=%d \n", mod_hPos, dsc_state->predErr[0][7]);
//ppp("     |05__157| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][8]=%d \n", mod_hPos, dsc_state->predErr[0][8]);
//ppp("     |05__158| mod_hPos=%d, <BlockPredSearch_Y> predErr[Y][9]=%d \n", mod_hPos, dsc_state->predErr[0][9]);

        if ( pixel_mod_cnt == PRED_BLK_SIZE/*3*/ - 1 )
        {
                // Track last 3 3-pixel SADs for each component (each is 7 bit)
                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                {
                        dsc_state->lastErr[Y][cursamp][candidate_vector] = dsc_state->predErr[Y][candidate_vector];
//ppp("     |05__159| mod_hPos=%d, <BlockPredSearch_Y> lastErr[Y][%d][%d]=%d\n", mod_hPos, cursamp, candidate_vector, dsc_state->lastErr[Y][cursamp][candidate_vector]);
//ppp("mod_hPos=%d,lastErr[Y][%d][%d]=%d\n", mod_hPos, cursamp, candidate_vector, dsc_state->lastErr[Y][cursamp][candidate_vector]);
                }

        }

}

void BlockPredSearch_U(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int **currLine, int mod_hPos, int B_recon_x, int B_recon_x_prev, int slicenum)
{
        int i, j;
        int candidate_vector;  // a value of 0 maps to -1, 2 maps to -3, etc.
        int B_pred_x;
        int new_B_pred_x;
        int pixel_mod_cnt;
        int cursamp;
        int pixdiff_pre;
        int pixdiff;
        int pixdiff2_pre;
        int pixdiff2;
        int modified_abs_diff;
        int new_B_recon_x;
        int Y = 0, U = 1, V = 2;

        //printf("mod_hPos = %d , cpnt = %d , predType = %d\n", mod_hPos, cpnt, dsc_state->prevLinePred[mod_hPos / PRED_BLK_SIZE]);
        // This function runs right after a reconstructed value is determined and computes the best predictor to use for the NEXT line.
        // An implementation could run the block prediction search at any time after that up until the point at which the selection is needed.
        // *MODEL NOTE* MN_BP_SEARCH


        if (mod_hPos == 0)
        {
                // Reset prediction accumulators every line
                dsc_state->bpCount = 0;

                for (i=0; i<NUM_COMPONENTS; ++i)
                {
                        for (j=0; j<BP_SIZE/*3*/; ++j)
                        {
                                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                                        dsc_state->lastErr[i][j][candidate_vector] = 0;
                        }
                }
        }

        // Last edge count check - looks at absolute differences between adjacent pixels
        //   - Don't use block prediction if the content is basically flat
        pixdiff_pre = SampToLineBuf(dsc_cfg, dsc_state, B_recon_x/*x*/, U/*cpnt*/, slicenum) -
                      SampToLineBuf(dsc_cfg, dsc_state, B_recon_x_prev, U/*cpnt*/, slicenum);

//ppp("     |05__160| mod_hPos=%d, <BlockPredSearch_U> B_recon_x=%d\n", mod_hPos, B_recon_x);
//ppp("     |05__161| mod_hPos=%d, <BlockPredSearch_U> B_recon_x_prev=%d\n", mod_hPos, B_recon_x_prev);

        pixdiff = ABS(pixdiff_pre);

//ppp("     |05__162| mod_hPos=%d, <BlockPredSearch_U> pixdiff=%d\n", mod_hPos, pixdiff);

        if (pixdiff > (BP_EDGE_STRENGTH << (dsc_cfg->bits_per_component-8)))
        {
                dsc_state->edgeDetected = 1;
//ppp("     |05__163| mod_hPos=%d, <BlockPredSearch_U> edgeDetected in U=1\n", mod_hPos);
        }
        else
        {
                dsc_state->edgeDetected = dsc_state->edgeDetected;
//ppp("     |05__164| mod_hPos=%d, <BlockPredSearch_U> edgeDetected in U=0\n", mod_hPos);
        }

        // The BP
        cursamp = (mod_hPos/PRED_BLK_SIZE/*3*/) % BP_SIZE/*3*/;

//ppp("     |05__165| mod_hPos=%d, <BlockPredSearch_U> cursamp=%d\n", mod_hPos, cursamp);

        pixel_mod_cnt = mod_hPos % PRED_BLK_SIZE/*3*/;

//ppp("     |05__166| mod_hPos=%d, <BlockPredSearch_U> pixel_mod_cnt=%d\n", mod_hPos, pixel_mod_cnt);

        for ( candidate_vector=0; candidate_vector<BP_RANGE/*10*/; candidate_vector++ )
        {
                if ( pixel_mod_cnt == 0 ) {                     // predErr is summed over PRED_BLK_SIZE pixels
                        dsc_state->predErr[U][candidate_vector] = 0;
                }

                B_pred_x = currLine[U][MAX(mod_hPos + PADDING_LEFT - 1 - candidate_vector, 0)];


                // HW uses previous line's reconstructed samples, which may be bit-reduced
                new_B_pred_x  = SampToLineBuf(dsc_cfg, dsc_state, B_pred_x/*x*/ , U/*cpnt*/, slicenum);
                new_B_recon_x = SampToLineBuf(dsc_cfg, dsc_state, B_recon_x/*x*/, U/*cpnt*/, slicenum);

//ppp("     |05__167| mod_hPos=%d, <BlockPredSearch_U> new_B_pred_x=%d\n", mod_hPos, new_B_pred_x);
//ppp("     |05__168| mod_hPos=%d, <BlockPredSearch_U> new_B_recon_x=%d\n", mod_hPos, new_B_recon_x);

                pixdiff2_pre = new_B_recon_x - new_B_pred_x;
                pixdiff2 = ABS(pixdiff2_pre);

//ppp("     |05__169| mod_hPos=%d, <BlockPredSearch_U> pixdiff2=%d\n", mod_hPos, pixdiff2);

                modified_abs_diff = MIN(pixdiff2>>(dsc_state->cpntBitDepth[U] - 7), 0x3f);

//ppp("     |05__170| mod_hPos=%d, <BlockPredSearch_U> mad[%d]=%d\n", mod_hPos, candidate_vector, modified_abs_diff);

                //printf("%x\n", modified_abs_diff);                                                            //
                // ABS differences are clamped to 6 bits each, predErr for 3 pixels is 8 bits                   //
                dsc_state->predErr[U][candidate_vector] += modified_abs_diff;                                   //

//ppp("     |05__171| mod_hPos=%d, <BlockPredSearch_U> dsc_state->predErr[U][%d]=%d\n", mod_hPos, candidate_vector, dsc_state->predErr[U][candidate_vector]);

        } // for END


//ppp("     |05__172| mod_hPos=%d, <BlockPredSearch_U> predErr[U][0]=%d \n", mod_hPos, dsc_state->predErr[1][0]);
//ppp("     |05__173| mod_hPos=%d, <BlockPredSearch_U> predErr[U][1]=%d \n", mod_hPos, dsc_state->predErr[1][1]);
//ppp("     |05__174| mod_hPos=%d, <BlockPredSearch_U> predErr[U][2]=%d \n", mod_hPos, dsc_state->predErr[1][2]);
//ppp("     |05__175| mod_hPos=%d, <BlockPredSearch_U> predErr[U][3]=%d \n", mod_hPos, dsc_state->predErr[1][3]);
//ppp("     |05__176| mod_hPos=%d, <BlockPredSearch_U> predErr[U][4]=%d \n", mod_hPos, dsc_state->predErr[1][4]);
//ppp("     |05__177| mod_hPos=%d, <BlockPredSearch_U> predErr[U][5]=%d \n", mod_hPos, dsc_state->predErr[1][5]);
//ppp("     |05__178| mod_hPos=%d, <BlockPredSearch_U> predErr[U][6]=%d \n", mod_hPos, dsc_state->predErr[1][6]);
//ppp("     |05__179| mod_hPos=%d, <BlockPredSearch_U> predErr[U][7]=%d \n", mod_hPos, dsc_state->predErr[1][7]);
//ppp("     |05__180| mod_hPos=%d, <BlockPredSearch_U> predErr[U][8]=%d \n", mod_hPos, dsc_state->predErr[1][8]);
//ppp("     |05__181| mod_hPos=%d, <BlockPredSearch_U> predErr[U][9]=%d \n", mod_hPos, dsc_state->predErr[1][9]);

        if ( pixel_mod_cnt == PRED_BLK_SIZE/*3*/ - 1 )
        {
                // Track last 3 3-pixel SADs for each component (each is 7 bit)
                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                {
                        dsc_state->lastErr[U][cursamp][candidate_vector] = dsc_state->predErr[U][candidate_vector];
//ppp("     |05__182| mod_hPos=%d, <BlockPredSearch_U> lastErr[U][%d][%d]=%d\n", mod_hPos, cursamp, candidate_vector, dsc_state->lastErr[U][cursamp][candidate_vector]);
//ppp("mod_hPos=%d,lastErr[U][%d][%d]=%d\n", mod_hPos, cursamp, candidate_vector, dsc_state->lastErr[U][cursamp][candidate_vector]);
                }

        }

}

void BlockPredSearch_V(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int **currLine, int mod_hPos, int B_recon_x, int B_recon_x_prev, int slicenum)
{
        int i, j;
        int candidate_vector;  // a value of 0 maps to -1, 2 maps to -3, etc.
        int B_pred_x;
        int new_B_pred_x;
        int pixel_mod_cnt;
        int min_err;
        PRED_TYPE min_pred;
        int cursamp;
        int pixdiff_pre;
        int pixdiff;
        int pixdiff2_pre;
        int pixdiff2;
        int bp_sads[BP_RANGE/*10*/];
        int modified_abs_diff;
        int new_B_recon_x;
        int Y = 0, U = 1, V = 2;

//      FILE *lastedgecountlog = fopen("lastEdgeCount_golden.txt","w");
//      FILE *lasterrlog = fopen("lastErr_golden.txt","w");

        //printf("mod_hPos = %d , cpnt = %d , predType = %d\n", mod_hPos, cpnt, dsc_state->prevLinePred[mod_hPos / PRED_BLK_SIZE]);
        // This function runs right after a reconstructed value is determined and computes the best predictor to use for the NEXT line.
        // An implementation could run the block prediction search at any time after that up until the point at which the selection is needed.
        // *MODEL NOTE* MN_BP_SEARCH

        if (mod_hPos == 0)
        {
                // Reset prediction accumulators every line
                dsc_state->bpCount = 0;
                dsc_state->lastEdgeCount = 10;  // Arbitrary large value as initial condition
                for (i=0; i<NUM_COMPONENTS; ++i)
                {
                        for (j=0; j<BP_SIZE/*3*/; ++j)
                        {
                                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                                        dsc_state->lastErr[i][j][candidate_vector] = 0;
                        }
                }
        }

        // Last edge count check - looks at absolute differences between adjacent pixels
        //   - Don't use block prediction if the content is basically flat
        pixdiff_pre = SampToLineBuf(dsc_cfg, dsc_state, B_recon_x/*x*/, V/*cpnt*/, slicenum) -
                      SampToLineBuf(dsc_cfg, dsc_state, B_recon_x_prev, V/*cpnt*/, slicenum);

//ppp("     |05__183| mod_hPos=%d, <BlockPredSearch_V> B_recon_x=%d\n", mod_hPos, B_recon_x);
//ppp("     |05__184| mod_hPos=%d, <BlockPredSearch_V> B_recon_x_prev=%d\n", mod_hPos, B_recon_x_prev);

        pixdiff = ABS(pixdiff_pre);

//ppp("     |05__185| mod_hPos=%d, <BlockPredSearch_V> pixdiff=%d\n", mod_hPos, pixdiff);

        if (pixdiff > (BP_EDGE_STRENGTH << (dsc_cfg->bits_per_component-8)))
        {
                dsc_state->edgeDetected = 1;
//ppp("     |05__186| mod_hPos=%d, <BlockPredSearch_V> edgeDetected in V=1\n", mod_hPos);
        }
        else
        {
                dsc_state->edgeDetected = dsc_state->edgeDetected;
//ppp("     |05__187| mod_hPos=%d, <BlockPredSearch_V> edgeDetected in V=0\n", mod_hPos);
        }

//ppp("     |05__188| mod_hPos=%d, <BlockPredSearch_V> edgeDetected=%d\n", mod_hPos, dsc_state->edgeDetected);

        if (dsc_state->edgeDetected)
                dsc_state->lastEdgeCount = 0;
        else
                dsc_state->lastEdgeCount++;

//ppp("     |05__189| mod_hPos=%d, <BlockPredSearch_V> lastEdgeCount=%d\n", mod_hPos, dsc_state->lastEdgeCount);
//ppp("mod_hPos=%d,lastEdgeCount=%d\n", mod_hPos, dsc_state->lastEdgeCount);

        // The BP
        cursamp = (mod_hPos/PRED_BLK_SIZE/*3*/) % BP_SIZE/*3*/;

//ppp("     |05__190| mod_hPos=%d, <BlockPredSearch_V> cursamp=%d\n", mod_hPos, cursamp);

        pixel_mod_cnt = mod_hPos % PRED_BLK_SIZE/*3*/;



        for ( candidate_vector=0; candidate_vector<BP_RANGE/*10*/; candidate_vector++ )
        {
                if ( pixel_mod_cnt == 0 ) {                     // predErr is summed over PRED_BLK_SIZE pixels
                        dsc_state->predErr[V][candidate_vector] = 0;
                }

                B_pred_x = currLine[V][MAX(mod_hPos + PADDING_LEFT - 1 - candidate_vector, 0)];


                // HW uses previous line's reconstructed samples, which may be bit-reduced
                new_B_pred_x  = SampToLineBuf(dsc_cfg, dsc_state, B_pred_x/*x*/ , V/*cpnt*/, slicenum);
                new_B_recon_x = SampToLineBuf(dsc_cfg, dsc_state, B_recon_x/*x*/, V/*cpnt*/, slicenum);

//ppp("     |05__191| mod_hPos=%d, <BlockPredSearch_V> new_B_pred_x=%d\n", mod_hPos, new_B_pred_x);
//ppp("     |05__192| mod_hPos=%d, <BlockPredSearch_V> new_B_recon_x=%d\n", mod_hPos, new_B_recon_x);

                pixdiff2_pre = new_B_recon_x - new_B_pred_x;
                pixdiff2 = ABS(pixdiff2_pre);
                modified_abs_diff = MIN(pixdiff2>>(dsc_state->cpntBitDepth[V] - 7), 0x3f);

//ppp("     |05__193| mod_hPos=%d, <BlockPredSearch_V> mad[%d]=%d\n", mod_hPos, candidate_vector, modified_abs_diff);

                //printf("%x\n", modified_abs_diff);                                                            //
                // ABS differences are clamped to 6 bits each, predErr for 3 pixels is 8 bits                   //
                dsc_state->predErr[V][candidate_vector] += modified_abs_diff;                                   //

//ppp("     |05__194| mod_hPos=%d, <BlockPredSearch_V> dsc_state->predErr[V][%d]=%d\n", mod_hPos, candidate_vector, dsc_state->predErr[V][candidate_vector]);

        } // for END


//ppp("     |05__195| mod_hPos=%d, <BlockPredSearch_V> predErr[V][0]=%d \n", mod_hPos, dsc_state->predErr[2][0]);
//ppp("     |05__196| mod_hPos=%d, <BlockPredSearch_V> predErr[V][1]=%d \n", mod_hPos, dsc_state->predErr[2][1]);
//ppp("     |05__197| mod_hPos=%d, <BlockPredSearch_V> predErr[V][2]=%d \n", mod_hPos, dsc_state->predErr[2][2]);
//ppp("     |05__198| mod_hPos=%d, <BlockPredSearch_V> predErr[V][3]=%d \n", mod_hPos, dsc_state->predErr[2][3]);
//ppp("     |05__199| mod_hPos=%d, <BlockPredSearch_V> predErr[V][4]=%d \n", mod_hPos, dsc_state->predErr[2][4]);
//ppp("     |05__200| mod_hPos=%d, <BlockPredSearch_V> predErr[V][5]=%d \n", mod_hPos, dsc_state->predErr[2][5]);
//ppp("     |05__201| mod_hPos=%d, <BlockPredSearch_V> predErr[V][6]=%d \n", mod_hPos, dsc_state->predErr[2][6]);
//ppp("     |05__202| mod_hPos=%d, <BlockPredSearch_V> predErr[V][7]=%d \n", mod_hPos, dsc_state->predErr[2][7]);
//ppp("     |05__203| mod_hPos=%d, <BlockPredSearch_V> predErr[V][8]=%d \n", mod_hPos, dsc_state->predErr[2][8]);
//ppp("     |05__204| mod_hPos=%d, <BlockPredSearch_V> predErr[V][9]=%d \n", mod_hPos, dsc_state->predErr[2][9]);

        if ( pixel_mod_cnt == PRED_BLK_SIZE/*3*/ - 1 )  // only a complete 3-pixel group counts
        {
                // Track last 3 3-pixel SADs for each component (each is 7 bit)
                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                {
                        dsc_state->lastErr[V][cursamp][candidate_vector] = dsc_state->predErr[V][candidate_vector];
//ppp("     |05__205| mod_hPos=%d, <BlockPredSearch_V> lastErr[V][%d][%d]=%d\n", mod_hPos, cursamp, candidate_vector, dsc_state->lastErr[V][cursamp][candidate_vector]);
//ppp("mod_hPos=%d,lastErr[V][%d][%d]=%d\n", mod_hPos, cursamp, candidate_vector, dsc_state->lastErr[V][cursamp][candidate_vector]);
                }


                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                {
                        bp_sads[candidate_vector] = 0;

                        for (i=0; i<BP_SIZE/*3*/; ++i)
                        {
                                int sad3x1 = 0;

                                // Use all 3 components
                                for(j=0; j<NUM_COMPONENTS; ++j)
                                         sad3x1 += dsc_state->lastErr[j][i][candidate_vector];
                                // sad3x1 is 9 bits
                                sad3x1 = MIN(511, sad3x1);

                                //printf("i = %d , sad3x1 %x\n" ,i, sad3x1);

                                bp_sads[candidate_vector] += sad3x1;  // 11-bit SAD
                        }
                        // Each bp_sad can have a max value of 63*9 pixels * 3 components = 1701 or 11 bits
                        bp_sads[candidate_vector] >>= 3;  // SAD is truncated to 8-bit for comparison
                        //**//
                        //printf("hpos = %d,%x\n", mod_hPos,bp_sads[candidate_vector]);

//ppp("     |05__206| mod_hPos=%d, <BlockPredSearch_V> bp_sads[%d]=%d\n", mod_hPos, candidate_vector, bp_sads[candidate_vector]);
                }

                min_err = 1000000;
                min_pred = PT_MAP/*0*/;
                for (candidate_vector=0; candidate_vector<BP_RANGE/*10*/; ++candidate_vector)
                {
                        //printf("%d\n", candidate_vector);
                        if (candidate_vector==1)
                                continue;           // Can't use -2 vector  //why?
                        // Ties favor smallest vector
                        if (min_err > bp_sads[candidate_vector])
                        {
                                min_err = bp_sads[candidate_vector];
                                min_pred = (PRED_TYPE)(candidate_vector+PT_BLOCK/*2*/);
                        }
                }

//ppp("     |05__207| mod_hPos=%d, <BlockPredSearch_V> min_err=%d\n", mod_hPos, min_err);
//ppp("     |05__208| mod_hPos=%d, <BlockPredSearch_V> min_pred=%d\n", mod_hPos, min_pred);

                //printf("%d\n", dsc_cfg->block_pred_enable);  all 1
                if (dsc_cfg->block_pred_enable && (mod_hPos>=9))  // Don't start algorithm until 10th pixel
                {
                        if (min_pred > PT_BLOCK/*2*/)
                                dsc_state->bpCount++;
                        else
                                dsc_state->bpCount = 0;
                }

//ppp("     |05__209| mod_hPos=%d, <BlockPredSearch_V> bpCount=%d\n", mod_hPos, dsc_state->bpCount);

                if ((dsc_state->bpCount>=3) && (dsc_state->lastEdgeCount < BP_EDGE_COUNT))
                {
                        dsc_state->prevLinePred[mod_hPos/PRED_BLK_SIZE/*3*/] = (PRED_TYPE)min_pred;/*0~11*/         //
//ppp("     |05__210| mod_hPos=%d, <BlockPredSearch_V> prevLinePred[%d]=%d \n", mod_hPos, mod_hPos/PRED_BLK_SIZE, dsc_state->prevLinePred[mod_hPos/PRED_BLK_SIZE]);
                }
                else
                {
                        dsc_state->prevLinePred[mod_hPos/PRED_BLK_SIZE/*3*/] = (PRED_TYPE)PT_MAP/*0*/;
//ppp("     |05__211| mod_hPos=%d, <BlockPredSearch_V> prevLinePred[%d]=%d \n", mod_hPos, mod_hPos/PRED_BLK_SIZE, (PRED_TYPE)PT_MAP);
  ppp("g%d,s%d,prevLinePred[%d]=%d \n", dsc_state->groupCount, slicenum, mod_hPos/PRED_BLK_SIZE, dsc_state->prevLinePred[mod_hPos/PRED_BLK_SIZE/*3*/]);
                }
        }

}




// ======================================================================================== begin
//! Function to compute number of bits required to code a given residual
/*! \param eq        Residual  */
int FindResidualSize(int eq)
{
        int size_e;

        // Find the size in bits of e
        if(eq == 0) size_e = 0;
        else if (eq >= -1 && eq <= 0) size_e = 1;
        else if (eq >= -2 && eq <= 1) size_e = 2;
        else if (eq >= -4 && eq <= 3) size_e = 3;
        else if (eq >= -8 && eq <= 7) size_e = 4;
        else if (eq >= -16 && eq <= 15) size_e = 5;
        else if (eq >= -32 && eq <= 31) size_e = 6;
        else if (eq >= -64 && eq <= 63) size_e = 7;
        else if (eq >= -128 && eq <= 127) size_e = 8;
        else if (eq >= -256 && eq <= 255) size_e = 9;
        else if (eq >= -512 && eq <= 511) size_e = 10;
        else if (eq >= -1024 && eq <= 1023) size_e = 11;
        else if (eq >= -2048 && eq <= 2047) size_e = 12;
        else if (eq >= -4096 && eq <= 4095) size_e = 13;
        else size_e = 14;

        return size_e;
}


// ======================================================================================== begin
//! Map QP to quantization level
/*! \param dsc_cfg   DSC configuration structure
        \param qp      QP to map
    \return        Flag if flatness information sent for the current supergroup */
int IsFlatnessInfoSent(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int qp, int slicenum)
{

//ppp("     |05__212| # int IsFlatnessInfoSent \n");
        //printf("%d , %d\n", dsc_cfg->flatness_min_qp, dsc_cfg->flatness_max_qp); //3.12

        return ((qp>=dsc_cfg->flatness_min_qp) && (qp<=dsc_cfg->flatness_max_qp));
}



// ======================================================================================== begin
//! Function to remove one pixel's worth of bits from the encoder buffer model
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure */
void RemoveBitsEncoderBuffer(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int slicenum)
{

//ppp("     |05__213| # void RemoveBitsEncoderBuffer \n");
//ppp("     |05__214| <RBEB> g%d, numBitsChunk=%d \n", dsc_state->groupCount, dsc_state->numBitsChunk);
        dsc_state->bpgFracAccum/*localking*/   += (dsc_cfg->bits_per_pixel & 0xf);
        dsc_state->bufferFullness              -= (dsc_cfg->bits_per_pixel >> 4) + (dsc_state->bpgFracAccum/*localking*/>>4);
        dsc_state->numBitsChunk                += (dsc_cfg->bits_per_pixel >> 4) + (dsc_state->bpgFracAccum/*localking*/>>4);
        dsc_state->bpgFracAccum/*localking*/   &= 0xf;
        dsc_state->chunkPixelTimes++;

//ppp("     |05__215| <RBEB> g%d, numBitsChunk=%d \n", dsc_state->groupCount, dsc_state->numBitsChunk);
        if (dsc_state->chunkPixelTimes >= dsc_cfg->slice_width)
        {
                int adjustment_bits/*localking*/;
//                   if (dsc_cfg->vbr_enable)
//                   {
//                           int R_size;
//                           R_size = (dsc_state->numBitsChunk - dsc_state->bitsClamped + 7) / 8;
//                           adjustment_bits/*localking*/ = R_size * 8 - (dsc_state->numBitsChunk - dsc_state->bitsClamped);
//                           dsc_state->bufferFullness -= adjustment_bits/*localking*/;
//                           dsc_state->bitsClamped = 0;
//                           if (dsc_state->isEncoder)
//                                   dsc_state->chunkSizes[dsc_state->chunkCount] = R_size;
//                   }
//                   else   // CBR mode
//                   {
                        adjustment_bits/*localking*/ = dsc_cfg->chunk_size * 8 - dsc_state->numBitsChunk;
                        dsc_state->bufferFullness -= adjustment_bits/*localking*/;
//                   }

//ppp("     |05__216| <RBEB> g%d, numBitsChunk=%d \n", dsc_state->groupCount, dsc_state->numBitsChunk);
                dsc_state->bpgFracAccum/*localking*/ = 0;
                dsc_state->numBitsChunk = 0;
                dsc_state->chunkCount++; // useless
                dsc_state->chunkPixelTimes = 0;

//ppp("     |05__217| <RBEB> g%d, numBitsChunk=%d \n", dsc_state->groupCount, dsc_state->numBitsChunk);
        }
}


// ======================================================================================== begin
//! Rate control function
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param throttle_offset  Offset to apply to buffer fullness before doing threshold comparisons
        \param bpg_offset  Bits per group adjustment for current group
        \param group_count  Current group within slice
        \param scale     Scale factor to apply to buffer fullness before doing threshold comparisons
        \param group_size Number of pixels actually in group (could be smaller than nominal group size for partial groups) */
void RateControl(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int throttle_offset, int bpg_offset, int group_count, int scale, int group_size, int slicenum)
{
        int i;
        int prev_fullness;
        int rcSizeGroup;
        int rcTgtBitsGroup;
        int overflowAvoid;
        int min_QP;
        int max_QP;
        int tgtMinusOffset;
        int tgtPlusOffset;
        dsc_range_cfg_t *range_cfg;
        int rcSizeGroupPrev = dsc_state->rcSizeGroup;
        int prevQp/*localking*/          = dsc_state->stQp;
        int prev2Qp/*localking*/         = dsc_state->prevQp/*localking*/;
        int rcModelBufferFullness/*localking*/;
        int bpg;
        int incr_amount;
        int selected_range/*localking*/;
        int stQp;
        int curQp;
        int iter;
        int R_throttle_offset/*localking*/;
        prev_fullness = dsc_state->bufferFullness; // garbage useless

//ppp("     |05__218| gC_inc1=%d, rcSizeGroupPrev=%d \n", dsc_state->groupCount, rcSizeGroupPrev);
//ppp("     |05__219| gC_inc1=%d, prevQp=%d \n", dsc_state->groupCount, prevQp);
//ppp("     |05__220| gC_inc1=%d, prev2Qp=%d \n", dsc_state->groupCount, prev2Qp);
//ppp("     |05__221| gC_inc1=%d, group_size=%d \n", dsc_state->groupCount, group_size);
//ppp("     |05__222| gC_inc1=%d, pC=%d \n", dsc_state->groupCount, dsc_state->pixelCount);

        for (i = 0; i < group_size; ++i)
        {
                dsc_state->pixelCount++;

                if (dsc_state->pixelCount >= dsc_cfg->initial_xmit_delay)
                        RemoveBitsEncoderBuffer(dsc_cfg, dsc_state, slicenum);
        }

//ppp("     |05__223| gC_inc1=%d, pC=%d \n", dsc_state->groupCount, dsc_state->pixelCount);

        // Add up estimated bits for the Group, i.e. as if VLC sample size matched max sample size
        rcSizeGroup = 0;
        for (i = 0; i < NUM_COMPONENTS; i++) {

                rcSizeGroup += dsc_state->rcSizeUnit[i];
        }

//ppp("     |05__224| gC_inc1=%d, rcSizeUnit[Y]=%d \n", dsc_state->groupCount, dsc_state->rcSizeUnit[0]);
//ppp("     |05__225| gC_inc1=%d, rcSizeUnit[U]=%d \n", dsc_state->groupCount, dsc_state->rcSizeUnit[1]);
//ppp("     |05__226| gC_inc1=%d, rcSizeUnit[V]=%d \n", dsc_state->groupCount, dsc_state->rcSizeUnit[2]);

//ppp("     |05__227| gC_inc1=%d, rcSizeGroup=%d \n", dsc_state->groupCount, rcSizeGroup);

//           if (PRINT_DEBUG_RC)
//           {
//                   fprintf(g_fp_dbg, "RC group #%d, scale=%d, offset=%d, bpg_offset=%d, ", group_count, scale, throttle_offset, bpg_offset);
//                   fprintf(g_fp_dbg, "RCSizeGroup=%d, coded_group_size=%d\n", rcSizeGroup, dsc_state->codedGroupSize);
//                   fprintf(g_fp_dbg, "Buffer fullness=%d, ", dsc_state->bufferFullness);
//           }

        // Set target number of bits per Group according to buffer fullness
        range_cfg                       = dsc_cfg->rc_range_parameters;
        R_throttle_offset/*localking*/  = throttle_offset - dsc_cfg->rc_model_size;

        // *MODEL NOTE* MN_RC_XFORM
        rcModelBufferFullness/*localking*/ = (scale * (dsc_state->bufferFullness + R_throttle_offset/*localking*/)) >> RC_SCALE_BINARY_POINT;

//ppp("     |05__228| gC_inc1=%d, R_throttle_offset=%d \n", dsc_state->groupCount, R_throttle_offset);
//ppp("     |05__229| gC_inc1=%d, rcModelBufferFullness=%d \n", dsc_state->groupCount, rcModelBufferFullness);
//ppp("     |05__230| gC_inc1=%d, scale=%d \n", dsc_state->groupCount, scale);
//ppp("     |05__231| gC_inc1=%d, bufferFullness=%d \n", dsc_state->groupCount, dsc_state->bufferFullness);

//           if (PRINT_DEBUG_RC)
//                   fprintf(g_fp_dbg, "RC model buffer fullness=%d\n", rcModelBufferFullness);

        // Pick the correct range
        // *MODEL NOTE* MN_RC_LONG_TERM
        for (i = NUM_BUF_RANGES/*15*/ - 1; i > 0; --i)
        {
                overflowAvoid = (dsc_state->bufferFullness + R_throttle_offset/*localking*/ > OVERFLOW_AVOID_THRESHOLD); /// ??? this code should be out of the loop
//ppp("     |05__232| gC_inc1=%d, overflowAvoid=%d \n", dsc_state->groupCount, overflowAvoid);

                if ((rcModelBufferFullness > dsc_cfg->rc_buf_thresh[i - 1] - dsc_cfg->rc_model_size))
                        break; ////////////////////////////////////////////////////////////////////////////////////////////
        }

//ppp("     |05__233| gC_inc1=%d, i=%d \n", dsc_state->groupCount, i);

        //printf("%d\n",i);
        if (rcModelBufferFullness > 0)
        {
                printf("The RC model has overflowed.  To address this issue, please adjust the\n");
                printf("min_QP and max_QP higher for the top-most ranges, or decrease the rc_buf_thresh\n");
                printf("for those ranges.\n");
                exit(1);
        }

        // Add a group time of delay to RC calculation
        selected_range/*localking*/ = dsc_state->prevRange/*localking*/;
        dsc_state->prevRange/*localking*/ = i;

        // *MODEL NOTE* MN_RC_SHORT_TERM
        bpg = (dsc_cfg->bits_per_pixel * group_size);
        bpg = (bpg + 8) >> 4;
        rcTgtBitsGroup = MAX(0, bpg + range_cfg[selected_range].range_bpg_offset + bpg_offset);
        min_QP = range_cfg[selected_range].range_min_qp;
        max_QP = range_cfg[selected_range].range_max_qp;

//ppp("     |05__234| gC_inc1=%d, selected_range=%d \n", dsc_state->groupCount, selected_range);
//ppp("     |05__235| gC_inc1=%d, prevRange=%d \n", dsc_state->groupCount, dsc_state->prevRange);
//ppp("     |05__236| gC_inc1=%d, bpg=%d \n", dsc_state->groupCount, bpg);
//ppp("     |05__237| gC_inc1=%d, rcTgtBitsGroup=%d \n", dsc_state->groupCount, rcTgtBitsGroup);
//ppp("     |05__238| gC_inc1=%d, min_QP=%d \n", dsc_state->groupCount, min_QP);
//ppp("     |05__239| gC_inc1=%d, max_QP=%d \n", dsc_state->groupCount, max_QP);

//           if (PRINT_DEBUG_RC)
//                   fprintf(g_fp_dbg, "Range %d: MIN=%d, MAX=%d, QuantPrev=%d, ", selected_range, min_QP, max_QP, dsc_state->stQp);

        tgtMinusOffset = MAX( 0, rcTgtBitsGroup - dsc_cfg->rc_tgt_offset_lo );
        tgtPlusOffset  = MAX( 0, rcTgtBitsGroup + dsc_cfg->rc_tgt_offset_hi );
        incr_amount = (dsc_state->codedGroupSize - rcTgtBitsGroup) >> 1;

//ppp("     |05__240| gC_inc1=%d, rc_tgt_offset_lo=%d \n", dsc_state->groupCount, dsc_cfg->rc_tgt_offset_lo);
//ppp("     |05__241| gC_inc1=%d, rc_tgt_offset_hi=%d \n", dsc_state->groupCount, dsc_cfg->rc_tgt_offset_hi);
//ppp("     |05__242| gC_inc1=%d, tgtMinusOffset=%d \n", dsc_state->groupCount, tgtMinusOffset);
//ppp("     |05__243| gC_inc1=%d, tgtPlusOffset=%d \n", dsc_state->groupCount, tgtPlusOffset);
//ppp("     |05__244| gC_inc1=%d, incr_amount=%d \n", dsc_state->groupCount, incr_amount);
//ppp("     |05__245| gC_inc1=%d, codedGroupSize=%d \n", dsc_state->groupCount, dsc_state->codedGroupSize);

//ppp("     |05__246| gC_inc1=%d, prevQp=%x\n", dsc_state->groupCount, prevQp);

        if (rcSizeGroup==PIXELS_PER_GROUP)
        {
                stQp = MAX(min_QP/2, prevQp/*localking*/-1);                // stQp COND01
//ppp("     |05__247| gC_inc1=%d, F. stQp=%x\n", dsc_state->groupCount, stQp);
        }
        else if ( (dsc_state->codedGroupSize < tgtMinusOffset) && (rcSizeGroup < tgtMinusOffset) )
        {
                stQp = MAX(min_QP, (prevQp/*localking*/-1));                // stQp COND02
//ppp("     |05__248| gC_inc1=%d, G. stQp=%x\n", dsc_state->groupCount, stQp);
        }
        // avoid increasing QP immediately after edge
        else if ( (dsc_state->bufferFullness >= 64) &&  dsc_state->codedGroupSize > tgtPlusOffset )  // over budget - increase qp
        {
                curQp = MAX(prevQp/*localking*/, min_QP);
//ppp("     |05__249| gC_inc1=%d, curQp=%x\n", dsc_state->groupCount, curQp);
//ppp("     |05__250| gC_inc1=%d, rc_edge_factor=%x\n", dsc_state->groupCount, dsc_cfg->rc_edge_factor);
                if (prev2Qp/*localking*/ == curQp)   // 2nd prev grp == prev grp
                {
                        if ( (rcSizeGroup*2) < (rcSizeGroupPrev*dsc_cfg->rc_edge_factor) )
                        {
                                stQp = MIN(max_QP, (curQp+incr_amount));    // stQp COND03
//ppp("     |05__251| gC_inc1=%d, H. stQp=%x\n", dsc_state->groupCount, stQp);
                        }
                        else
                        {
                                stQp = curQp;                               // stQp COND04
//ppp("     |05__252| gC_inc1=%d, I. stQp=%x\n", dsc_state->groupCount, stQp);
                        }
                }
                else if (prev2Qp/*localking*/ < curQp)
                {
                        if (((rcSizeGroup * 2) < (rcSizeGroupPrev*dsc_cfg->rc_edge_factor) && (curQp < dsc_cfg->rc_quant_incr_limit0)))
                        {
                                stQp = MIN(max_QP, (curQp + incr_amount));  // stQp COND05
//ppp("     |05__253| gC_inc1=%d, J. stQp=%x\n", dsc_state->groupCount, stQp);
                        }
                        else
                        {
                                stQp = curQp;                               // stQp COND06
//ppp("     |05__254| gC_inc1=%d, K. stQp=%x\n", dsc_state->groupCount, stQp);
                        }
                }
                else if ( curQp < dsc_cfg->rc_quant_incr_limit1 )
                {
                        stQp = MIN(max_QP, (curQp+incr_amount));            // stQp COND07
//ppp("     |05__255| gC_inc1=%d, L. stQp=%x\n", dsc_state->groupCount, stQp);
                }
                else
                {
                        stQp = curQp;                                       // stQp COND08
//ppp("     |05__256| gC_inc1=%d, M. stQp=%x\n", dsc_state->groupCount, stQp);
                }
        }
        else
        {
                stQp = prevQp/*localking*/;                                 // stQp COND09
//ppp("     |05__257| gC_inc1=%d, N. stQp=%x\n", dsc_state->groupCount, stQp);
        }

        if ( overflowAvoid )
                stQp = range_cfg[NUM_BUF_RANGES/*15*/-1].range_max_qp;      // stQp COND10

        rcSizeGroupPrev = rcSizeGroup;

        dsc_state->rcSizeGroup = rcSizeGroup;
        dsc_state->stQp                     = stQp;
        dsc_state->prevQp/*localking*/      = prevQp/*localking*/;

//        if (PRINT_DEBUG_RC)
//                fprintf(g_fp_dbg, "New quant value=%d\n", stQp);

        if ( dsc_state->bufferFullness > dsc_cfg->rcb_bits ) {
                printf("The buffer model has overflowed.  This probably occurred due to an error in the\n");
                printf("rate control parameter programming or an attempt to decode an invalid DSC stream.\n\n");
                printf( "ERROR: RCB overflow; size is %d, tried filling to %d\n", dsc_cfg->rcb_bits, dsc_state->bufferFullness );
                printf( "  previous level: %5d\n", prev_fullness );
                printf( "  target BPP:     %5d\n", dsc_cfg->bits_per_pixel >> 4 );
                printf( "  new level:      %5d\n", dsc_state->bufferFullness );
                printf( "Range info\n" );
                printf( "  range min_qp:     %d\n", range_cfg->range_min_qp );
                printf( "  range max_qp:     %d\n", range_cfg->range_max_qp );
                printf( "  range bpg_offset: %d\n", range_cfg->range_bpg_offset );
                range_cfg--;
                printf( "Previous range info\n" );
                printf( "  range min_qp:     %d\n", range_cfg->range_min_qp );
                printf( "  range max_qp:     %d\n", range_cfg->range_max_qp );
                exit(1);
        }
}

// ======================================================================================== begin
//! Predict size for next unit
/*! \param dsc_cfg   DSC configuration structure
    \param req_size  Array of required sizes for the samples in the unit
        \return          Predicted size for next unit */
int PredictSize(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int *req_size, int slicenum)
{
        int pred_size;

//ppp("     |05__258| # int PredictSize \n");
        pred_size = 2;  // +0.5 for rounding
        pred_size += req_size[0]+req_size[1];
        pred_size += 2*req_size[2];
        pred_size >>= 2;

        return (pred_size);
}


// ======================================================================================== begin
//! Size to code that means "escape code"
/*! \param dsc_state DSC state structure
        \param qp        Quantization parameter for group */
int EscapeCodeSize(dsc_state_t *dsc_state, int qp, int slicenum)
{
        int qlevel, alt_size_to_generate;

//ppp("     |05__259| # int EscapeCodeSize \n");
        qlevel = MapQpToQlevel(dsc_state, qp, 0);    // map to luma quant
        alt_size_to_generate = dsc_state->cpntBitDepth[0] + 1 - qlevel;

        return (alt_size_to_generate);
}


// ======================================================================================== begin
//! Decode one unit
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param cpnt      Component to code
        \param quantized_residuals Quantized residuals
        \param byte_in_p Pointer to compressed bits buffer (modified) */
void VLDUnit_Y(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int *quantized_residuals, unsigned char **byte_in_p, int slicenum)
{
        int required_size[NUM_COMPONENTS];
        int size;
        int max_size;
        int prefix_value;
        int adj_predicted_size;
        int i;
        int alt_size_to_generate;
        int use_ich;
        int qlevel;
        int max_prefix;
        int midpoint_selected;
        int qp;
        int Y = 0, U = 1, V = 2;
        int shifter[] = {0, 0};

        get_shifter_for_verilog(dsc_cfg, dsc_state, Y, *shifter, slicenum);

        get_shifter_for_verilog(dsc_cfg, dsc_state, U, *shifter, slicenum);

        get_shifter_for_verilog(dsc_cfg, dsc_state, V, *shifter, slicenum);

//ppp("     |05__260| ================ \n");
//ppp("     |05__261| <VLDUnit_Y> g%d, Y, # shifter[Y].fullness=%d (old 1)\n", dsc_state->groupCount, dsc_state->shifter[Y].fullness);
        qp = dsc_state->masterQp;

        qlevel = MapQpToQlevel(dsc_state, dsc_state->masterQp, Y);

//ppp("     |05__262| <VLDUnit_Y> g%d, Y, # qp=%d \n", dsc_state->groupCount, qp);
//ppp("     |05__263| <VLDUnit_Y> g%d, Y, # void qlevel=%d \n", dsc_state->groupCount, qlevel);

        adj_predicted_size = GetQpAdjPredSize(dsc_state, Y, slicenum); // 0~9

//ppp("     |05__264| <VLDUnit_Y> g%d, Y, # adj_predicted_size=%d \n", dsc_state->groupCount, adj_predicted_size);

//ppp("     |05__265| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);

        dsc_state->prevIchSelected = dsc_state->ichSelected;
        dsc_state->ichSelected = 0;

        if ((dsc_state->groupCount % GROUPS_PER_SUPERGROUP) == 3)
        {
                if (IsFlatnessInfoSent(dsc_cfg, dsc_state, qp, slicenum)) // according to masterQp
                {
                        if (GetBits(dsc_cfg, dsc_state, Y, 1, 0, *byte_in_p)) // get 1 bit from shifter[Y]
                                dsc_state->prevFirstFlat = 0;
                        else
                                dsc_state->prevFirstFlat = -1;
                }
                else
                        dsc_state->prevFirstFlat = -1;                        // get 0 bit from shifter[Y]
        }
//ppp("     |05__266| <VLDUnit_Y> g%d, Y, # shifter[Y].fullness=%d (old 2)\n", dsc_state->groupCount, dsc_state->shifter[Y].fullness);
//ppp("     |05__267| <VLDUnit_Y> g%d, Y, # prevFirstFlat=%d \n", dsc_state->groupCount, dsc_state->prevFirstFlat);

        if ((dsc_state->groupCount % GROUPS_PER_SUPERGROUP) == 0)
        {
            if (dsc_state->prevFirstFlat >= 0)
                {
                        dsc_state->flatnessType = 0;
                        if (dsc_state->masterQp >= SOMEWHAT_FLAT_QP_THRESH) // according to masterQp
                                dsc_state->flatnessType = GetBits(dsc_cfg, dsc_state, Y, 1, 0, *byte_in_p); // get 1 bit from shifter[Y]

                                dsc_state->firstFlat    = GetBits(dsc_cfg, dsc_state, Y, 2, 0, *byte_in_p); // get 2 bit from shifter[Y]
                }
                else
                        dsc_state->firstFlat = -1;                                                          // get 0 bit from shifter[Y]
        }
//ppp("     |05__268| <VLDUnit_Y> g%d, Y, # shifter[Y].fullness=%d (old 3)\n", dsc_state->groupCount, dsc_state->shifter[Y].fullness);
//ppp("     |05__269| <VLDUnit_Y> g%d, Y, # flatnessType=%d \n", dsc_state->groupCount, dsc_state->flatnessType );
//ppp("     |05__270| <VLDUnit_Y> g%d, Y, # firstFlat   =%d \n", dsc_state->groupCount, dsc_state->firstFlat    );

        max_prefix = MaxResidualSize(dsc_state, Y, dsc_state->masterQp, slicenum) + 1 - adj_predicted_size; // +(CType==0) for escape code

//ppp("     |05__271| <VLDUnit_Y> g%d, Y, # max_prefix=%d \n", dsc_state->groupCount, max_prefix);

        prefix_value = 0;


//ppp("     |05__272| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);
        while ((prefix_value < max_prefix) && !GetBits(dsc_cfg, dsc_state, Y, 1, 0, *byte_in_p)) // get x bit from shifter[Y]
        {
//ppp("     |05__273| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);
//ppp("     |05__274| <VLDUnit_Y> g%d, Y, # shifter[Y].fullness=%d (old 4)\n", dsc_state->groupCount, dsc_state->shifter[Y].fullness);
                prefix_value++;  // 0~11
        }
//ppp("     |05__275| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);
//ppp("     |05__276| <VLDUnit_Y> g%d, Y, # shifter[Y].fullness=%d (old 5)\n", dsc_state->groupCount, dsc_state->shifter[Y].fullness);

//ppp("     |05__277| <VLDUnit_Y> g%d, Y, # prefix_value=%d \n", dsc_state->groupCount, prefix_value);

        //printf("%x\n", prefix_value);

        if (dsc_state->prevIchSelected)
                size = adj_predicted_size + prefix_value - 1;  // size can >=11, but the max possible used size is 10
        else
                size = adj_predicted_size + prefix_value;      // size can >=11, but the max possible used size is 10

//ppp("     |05__278| <VLDUnit_Y> g%d, Y, # size=%d \n", dsc_state->groupCount, size); // size can >=11, but the max possible used size is 10

        //printf("adj_predicted_size=%d,prefix_value=%d,dsc_state->cpntBitDepth[cpnt] - qlevel=%d\n", adj_predicted_size, prefix_value, dsc_state->cpntBitDepth[cpnt] - qlevel);

        alt_size_to_generate = EscapeCodeSize(dsc_state, dsc_state->masterQp, slicenum);
//ppp("     |05__279| <VLDUnit_Y> g%d, Y, # alt_size_to_generate=%d \n", dsc_state->groupCount, alt_size_to_generate);

        if (dsc_state->prevIchSelected)
                use_ich = (prefix_value==0);
        else
                use_ich = (size >= alt_size_to_generate);

//ppp("     |05__280| <VLDUnit_Y> g%d, Y, # q_r[samp0]=%d (meta) \n", dsc_state->groupCount,quantized_residuals[0]);
//ppp("     |05__281| <VLDUnit_Y> g%d, Y, # q_r[samp1]=%d (meta) \n", dsc_state->groupCount,quantized_residuals[1]);
//ppp("     |05__282| <VLDUnit_Y> g%d, Y, # q_r[samp2]=%d (meta) \n", dsc_state->groupCount,quantized_residuals[2]);

//ppp("     |05__283| <VLDUnit_Y> g%d, Y, # prevIchSelected=%d \n", dsc_state->groupCount,dsc_state->prevIchSelected);
//ppp("     |05__284| <VLDUnit_Y> g%d, Y, # use_ich=%d \n", dsc_state->groupCount,    use_ich);

//ppp("     |05__285| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);
//ppp("     |05__286| <VLDUnit_Y> g%d, Y, # shifter[Y].fullness=%d (old 6)\n", dsc_state->groupCount, dsc_state->shifter[Y].fullness);
//ppp("     |05__287| -------------------------------- \n");
        if (use_ich)  // ICH hit
        {
                dsc_state->ichSelected = 1;
                for (i=0; i<PIXELS_PER_GROUP; ++i)
                {
                        char c_cpnt;
                        if(i==0) c_cpnt='Y'; else if(i==1) c_cpnt='U'; else c_cpnt='V';

                        dsc_state->ichLookup[i] = GetBits(dsc_cfg, dsc_state, i, ICH_BITS/*5*/, 0, *byte_in_p); // get 5 bit from shifter[Y][U][V] each
//ppp("     |05__288| <VLDUnit_Y> g%d, %c, # ichLookup[%d]=%d \n", dsc_state->groupCount, c_cpnt, i, dsc_state->ichLookup[i]);
//ppp("     |05__289| <VLDUnit_Y> g%d, %c, # shifter[%c].data[%d/8=%d]=%02x \n", dsc_state->groupCount, c_cpnt, c_cpnt, dsc_state->shifter[i].read_ptr, dsc_state->shifter[i].read_ptr/8, dsc_state->shifter[i].data[dsc_state->shifter[i].read_ptr/8]);
//ppp("     |05__290| <VLDUnit_Y> g%d, %c, # shifter[%c].fullness=%d (old 7)\n"       , dsc_state->groupCount, c_cpnt, c_cpnt, dsc_state->shifter[i].fullness);
                }
//ppp("     |05__291| -------------------------------- \n");


                dsc_state->rcSizeUnit[0] = ICH_BITS/*5*/ + 1;
                dsc_state->rcSizeUnit[1] = dsc_state->rcSizeUnit[2] = ICH_BITS/*5*/;

                return;
        }

        // *MODEL NOTE* MN_DEC_MPP_SELECT
        midpoint_selected           = (size==dsc_state->cpntBitDepth[Y] - qlevel);
        dsc_state->useMidpoint[Y]   = midpoint_selected;
        //printf("cpnt = %d, usemid = %d\n", cpnt, dsc_state->useMidpoint[cpnt]);

//ppp("     |05__292| <VLDUnit_Y> g%d, Y, # midpoint_selected=%d \n", dsc_state->groupCount, midpoint_selected);
//ppp("     |05__293| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);

        // Get bits from input bitstream
        max_size = 0;
        for ( i=0; i<SAMPLES_PER_UNIT; i++ ) {
                quantized_residuals[i] = GetBits(dsc_cfg, dsc_state, Y, size, 1, *byte_in_p); // get 3*size bit from shifter[Y]
//ppp("     |05__294| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);
                required_size[i] = FindResidualSize( quantized_residuals[i] );
                max_size = MAX( required_size[i], max_size );
        }

//ppp("     |05__295| <VLDUnit_Y> g%d, Y, # shifter[Y].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[Y].read_ptr, dsc_state->shifter[Y].read_ptr/8, dsc_state->shifter[Y].data[dsc_state->shifter[Y].read_ptr/8]);
//ppp("     |05__296| <VLDUnit_Y> g%d, Y, # shifter[Y].fullness=%d (final)\n", dsc_state->groupCount, dsc_state->shifter[Y].fullness);

//ppp("     |05__297| <VLDUnit_Y> g%d, Y, # q_r[samp0]=%d (new) \n", dsc_state->groupCount,quantized_residuals[0]);
//ppp("     |05__298| <VLDUnit_Y> g%d, Y, # q_r[samp1]=%d (new) \n", dsc_state->groupCount,quantized_residuals[1]);
//ppp("     |05__299| <VLDUnit_Y> g%d, Y, # q_r[samp2]=%d (new) \n", dsc_state->groupCount,quantized_residuals[2]);

//ppp("     |05__300| <VLDUnit_Y> g%d, Y, # r_s[samp0]=%d \n", dsc_state->groupCount,required_size[0]);
//ppp("     |05__301| <VLDUnit_Y> g%d, Y, # r_s[samp1]=%d \n", dsc_state->groupCount,required_size[1]);
//ppp("     |05__302| <VLDUnit_Y> g%d, Y, # r_s[samp2]=%d \n", dsc_state->groupCount,required_size[2]);

//ppp("     |05__303| <VLDUnit_Y> g%d, Y, # max_size=%d \n", dsc_state->groupCount,max_size);

        if (midpoint_selected)
        {
                max_size = size;
                for (i=0; i<SAMPLES_PER_UNIT; ++i)
                        required_size[i] = size;
        }

//ppp("     |05__304| <VLDUnit_Y> g%d, Y, # r_s[samp0]=%d \n", dsc_state->groupCount,required_size[0]);
//ppp("     |05__305| <VLDUnit_Y> g%d, Y, # r_s[samp1]=%d \n", dsc_state->groupCount,required_size[1]);
//ppp("     |05__306| <VLDUnit_Y> g%d, Y, # r_s[samp2]=%d \n", dsc_state->groupCount,required_size[2]);

        // rate control size uses max required size plus 1 (for prefix value of 0)
        dsc_state->rcSizeUnit[Y] = max_size*SAMPLES_PER_UNIT + 1;
//ppp("     |05__307| <VLDUnit_Y> g%d, Y, # rcSizeUnit[Y]=%d \n", dsc_state->groupCount, dsc_state->rcSizeUnit[Y]);

        //
        // Predict size for next unit for this component
        // and store predicted size to state structure
        //printf("%d\n",);
        dsc_state->predictedSize[Y] = PredictSize(dsc_cfg, dsc_state, required_size, slicenum);
//ppp("     |05__308| <VLDUnit_Y> g%d, Y, # predictedSize[Y]=%d \n", dsc_state->groupCount, dsc_state->predictedSize[Y]);
        //printf("%d\n", dsc_state->predictedSize[cpnt]);
}

void VLDUnit_U(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int *quantized_residuals, unsigned char **byte_in_p, int slicenum)
{
        int required_size[NUM_COMPONENTS];
        int size;
        int max_size;
        int prefix_value;
        int adj_predicted_size;
        int i;
        int qlevel;
        int max_prefix;
        int midpoint_selected;
        int qp;
        int Y = 0, U = 1, V = 2;
        int shifter;

//ppp("     |05__309| ================ \n");
//ppp("     |05__310| <VLDUnit_U> g%d, U, # shifter[U].fullness=%d \n", dsc_state->groupCount, dsc_state->shifter[U].fullness);
        qp = dsc_state->masterQp;

        qlevel = MapQpToQlevel(dsc_state, dsc_state->masterQp, U);

//ppp("     |05__311| <VLDUnit_U> g%d, U, # qp=%d \n", dsc_state->groupCount, qp);
//ppp("     |05__312| <VLDUnit_U> g%d, U, # qlevel=%d \n", dsc_state->groupCount, qlevel);

        adj_predicted_size = GetQpAdjPredSize(dsc_state, U, slicenum); // 0~10

//ppp("     |05__313| <VLDUnit_U> g%d, U, # adj_predicted_size=%d \n", dsc_state->groupCount, adj_predicted_size);

//ppp("     |05__314| <VLDUnit_U> g%d, U, # q_r[samp0]=%d (meta)\n", dsc_state->groupCount,quantized_residuals[0]);
//ppp("     |05__315| <VLDUnit_U> g%d, U, # q_r[samp1]=%d (meta)\n", dsc_state->groupCount,quantized_residuals[1]);
//ppp("     |05__316| <VLDUnit_U> g%d, U, # q_r[samp2]=%d (meta)\n", dsc_state->groupCount,quantized_residuals[2]);

//ppp("     |05__317| <VLDUnit_U> g%d, U, # ichSelected=%d \n", dsc_state->groupCount, dsc_state->ichSelected);
        if (dsc_state->ichSelected){
                return;                                                 // Don't read other 2 components if we're in ICH mode
        }

        max_prefix = MaxResidualSize(dsc_state, U, dsc_state->masterQp, slicenum) - adj_predicted_size; // +(CType==0) for escape code

//ppp("     |05__318| <VLDUnit_U> g%d, U, # max_prefix=%d \n", dsc_state->groupCount, max_prefix);

        prefix_value = 0;

//ppp("     |05__319| <VLDUnit_U> g%d, U, # shifter[U].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[U].read_ptr, dsc_state->shifter[U].read_ptr/8, dsc_state->shifter[U].data[dsc_state->shifter[U].read_ptr/8]);
        while ((prefix_value < max_prefix) && !GetBits(dsc_cfg, dsc_state, U, 1, 0, *byte_in_p))  // get x bit from shifter[U]
        {
                prefix_value++; // 0~11
//ppp("     |05__320| <VLDUnit_U> g%d, U, # shifter[U].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[U].read_ptr, dsc_state->shifter[U].read_ptr/8, dsc_state->shifter[U].data[dsc_state->shifter[U].read_ptr/8]);
//ppp("     |05__321| <VLDUnit_U> g%d, U, # prefix_value=%d \n", dsc_state->groupCount, prefix_value);
        }
//ppp("     |05__322| <VLDUnit_U> g%d, U, # shifter[U].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[U].read_ptr, dsc_state->shifter[U].read_ptr/8, dsc_state->shifter[U].data[dsc_state->shifter[U].read_ptr/8]);

//ppp("     |05__323| <VLDUnit_U> g%d, U, # shifter[U].fullness=%d \n", dsc_state->groupCount, dsc_state->shifter[U].fullness);

        size = adj_predicted_size + prefix_value;

//ppp("     |05__324| <VLDUnit_U> g%d, U, # size=%d \n", dsc_state->groupCount, size); // size can >=11, but the max possible used size is 10

        // *MODEL NOTE* MN_DEC_MPP_SELECT
        midpoint_selected           = (size==dsc_state->cpntBitDepth[U] - qlevel);
        dsc_state->useMidpoint[U]   = midpoint_selected;

//ppp("     |05__325| <VLDUnit_U> g%d, U, # midpoint_selected=%d \n", dsc_state->groupCount, midpoint_selected);
//ppp("     |05__326| <VLDUnit_U> g%d, U, # shifter[U].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[U].read_ptr, dsc_state->shifter[U].read_ptr/8, dsc_state->shifter[U].data[dsc_state->shifter[U].read_ptr/8]);

        // Get bits from input bitstream
        max_size = 0;
        for ( i=0; i<SAMPLES_PER_UNIT; i++ ) {
                quantized_residuals[i]  = GetBits(dsc_cfg, dsc_state, U, size, 1, *byte_in_p);  // get 3*size bit from shifter[U]
//ppp("     |05__327| <VLDUnit_U> g%d, U, # shifter[U].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[U].read_ptr, dsc_state->shifter[U].read_ptr/8, dsc_state->shifter[U].data[dsc_state->shifter[U].read_ptr/8]);
                required_size[i]        = FindResidualSize( quantized_residuals[i] );
                max_size                = MAX( required_size[i], max_size );
        }

//ppp("     |05__328| <VLDUnit_U> g%d, U, # shifter[U].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[U].read_ptr, dsc_state->shifter[U].read_ptr/8, dsc_state->shifter[U].data[dsc_state->shifter[U].read_ptr/8]);
//ppp("     |05__329| <VLDUnit_U> g%d, U, # shifter[U].fullness=%d \n", dsc_state->groupCount, dsc_state->shifter[U].fullness);

//ppp("     |05__330| <VLDUnit_U> g%d, U, # q_r[samp0]=%d (new)\n", dsc_state->groupCount,quantized_residuals[0]);
//ppp("     |05__331| <VLDUnit_U> g%d, U, # q_r[samp1]=%d (new)\n", dsc_state->groupCount,quantized_residuals[1]);
//ppp("     |05__332| <VLDUnit_U> g%d, U, # q_r[samp2]=%d (new)\n", dsc_state->groupCount,quantized_residuals[2]);

//ppp("     |05__333| <VLDUnit_U> g%d, U, # r_s[samp0]=%d \n", dsc_state->groupCount,required_size[0]);
//ppp("     |05__334| <VLDUnit_U> g%d, U, # r_s[samp1]=%d \n", dsc_state->groupCount,required_size[1]);
//ppp("     |05__335| <VLDUnit_U> g%d, U, # r_s[samp2]=%d \n", dsc_state->groupCount,required_size[2]);

//ppp("     |05__336| <VLDUnit_U> g%d, U, # max_size=%d \n", dsc_state->groupCount,max_size);

        if (midpoint_selected)
        {
                max_size = size;
                for (i=0; i<SAMPLES_PER_UNIT; ++i)
                        required_size[i] = size;
        }

//ppp("     |05__337| <VLDUnit_U> g%d, U, # r_s[samp0]=%d \n", dsc_state->groupCount,required_size[0]);
//ppp("     |05__338| <VLDUnit_U> g%d, U, # r_s[samp1]=%d \n", dsc_state->groupCount,required_size[1]);
//ppp("     |05__339| <VLDUnit_U> g%d, U, # r_s[samp2]=%d \n", dsc_state->groupCount,required_size[2]);

        // rate control size uses max required size plus 1 (for prefix value of 0)
        dsc_state->rcSizeUnit[U] = max_size*SAMPLES_PER_UNIT + 1;
//ppp("     |05__340| <VLDUnit_U> g%d, U, # rcSizeUnit[U]=%d \n", dsc_state->groupCount, dsc_state->rcSizeUnit[U]);

        //
        // Predict size for next unit for this component
        // and store predicted size to state structure
        //printf("%d\n",);
        dsc_state->predictedSize[U] = PredictSize(dsc_cfg, dsc_state, required_size, slicenum);
//ppp("     |05__341| <VLDUnit_U> g%d, U, # predictedSize[U]=%d \n", dsc_state->groupCount, dsc_state->predictedSize[U]);
        //printf("%d\n", dsc_state->predictedSize[cpnt]);
}

void VLDUnit_V(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int *quantized_residuals, unsigned char **byte_in_p, int slicenum)
{
        int required_size[NUM_COMPONENTS];
        int size;
        int max_size;
        int prefix_value;
        int adj_predicted_size;
        int i;
        int qlevel;
        int max_prefix;
        int midpoint_selected;
        int qp;
        int Y = 0, U = 1, V = 2;
        int shifter;

//ppp("     |05__342| ================ \n");
//ppp("     |05__343| <VLDUnit_V> g%d, V, # shifter[V].fullness=%d \n", dsc_state->groupCount, dsc_state->shifter[V].fullness);
        qp = dsc_state->masterQp;

        qlevel = MapQpToQlevel(dsc_state, dsc_state->masterQp, V);

//ppp("     |05__344| <VLDUnit_V> g%d, V, # qp=%d \n", dsc_state->groupCount, qp);
//ppp("     |05__345| <VLDUnit_V> g%d, V, # void qlevel=%d \n", dsc_state->groupCount, qlevel);

        adj_predicted_size = GetQpAdjPredSize(dsc_state, V, slicenum); // 0~10

//ppp("     |05__346| <VLDUnit_V> g%d, V, # adj_predicted_size=%d \n", dsc_state->groupCount, adj_predicted_size);

//ppp("     |05__347| <VLDUnit_V> g%d, V, # q_r[samp0]=%d (meta)\n", dsc_state->groupCount,quantized_residuals[0]);
//ppp("     |05__348| <VLDUnit_V> g%d, V, # q_r[samp1]=%d (meta)\n", dsc_state->groupCount,quantized_residuals[1]);
//ppp("     |05__349| <VLDUnit_V> g%d, V, # q_r[samp2]=%d (meta)\n", dsc_state->groupCount,quantized_residuals[2]);

//ppp("     |05__350| <VLDUnit_V> g%d, V, # ichSelected=%d \n", dsc_state->groupCount, dsc_state->ichSelected);
        if (dsc_state->ichSelected){
                return;                                                 // Don't read other 2 components if we're in ICH mode
        }

        max_prefix = MaxResidualSize(dsc_state, V, dsc_state->masterQp, slicenum) - adj_predicted_size; // +(CType==0) for escape code

//ppp("     |05__351| <VLDUnit_V> g%d, V, # max_prefix=%d \n", dsc_state->groupCount, max_prefix);

        prefix_value = 0;


//ppp("     |05__352| <VLDUnit_V> g%d, V, # shifter[V].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[V].read_ptr, dsc_state->shifter[V].read_ptr/8, dsc_state->shifter[V].data[dsc_state->shifter[V].read_ptr/8]);
        while ((prefix_value < max_prefix) && !GetBits(dsc_cfg, dsc_state, V, 1, 0, *byte_in_p))    // get x bit from shifter[V]
        {
//ppp("     |05__353| <VLDUnit_V> g%d, V, # shifter[V].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[V].read_ptr, dsc_state->shifter[V].read_ptr/8, dsc_state->shifter[V].data[dsc_state->shifter[V].read_ptr/8]);
                prefix_value++; // 0~11
        }
//ppp("     |05__354| <VLDUnit_V> g%d, V, # shifter[V].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[V].read_ptr, dsc_state->shifter[V].read_ptr/8, dsc_state->shifter[V].data[dsc_state->shifter[V].read_ptr/8]);

//ppp("     |05__355| <VLDUnit_V> g%d, V, # shifter[V].fullness=%d \n", dsc_state->groupCount, dsc_state->shifter[V].fullness);
//ppp("     |05__356| <VLDUnit_V> g%d, V, # prefix_value=%d \n", dsc_state->groupCount, prefix_value);

        size = adj_predicted_size + prefix_value;

//ppp("     |05__357| <VLDUnit_V> g%d, V, # size=%d \n", dsc_state->groupCount, size); // size can >=11, but the max possible used size is 10


        // *MODEL NOTE* MN_DEC_MPP_SELECT
        midpoint_selected           = (size==dsc_state->cpntBitDepth[V] - qlevel);
        dsc_state->useMidpoint[V]   = midpoint_selected;

//ppp("     |05__358| <VLDUnit_V> g%d, V, # midpoint_selected=%d \n", dsc_state->groupCount, midpoint_selected);
//ppp("     |05__359| <VLDUnit_V> g%d, V, # shifter[V].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[V].read_ptr, dsc_state->shifter[V].read_ptr/8, dsc_state->shifter[V].data[dsc_state->shifter[V].read_ptr/8]);

        // Get bits from input bitstream
        max_size = 0;
        for ( i=0; i<SAMPLES_PER_UNIT; i++ ) {
                quantized_residuals[i]  = GetBits(dsc_cfg, dsc_state, V, size, 1, *byte_in_p);  // get 3*size bit from shifter[V]
//ppp("     |05__360| <VLDUnit_V> g%d, V, # shifter[V].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[V].read_ptr, dsc_state->shifter[V].read_ptr/8, dsc_state->shifter[V].data[dsc_state->shifter[V].read_ptr/8]);
                required_size[i]        = FindResidualSize( quantized_residuals[i] );
                max_size                = MAX( required_size[i], max_size );
        }

//ppp("     |05__361| <VLDUnit_V> g%d, V, # shifter[V].data[%d/8=%d]=%02x \n", dsc_state->groupCount, dsc_state->shifter[V].read_ptr, dsc_state->shifter[V].read_ptr/8, dsc_state->shifter[V].data[dsc_state->shifter[V].read_ptr/8]);
//ppp("     |05__362| <VLDUnit_V> g%d, V, # shifter[V].fullness=%d \n", dsc_state->groupCount, dsc_state->shifter[V].fullness);

//ppp("     |05__363| <VLDUnit_V> g%d, V, # q_r[samp0]=%d (new)\n", dsc_state->groupCount,quantized_residuals[0]);
//ppp("     |05__364| <VLDUnit_V> g%d, V, # q_r[samp1]=%d (new)\n", dsc_state->groupCount,quantized_residuals[1]);
//ppp("     |05__365| <VLDUnit_V> g%d, V, # q_r[samp2]=%d (new)\n", dsc_state->groupCount,quantized_residuals[2]);

//ppp("     |05__366| <VLDUnit_V> g%d, V, # r_s[samp0]=%d \n", dsc_state->groupCount,required_size[0]);
//ppp("     |05__367| <VLDUnit_V> g%d, V, # r_s[samp1]=%d \n", dsc_state->groupCount,required_size[1]);
//ppp("     |05__368| <VLDUnit_V> g%d, V, # r_s[samp2]=%d \n", dsc_state->groupCount,required_size[2]);

//ppp("     |05__369| <VLDUnit_V> g%d, V, # max_size=%d \n", dsc_state->groupCount,max_size);

        if (midpoint_selected)
        {
                max_size = size;
                for (i=0; i<SAMPLES_PER_UNIT; ++i)
                        required_size[i] = size;
        }

//ppp("     |05__370| <VLDUnit_V> g%d, V, # r_s[samp0]=%d \n", dsc_state->groupCount,required_size[0]);
//ppp("     |05__371| <VLDUnit_V> g%d, V, # r_s[samp1]=%d \n", dsc_state->groupCount,required_size[1]);
//ppp("     |05__372| <VLDUnit_V> g%d, V, # r_s[samp2]=%d \n", dsc_state->groupCount,required_size[2]);

        // rate control size uses max required size plus 1 (for prefix value of 0)
        dsc_state->rcSizeUnit[V] = max_size*SAMPLES_PER_UNIT + 1;
//ppp("     |05__373| <VLDUnit_V> g%d, V, # rcSizeUnit[V]=%d \n", dsc_state->groupCount, dsc_state->rcSizeUnit[V]);

        //
        // Predict size for next unit for this component
        // and store predicted size to state structure
        //printf("%d\n",);
        dsc_state->predictedSize[V] = PredictSize(dsc_cfg, dsc_state, required_size, slicenum);
//ppp("     |05__374| <VLDUnit_V> g%d, V, # predictedSize[V]=%d \n", dsc_state->groupCount, dsc_state->predictedSize[V]);
        //printf("%d\n", dsc_state->predictedSize[cpnt]);
}

// ======================================================================================== begin
//! Decode one group
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param byte_in_p Pointer to compressed data buffer (modified) */
void VLDGroup(dsc_cfg_t* dsc_cfg, dsc_state_t* dsc_state, unsigned char** byte_in_p, unsigned int *cnt_mw, int slicenum, FILE *gold_ichSelected, FILE *gold_useMidpoint)
{
        int prevNumBits = dsc_state->numBits;
        //printf("%d\n", dsc_state->numBits); //0.71.88.104.120....
        int i;

//ppp("     |05__375| # void VLDGroup \n");
        if (dsc_cfg->muxing_mode) {
                ProcessGroupDec(dsc_cfg, dsc_state, *byte_in_p, cnt_mw, slicenum);  // derive 6 bytes from byte_in_p to shifter if shifter.fullness < 44
                //printf("hpos=%d\n", dsc_state->hPos); //0.2.5.8...
				//===============================================
                                //
                                //              byte_in_p
				//              ________
				//             |________|
				//             |________|
				//             |________|
				//             |________|<- rptr (=postMuxNumBits/8)
				//             |________|
				//
				//            d    = buf[rptr] ;
				//            rptr = rptr+1    ;

				//===============================================
                                //
                                //                shifter
				//                ________
				//               |________|
				//               |________|
				// write_ptr/8 ->|________|
				//               |________|
				//               |________|
				//
				//            fullness        = fullness + 8;
				//            max_fullness    = fullness or keep;
				//            shifter[wptr/8] = d           ;
				//            wptr/8          = wptr/8   + 1;
				//
				//
        }
        // *MODEL NOTE* MN_DEC_ENTROPY
        // 444; Unit is same as CType
//      for (i=0; i<NUM_COMPONENTS; ++i)
//              VLDUnit(dsc_cfg, dsc_state, i, dsc_state->quantizedResidual[i], byte_in_p);


//ppp("     # ----------- Y -----------\n");
                VLDUnit_Y(dsc_cfg, dsc_state, dsc_state->quantizedResidual[0], byte_in_p, slicenum);
//ppp("     # ----------- U -----------\n");
                VLDUnit_U(dsc_cfg, dsc_state, dsc_state->quantizedResidual[1], byte_in_p, slicenum);
//ppp("     # ----------- V -----------\n");
                VLDUnit_V(dsc_cfg, dsc_state, dsc_state->quantizedResidual[2], byte_in_p, slicenum);
//ppp(" \n");
  fppp(gold_ichSelected, "g%d,s%d,ichSelected=%d\n", dsc_state->groupCount, slicenum, dsc_state->ichSelected);
  fppp(gold_useMidpoint, "g%d,s%d,useMidpoint[%c]=%d\n", dsc_state->groupCount, slicenum, 'Y', dsc_state->useMidpoint[0]);
  fppp(gold_useMidpoint, "g%d,s%d,useMidpoint[%c]=%d\n", dsc_state->groupCount, slicenum, 'U', dsc_state->useMidpoint[1]);
  fppp(gold_useMidpoint, "g%d,s%d,useMidpoint[%c]=%d\n", dsc_state->groupCount, slicenum, 'V', dsc_state->useMidpoint[2]);

//ppp("     |05__376| <VLDG> g%d, bufferFullness=%d \n", dsc_state->groupCount, dsc_state->bufferFullness);
        dsc_state->prevMasterQp = dsc_state->masterQp;
        dsc_state->codedGroupSize = dsc_state->numBits - prevNumBits;
        //printf("%d\n", dsc_state->codedGroupSize);
        dsc_state->bufferFullness += dsc_state->codedGroupSize;

//ppp("     --------------------------- \n");
//ppp("     |05__377| <VLDG> g%d, prevMasterQp  =%d \n", dsc_state->groupCount, dsc_state->prevMasterQp  );
//ppp("     |05__378| <VLDG> g%d, codedGroupSize=%d \n", dsc_state->groupCount, dsc_state->codedGroupSize);
//ppp("     |05__379| <VLDG> g%d, bufferFullness_VLDG=%d \n", dsc_state->groupCount, dsc_state->bufferFullness);

        //printf("%d\n", dsc_state->bufferFullness);
//           if ( dsc_state->bufferFullness > dsc_cfg->rcb_bits ) {
//                   // This check may actually belong after tgt_bpg has been subtracted
//                   printf("The buffer model has overflowed.  This probably occurred due to an attempt to decode an invalid DSC stream.\n\n");
//                   printf( "ERROR: RCB overflow; size is %d, tried filling to %d\n", dsc_cfg->rcb_bits, dsc_state->bufferFullness );
//                   exit(1);
//           }

        //printf("%d\n", dsc_state->firstFlat);
        if ((dsc_state->groupCount % GROUPS_PER_SUPERGROUP) == dsc_state->firstFlat)
                dsc_state->origIsFlat = 1;
        else
                dsc_state->origIsFlat = 0;

//ppp("     |05__380| <VLDG> g%d, origIsFlat=%d \n", dsc_state->groupCount, dsc_state->origIsFlat);
//if(dsc_state->groupCount==7000) assert(0);
        dsc_state->groupCountLine++; // useless

}


// ======================================================================================== begin
//! Reduce the bits required for a previous reconstructed line sample (currently via rounding)
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param x         The sample
        \param cpnt      Component to process */
int SampToLineBuf( dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int x, int cpnt, int slicenum)
{
        int shift_amount, round, storedSample;

//ppp("     |05__381| # int SampToLineBuf \n");
        // *MODEL NOTE* MN_LINE_STORAGE
        //printf("%d\n", dsc_cfg->linebuf_depth);//9
        shift_amount = MAX(dsc_state->cpntBitDepth[cpnt] - dsc_cfg->linebuf_depth, 0);
        if (shift_amount > 0)
                round = 1<<(shift_amount-1);
        else
                round = 0;

        storedSample = MIN(((x+round)>>shift_amount), (1<<dsc_cfg->linebuf_depth) - 1);
        return (storedSample << shift_amount);
}


// ======================================================================================== begin
//! Initialize the DSC state
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \return          Returns dsc_state that was passed in */
dsc_state_t *InitializeDSCState( dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int slicenum )
{
        int i, j, k;

        memset(dsc_state, 0, sizeof(dsc_state_t));

        // Initialize quantization table
        if (dsc_cfg->bits_per_component == 12)
        {
                dsc_state->quantTableLuma = qlevel_luma_12bpc;
                dsc_state->quantTableChroma = qlevel_chroma_12bpc;
        } else if (dsc_cfg->bits_per_component == 10) {
                dsc_state->quantTableLuma = qlevel_luma_10bpc;
                dsc_state->quantTableChroma = qlevel_chroma_10bpc;
        } else {
                dsc_state->quantTableLuma = qlevel_luma_8bpc;
                dsc_state->quantTableChroma = qlevel_chroma_8bpc;
        }

//ppp("     |05__382| dsc_cfg->bits_per_component = %d \n", dsc_cfg->bits_per_component);
        // initialize dsc state
        dsc_state->numBits            = 0;
        dsc_state->prevNumBits        = 0;
        dsc_state->bufferFullness     = 0;
        dsc_state->stQp               = 0;
        dsc_state->prevQp             = 0;
        dsc_state->masterQp           = 0;
        dsc_state->prevMasterQp       = 0;
        dsc_state->rcSizeGroup        = 0;
        dsc_state->nonFirstLineBpgTarget = 0;
        dsc_state->rcXformOffset     = dsc_cfg->initial_offset;
        dsc_state->throttleInt       = 0;
        dsc_state->throttleFrac      = 0;
        dsc_state->firstFlat         = -1;
        dsc_state->prevFirstFlat     = -1;
        for ( i=0; i<NUM_COMPONENTS; i++ ) {
                dsc_state->predictedSize[i] = 0;
                for ( j=0; j<SAMPLES_PER_UNIT; j++ )
                        dsc_state->quantizedResidual[i][j] = 0;
        }
        for ( i=0; i<MAX_UNITS_PER_GROUP; i++ ) {
                dsc_state->rcSizeUnit[i] = 0;
        }

        for (i=0; i<NUM_COMPONENTS; ++i)
        {
                for(j=0; j<BP_RANGE/*10*/; ++j)
                {
                        for(k=0; k<BP_SIZE/*3*/; ++k)
                                dsc_state->lastErr[i][k][j] = 0;
                }
        }
//ppp("     |05__383| MAX_UNITS_PER_GROUP (def''d) = %d \n"   , MAX_UNITS_PER_GROUP   );
//ppp("     |05__384| BP_RANGE (def''d) = %d \n"              , BP_RANGE              );
//ppp("     |05__385| BP_SIZE (def''d) = %d \n"               , BP_SIZE               );
//ppp("     |05__386| sizeof(PRED_TYPE) (def''d) = %ld \n"     , sizeof(PRED_TYPE)     );
//ppp("     |05__387| prevLinePred entry count = %d \n"       , (dsc_cfg->slice_width+PRED_BLK_SIZE-1) / PRED_BLK_SIZE);

        dsc_state->prevLinePred = (PRED_TYPE *)malloc(sizeof(PRED_TYPE) * (dsc_cfg->slice_width+PRED_BLK_SIZE/*3*/-1) / PRED_BLK_SIZE/*3*/);
        assert(dsc_state->prevLinePred != NULL);
        // Sets last predictor of line to MAP, since BP search is not done for partial groups
        memset(dsc_state->prevLinePred, 0, sizeof(PRED_TYPE) * (dsc_cfg->slice_width+PRED_BLK_SIZE/*3*/-1) / PRED_BLK_SIZE/*3*/);
        dsc_state->history.valid = (int *)malloc(sizeof(int)*ICH_SIZE);
        assert(dsc_state->history.valid != NULL);

//ppp("     |05__388| ICH_SIZE (unit:entries)=%d \n"        , ICH_SIZE);
        for(i=0; i<ICH_SIZE; ++i)
                dsc_state->history.valid[i] = 0;
        for(i=0; i<NUM_COMPONENTS; ++i)
        {
                dsc_state->history.pixels[i] = (unsigned int*)malloc(sizeof(unsigned int)*ICH_SIZE);
        }
        dsc_state->ichSelected = 0;

        for(i=0; i<NUM_COMPONENTS; ++i)
        {
//ppp("\n");
//ppp("     |05__389| # ============================================= \n");
//ppp("     |05__390| # ================== FOR_fifo_init BEGIN ================ \n");
//ppp("     |05__391| cpnt=%d, mux_word_size = %d \n", i, dsc_cfg->mux_word_size);
//ppp("     |05__392| cpnt=%d, MAX_SE_SIZE   = %d \n", i, MAX_SE_SIZE           );
//ppp("     |05__393| cpnt=%d, shifter[i]        size = %d \n", i, (dsc_cfg->mux_word_size + MAX_SE_SIZE + 7) / 8                     );
//ppp("     |05__394| cpnt=%d, encBalanceFifo[i] size = %d \n", i, ((dsc_cfg->mux_word_size + MAX_SE_SIZE - 1) * (MAX_SE_SIZE) + 7)/8 );
//ppp("     |05__395| cpnt=%d, seSizeFifo[i]     size = %d \n", i, (6 * (dsc_cfg->mux_word_size + MAX_SE_SIZE - 1) + 7)/8             );
                fifo_init(&(dsc_state->shifter[i])       , (dsc_cfg->mux_word_size + MAX_SE_SIZE + 7) / 8 );
                fifo_init(&(dsc_state->encBalanceFifo[i]), ((dsc_cfg->mux_word_size + MAX_SE_SIZE - 1) * (MAX_SE_SIZE) + 7)/8 );
                fifo_init(&(dsc_state->seSizeFifo[i])    , (6 * (dsc_cfg->mux_word_size + MAX_SE_SIZE - 1) + 7)/8 );
//ppp("     |05__396| # ================== FOR_fifo_init END ================== \n");
//ppp("     |05__397| # ============================================= \n\n");
        }

        return dsc_state;
}


// ======================================================================================== begin
//! Calculate offset & scale values for rate control
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure
        \param vPos    Current vertical position in slice
        \param group_count Group counter
        \param scale     Scale factor for RC (returned)
        \param bpgOffset BPG Offset value for RC (returned)  */
void CalcFullnessOffset(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state, int vPos, int group_count, int *scale, int *bpg_offset, int slicenum)
{
        // positive offset takes bits away, negative offset provides more bits
        int current_bpg_target;
        int unity_scale;
        int increment;

//ppp("     |05__398| # void CalcFullnessOffset \n");
        // *MODEL NOTE* MN_CALC_SCALE_OFFSET
        unity_scale = (1<<RC_SCALE_BINARY_POINT); /*4'b1000*/

//ppp("    # Before_Before_Before_Before_Before_BEFORE \n");
//ppp("     |05__399| <CFO> g%d, cS=%d (meta) \n", dsc_state->groupCount, dsc_state->currentScale);
//ppp("     |05__400| <CFO> g%d, sIS=%d (meta)\n", dsc_state->groupCount, dsc_state->scaleIncrementStart);
//ppp("     |05__401| <CFO> g%d, i_s_v=%d (final) \n", dsc_state->groupCount, dsc_cfg->initial_scale_value);
//ppp("     |05__402| <CFO> g%d, sAC=%d (meta) \n", dsc_state->groupCount, dsc_state->scaleAdjustCounter);
//ppp("     |05__403| <CFO> g%d, s_d_i=%d (final) \n", dsc_state->groupCount, dsc_cfg->scale_decrement_interval);
//ppp("     |05__404| <CFO> g%d, s_i_i=%d (meta) \n", dsc_state->groupCount, dsc_cfg->scale_increment_interval);

        if (group_count == 0)
        {
                dsc_state->currentScale/*cS*/ = dsc_cfg->initial_scale_value;
                dsc_state->scaleAdjustCounter/*sAC*/ = 1;
        }
        else if ((vPos == 0) && (dsc_state->currentScale/*cS*/ > unity_scale))  // Reduce scale at beginning of slice
        {
                dsc_state->scaleAdjustCounter++/*sAC*/;
                if(dsc_state->scaleAdjustCounter/*sAC*/ >= dsc_cfg->scale_decrement_interval)
                {
                        dsc_state->scaleAdjustCounter/*sAC*/ = 0;
                        dsc_state->currentScale--/*cS*/;
                }
        }
        else if (dsc_state->scaleIncrementStart/*sIS*/)
        {
                dsc_state->scaleAdjustCounter++/*sAC*/;
                if (dsc_state->scaleAdjustCounter/*sAC*/ >= dsc_cfg->scale_increment_interval)
                {
                        dsc_state->scaleAdjustCounter/*sAC*/ = 0;
                        dsc_state->currentScale/*cS*/++;
                }
        }
//ppp("    # After_After_After_After_After_After_AFTER \n");
//ppp("     |05__405| <CFO> g%d, cS=%d (meta) \n", dsc_state->groupCount, dsc_state->currentScale);
//ppp("     |05__406| <CFO> g%d, sAC=%d (meta) \n", dsc_state->groupCount, dsc_state->scaleAdjustCounter);

//ppp("    # Before_Before_Before_Before_Before_BEFORE \n");
//ppp("     |05__407| <CFO> g%d, vPos=%d \n", dsc_state->groupCount, vPos);
//ppp("     |05__408| <CFO> g%d, first_line_bpg_ofs=%d (final) \n", dsc_state->groupCount, dsc_cfg->first_line_bpg_ofs );
//ppp("     |05__409| <CFO> g%d, OFFSET_FRACTIONAL_BITS=%d (final) \n", dsc_state->groupCount, OFFSET_FRACTIONAL_BITS );
//ppp("     |05__410| <CFO> g%d, first_line_bpg_ofs < < OFFSET_FRACTIONAL_BITS=%d (final) \n", dsc_state->groupCount, dsc_cfg->first_line_bpg_ofs << OFFSET_FRACTIONAL_BITS );
//ppp("     |05__411| <CFO> g%d, nfl_bpg_offset > > OFFSET_FRACTIONAL_BITS=%d (final) \n", dsc_state->groupCount, dsc_cfg->nfl_bpg_offset >> OFFSET_FRACTIONAL_BITS);
//ppp("     |05__412| <CFO> g%d, nfl_bpg_offset=%d (final) \n", dsc_state->groupCount, dsc_cfg->nfl_bpg_offset);
        // Account for first line boost
        if (vPos == 0)
        {
                current_bpg_target = dsc_cfg->first_line_bpg_ofs;
                increment = -(dsc_cfg->first_line_bpg_ofs << OFFSET_FRACTIONAL_BITS);
        } else {
                current_bpg_target = -(dsc_cfg->nfl_bpg_offset >> OFFSET_FRACTIONAL_BITS);
                increment = dsc_cfg->nfl_bpg_offset;
        }

//ppp("    # After_After_After_After_After_After_AFTER \n");
//ppp("     |05__413| <CFO> g%d, c_b_t=%d (meta) \n", dsc_state->groupCount, current_bpg_target);
//ppp("     |05__414| <CFO> g%d, increment=%d (meta) \n", dsc_state->groupCount, increment);

//ppp("    # Before_Before_Before_Before_Before_BEFORE \n");
//ppp("     |05__415| <CFO> g%d, pC=%d \n", dsc_state->groupCount, dsc_state->pixelCount);
//ppp("     |05__416| <CFO> g%d, prevPC=%d \n", dsc_state->groupCount, dsc_state->prevPixelCount);
//ppp("     |05__417| <CFO> g%d, i_x_d=%d \n", dsc_state->groupCount, dsc_cfg->initial_xmit_delay);
//ppp("     |05__418| <CFO> g%d, s_i_i=%d (final) \n", dsc_state->groupCount, dsc_cfg->scale_increment_interval);
//ppp("     |05__419| <CFO> g%d, sIS=%d (meta) \n", dsc_state->groupCount, dsc_state->scaleIncrementStart);
//ppp("     |05__420| <CFO> g%d, vPos=%d \n", dsc_state->groupCount, vPos);
//ppp("     |05__421| <CFO> g%d, rcXO=%d (meta) \n", dsc_state->groupCount, dsc_state->rcXformOffset);
//ppp("     |05__422| <CFO> g%d, b_p_p=%d \n", dsc_state->groupCount, dsc_cfg->bits_per_pixel);

        // Account for initial delay boost
        if (dsc_state->pixelCount < dsc_cfg->initial_xmit_delay)
        {
                int num_pixels;

                if(dsc_state->pixelCount == 0)
                        num_pixels = PIXELS_PER_GROUP;
                else
                        num_pixels = dsc_state->pixelCount - dsc_state->prevPixelCount;

//ppp("     |05__423| <CFO> g%d, num_pixels=%d (meta) \n", dsc_state->groupCount, num_pixels);
                num_pixels = MIN(dsc_cfg->initial_xmit_delay - dsc_state->pixelCount, num_pixels);
//ppp("     |05__424| <CFO> g%d, num_pixels=%d (final) \n", dsc_state->groupCount, num_pixels);

                increment -= (dsc_cfg->bits_per_pixel * num_pixels) << (OFFSET_FRACTIONAL_BITS - 4);
        }
        else
        {
                if (dsc_cfg->scale_increment_interval && !dsc_state->scaleIncrementStart/*sIS*/ && (vPos > 0) && (dsc_state->rcXformOffset/*rcXO*/ > 0))
                {
                        dsc_state->currentScale/*cS*/ = 9;
                        dsc_state->scaleAdjustCounter/*sAC*/ = 0;
                        dsc_state->scaleIncrementStart/*sIS*/ = 1;
                }
        }

//ppp("    # After_After_After_After_After_After_AFTER \n");
//ppp("     |05__425| <CFO> g%d, increment=%d (meta) \n", dsc_state->groupCount, increment);
//ppp("     |05__426| <CFO> g%d, cS=%d (final) \n", dsc_state->groupCount, dsc_state->currentScale);
//ppp("     |05__427| <CFO> g%d, sAC=%d (final) \n", dsc_state->groupCount, dsc_state->scaleAdjustCounter);
//ppp("     |05__428| <CFO> g%d, sIS=%d (final) \n", dsc_state->groupCount, dsc_state->scaleIncrementStart);


        dsc_state->prevPixelCount = dsc_state->pixelCount;

//ppp("    # Before_Before_Before_Before_Before_BEFORE \n");
//ppp("     |05__429| <CFO> g%d, c_b_t=%d (meta) \n", dsc_state->groupCount, current_bpg_target);
//ppp("     |05__430| <CFO> g%d, increment=%d (meta) \n", dsc_state->groupCount, increment);
//ppp("     |05__431| <CFO> g%d, tF=%d (meta) \n", dsc_state->groupCount, dsc_state->throttleFrac);
//ppp("     |05__432| <CFO> g%d, rcXO=%d (meta) \n", dsc_state->groupCount, dsc_state->rcXformOffset);
//ppp("     |05__433| <CFO> g%d, s_b_o=%d \n", dsc_state->groupCount, dsc_cfg->slice_bpg_offset);

        current_bpg_target -= (dsc_cfg->slice_bpg_offset>>OFFSET_FRACTIONAL_BITS);
        increment += dsc_cfg->slice_bpg_offset;

//ppp("     |05__434| <CFO> g%d, increment=%d (meta) \n", dsc_state->groupCount, increment);

        dsc_state->throttleFrac += increment;
        dsc_state->rcXformOffset/*rcXO*/ += dsc_state->throttleFrac >> OFFSET_FRACTIONAL_BITS;
        dsc_state->throttleFrac = dsc_state->throttleFrac & ((1<<OFFSET_FRACTIONAL_BITS)-1);

//ppp("    # After_After_After_After_After_After_AFTER \n");
//ppp("     |05__435| <CFO> g%d, c_b_t=%d (final) \n", dsc_state->groupCount, current_bpg_target);
//ppp("     |05__436| <CFO> g%d, increment=%d (final) \n", dsc_state->groupCount, increment);
//ppp("     |05__437| <CFO> g%d, tF=%d (final) \n", dsc_state->groupCount, dsc_state->throttleFrac);
//ppp("     |05__438| <CFO> g%d, rcXO=%d (meta) \n", dsc_state->groupCount, dsc_state->rcXformOffset);

//ppp("    # Before_Before_Before_Before_Before_BEFORE \n");
//ppp("     |05__439| <CFO> g%d, rcOffsetClampEnable =%d (meta) \n", dsc_state->groupCount, dsc_state->rcOffsetClampEnable);
//ppp("     |05__440| <CFO> g%d, rcXO=%d (meta) \n", dsc_state->groupCount, dsc_state->rcXformOffset);
//ppp("     |05__441| <CFO> g%d, final_offset=%d (final) \n", dsc_state->groupCount, dsc_cfg->final_offset);
        if(dsc_state->rcXformOffset/*rcXO*/ < dsc_cfg->final_offset)  // garbage ?
                dsc_state->rcOffsetClampEnable/*localking*/ = 1;      // garbage ?

        if(dsc_state->rcOffsetClampEnable/*localking*/)
                dsc_state->rcXformOffset/*rcXO*/ = MIN(dsc_state->rcXformOffset/*rcXO*/, dsc_cfg->final_offset);

//ppp("    # After_After_After_After_After_After_AFTER \n");
//ppp("     |05__442| <CFO> g%d, rcOffsetClampEnable =%d (final) \n", dsc_state->groupCount, dsc_state->rcOffsetClampEnable);
//ppp("     |05__443| <CFO> g%d, rcXO=%d (final) \n", dsc_state->groupCount, dsc_state->rcXformOffset);

        *scale = dsc_state->currentScale/*cS*/;
        *bpg_offset = current_bpg_target;
}


// ======================================================================================== begin
//! Main DSC encoding and decoding algorithm
/*! \param isEncoder Flag indicating whether to do an encode (1) or decode (0)
    \param dsc_cfg   DSC configuration structure
        \param ip        Input picutre
        \param op        Output picture (modified, only affects area of current slice)
        \param cmpr_buf  Compressed data buffer (modified for encoder)
        \param temp_pic  Array of two temporary pictures to use for RGB-YCoCg conversion and back
        \param chunk_sizes Array to hold sizes in bytes for each slice multiplexed chunk (modified for encoder) */
int DSC_Algorithm(int isEncoder, dsc_cfg_t* dsc_cfg, pic_t* ip, pic_t* op, unsigned char* cmpr_buf, pic_t **temp_pic, int *chunk_sizes/*useless*/, int slicenum, FILE *gold_ICH           ,
                                                                                                                                                                 FILE *gold_ichSelected   ,
                                                                                                                                                                 FILE *gold_useMidpoint   ,
                                                                                                                                                                 FILE *gold_pred_x_SP     ,
                                                                                                                                                                 FILE *gold_err_q         ,
                                                                                                                                                                 FILE *gold_pred_x        ,
                                                                                                                                                                 FILE *gold_recon_x_clamp ,
                                                                                                                                                                 FILE *gold_recon_x_final ,
                                                                                                                                                                 FILE *gold_qp            ,
                                                                                                                                                                 FILE *gold_rgb           )
{
        dsc_state_t dsc_state_storage, *dsc_state;
        pic_t* pic, *orig_op, *opic;
        int i;
        int vPos;
        int hPos;
        unsigned int cnt_mw=0;
        int done;
        int hSkew = PADDING_LEFT;    // there are hSkew fake pixels to the left of first real pixel
        int sampModCnt;
        int cpnt;
        int pred_x;
        int actual_x = 0;
        int recon_x;
        int err_raw;
        int err_raw_new;
        int err_q;
        int *currLine[NUM_COMPONENTS];
        int *prevLine[NUM_COMPONENTS];
        int lbufWidth;
        int range[NUM_COMPONENTS];
        int maxval;
        int qp;
        int qlevel;
        int group_count = 0;
        int throttle_offset, bpg_offset;
        int scale;
        int new_quant;
        int iter,iter1,iter2,iter3;
        PRED_TYPE pred2use;
        int h_offset_array_idx;

//      FILE *reconlog = fopen("recon_x_golden.txt","wt");
  printf("     \%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%");
  printf("\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\%\n");
  printf("     |05__444| # int DSC_Algorithm \n");
  printf("     |05__445| # slicenum = %d \n", slicenum);


#ifdef PRINTDEBUG
        if(isEncoder)
                g_fp_dbg = fopen("log_encode.txt","wt");
        else
                g_fp_dbg = fopen("log_decode.txt","wt");
#endif


        dsc_state             = InitializeDSCState( dsc_cfg, &dsc_state_storage, slicenum);
        dsc_state->isEncoder  = isEncoder;
        dsc_state->chunkSizes/*useless*/ = chunk_sizes/*useless*/;


        orig_op = op;
        if ( dsc_cfg->convert_rgb ) {
                // convert rgb to ycocg
                pic = temp_pic[0];  // temp space 1
                opic = temp_pic[1]; // temp space 2
                op = opic;          // temp space 2

//ppp("     |05__446| \n");
//ppp("     |05__447| midpointSelected[0]=%d, [1]=%d, [2]=%d \n", dsc_state->midpointSelected[0], dsc_state->midpointSelected[1], dsc_state->midpointSelected[2]);
                rgb2ycocg(ip, pic, dsc_cfg);
        } else {
                // no color conversion
                pic = ip;
        }

        // line buffers have padding to left and right
        lbufWidth = dsc_cfg->slice_width + PADDING_LEFT + PADDING_RIGHT; // pixels to left and right

        //printf("%d\n", pic->bits); //8
        // initialize DSC variables
        for ( cpnt = 0; cpnt<NUM_COMPONENTS; cpnt++ )
        {
                int initValue;
                if ( dsc_cfg->convert_rgb )
                {
                        initValue = 1 << (pic->bits - 1);
                        if(cpnt != 0)
                                initValue *= 2;
                }
                else
                        initValue = 1 << (pic->bits-1);


                dsc_state->currLine[cpnt] = currLine[cpnt] = (int*) malloc(lbufWidth*sizeof(int)); // dsc_state->currLine and currLine has the same pointer
                dsc_state->prevLine[cpnt] = prevLine[cpnt] = (int*) malloc(lbufWidth*sizeof(int));
                dsc_state->origLine[cpnt]/*useless*/ = (int*) malloc(lbufWidth*sizeof(int));
                for ( i=0; i<lbufWidth; i++ ) {
                        currLine[cpnt][i] = initValue;
                        prevLine[cpnt][i] = initValue;
                }
        }

        //--------------------------------------------------------------------------
        // sample range handling
        //
        if ( pic->bits != dsc_cfg->bits_per_component )
        {
                //printf("%d , %d \n", pic->bits, dsc_cfg->bits_per_component);
                printf("ERROR: Expect picture bit depth to match configuration\n");
                exit(1);
        }

        for ( i=0; i<NUM_COMPONENTS; i++ )
        {
                range[i] = 1<<dsc_cfg->bits_per_component;
                dsc_state->cpntBitDepth[i] = dsc_cfg->bits_per_component;
        }

        if (dsc_cfg->convert_rgb)
        {
                range[1] *= 2;
                range[2] *= 2;
                dsc_state->cpntBitDepth[1]++;
                dsc_state->cpntBitDepth[2]++;
        }

        dsc_state->groupCountLine = 0; // useless
        // If decoder, read first group's worth of data
        if ( !isEncoder )
                VLDGroup( dsc_cfg, dsc_state, &cmpr_buf, &cnt_mw, slicenum, gold_ichSelected, gold_useMidpoint);
//ppp("     |05__448| linebuf_depth=%d \n", (1<<dsc_cfg->linebuf_depth) -1);

        vPos = 0;
        hPos = 0;
        sampModCnt = 0;
        done = 0;
        dsc_state->hPos = 0;
        dsc_state->vPos = 0;

        new_quant = 0;
        qp = 0;
        iter2 = 0;

//           if (isEncoder)
//                   PopulateOrigLine(dsc_cfg, dsc_state, pic, 0);

//ppp("     |05__449| ================================================================= \n");
//ppp("     |05__450|  currLine[cpnt=0][i+PADDING_LEFT=0]=%x \n", dsc_state->currLine[0][0] );
//ppp("     |05__451|  currLine[cpnt=1][i+PADDING_LEFT=0]=%x \n", dsc_state->currLine[1][0] );
//ppp("     |05__452|  currLine[cpnt=2][i+PADDING_LEFT=0]=%x \n", dsc_state->currLine[2][0] );
//ppp("     # ----------------------------------------------------------------- \n");
//ppp("     |05__453|  currLine[cpnt=0][i+PADDING_LEFT=1]=%x \n", dsc_state->currLine[0][1] );
//ppp("     |05__454|  currLine[cpnt=1][i+PADDING_LEFT=1]=%x \n", dsc_state->currLine[1][1] );
//ppp("     |05__455|  currLine[cpnt=2][i+PADDING_LEFT=1]=%x \n", dsc_state->currLine[2][1] );
//ppp("     |05__456|  . . . . . . \n");
//ppp("     |05__457|  currLine[cpnt=0][i+PADDING_LEFT=5]=%x \n", dsc_state->currLine[0][5] );
//ppp("     |05__458|  currLine[cpnt=1][i+PADDING_LEFT=5]=%x \n", dsc_state->currLine[1][5] );
//ppp("     |05__459|  currLine[cpnt=2][i+PADDING_LEFT=5]=%x \n", dsc_state->currLine[2][5] );
//ppp("     # ----------------------------------------------------------------- \n");
//ppp("     |05__460|  currLine[cpnt=0][i+PADDING_LEFT=6]=%x \n", dsc_state->currLine[0][6] );
//ppp("     |05__461|  currLine[cpnt=1][i+PADDING_LEFT=6]=%x \n", dsc_state->currLine[1][6] );
//ppp("     |05__462|  currLine[cpnt=2][i+PADDING_LEFT=6]=%x \n", dsc_state->currLine[2][6] );
//ppp("     |05__463|  . . . . . . \n");
//ppp("     |05__464|  currLine[cpnt=0][i+PADDING_LEFT=1083]=%x \n", dsc_state->currLine[0][1083] );
//ppp("     |05__465|  currLine[cpnt=1][i+PADDING_LEFT=1083]=%x \n", dsc_state->currLine[1][1083] );
//ppp("     |05__466|  currLine[cpnt=2][i+PADDING_LEFT=1083]=%x \n", dsc_state->currLine[2][1083] );
//ppp("     # ----------------------------------------------------------------- \n");
//ppp("     |05__467|  currLine[cpnt=0][i+PADDING_LEFT=1084]=%x \n", dsc_state->currLine[0][1084] );
//ppp("     |05__468|  currLine[cpnt=1][i+PADDING_LEFT=1084]=%x \n", dsc_state->currLine[1][1084] );
//ppp("     |05__469|  currLine[cpnt=2][i+PADDING_LEFT=1084]=%x \n", dsc_state->currLine[2][1084] );
//ppp("     |05__470|  . . . . . . \n");
//ppp("     |05__471|  currLine[cpnt=0][i+PADDING_LEFT=1088]=%x \n", dsc_state->currLine[0][1088] );
//ppp("     |05__472|  currLine[cpnt=1][i+PADDING_LEFT=1088]=%x \n", dsc_state->currLine[1][1088] );
//ppp("     |05__473|  currLine[cpnt=2][i+PADDING_LEFT=1088]=%x \n", dsc_state->currLine[2][1088] );
//ppp("     # ----------------------------------------------------------------- \n");
//ppp("     |05__474|  currLine[cpnt=0][i+PADDING_LEFT=1089]=%x \n", dsc_state->currLine[0][1089] );
//ppp("     |05__475|  currLine[cpnt=1][i+PADDING_LEFT=1089]=%x \n", dsc_state->currLine[1][1089] );
//ppp("     |05__476|  currLine[cpnt=2][i+PADDING_LEFT=1089]=%x \n", dsc_state->currLine[2][1089] );
//ppp("     # ----------------------------------------------------------------- \n");
//ppp("                   \n");



        int while_cnt=0;

        while ( !done ) {
        char c_cpnt;


//ppp("      # ----------------------------------------------------------- \n");
//ppp("      # -------- WHILE_%d BEGIN ----------------------------------- \n", while_cnt);
//ppp(" \n");
//ppp(" \n");


                dsc_state->vPos = vPos;

//ppp("      # ----------------------------------------------------------- \n");
//ppp("      # -------- ich BEGIN ---------------------------------------- \n");
//ppp("     |05__477| <ich> g%d, (v,h)=(%d,%d) \n", dsc_state->groupCount, vPos, hPos);
                if ((hPos % PIXELS_PER_GROUP)==0)                                                        //
                {                                                                                        // �� hpos=3��, st_hpos=2, ��currLine[0,1,2]���e
                        // Note that UpdateICHistory works on the group to the left                      // ��� history.pixels�̡A���e�@��grp��XichSelected�A
                        for (i=0; i<PIXELS_PER_GROUP; ++i)                                               // �M�� history.pixels���M currLine[0,1,2]�ǰt��entry,
                                UpdateICHistory(dsc_cfg, dsc_state, currLine, sampModCnt, hPos+i, vPos, slicenum, gold_ICH); // �Y�e�@��grp��X�Ӫ�ichSelected=0�A�h�y�����~
                }

//ppp("      # -------- ich END ------------------------------------------ \n");
//ppp("      # ----------------------------------------------------------- \n");

                for ( cpnt = 0; cpnt<NUM_COMPONENTS; cpnt++ ) {
//ppp(" \n");
//ppp("      # ----------------------------------------------------------- \n");
//ppp("      # -------- recon_x BEGIN ------------------------------------ \n");
                        qlevel = MapQpToQlevel(dsc_state, qp, cpnt);
                        char c_cpnt;
                        if(cpnt==0) c_cpnt='Y'; else if(cpnt==1) c_cpnt='U'; else c_cpnt='V';

                        if (vPos==0)
                        {
                                // Use left predictor.  Modified MAP doesn't make sense since there is no previous line.
                                pred2use = PT_LEFT/*1*/;                                     // ----- func of hPos/vPos
                        }
                        else
                        {
                                pred2use = dsc_state->prevLinePred[hPos/PRED_BLK_SIZE/*3*/];  // �S���D�A�e���u����T���w�Ƨ�
                        }

//ppp("     |05__478| <recon_x> g%d, %c, (v,h)=(%d,%d), pred2use(%d)=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, hPos/PRED_BLK_SIZE, pred2use);
                        h_offset_array_idx = (hPos / 3) * 3 + PADDING_LEFT;     // ----- func of hPos/vPos

                        pred_x = SamplePredict( dsc_state, prevLine[cpnt], currLine[cpnt], hPos, pred2use, qlevel, cpnt, slicenum); // hPos=0,1,2�ɡA�|�ϥΨ�currLine[-1] ����T�A�M���Uqlevel, qlevel �������h�Apred_x �i�w���o��
//ppp("     |05__479| <recon_x> g%d, (v,h)=(%d,%d), pred_x_SP[%c]=%d \n", dsc_state->groupCount, vPos, hPos, c_cpnt, pred_x);
  fppp(gold_pred_x_SP, "g%d,s%d,pred_x_SP[%c]=%d\n", dsc_state->groupCount, slicenum, c_cpnt, pred_x);
                                                                                                                          // hPos=3,4,5�ɡA�|�ϥΨ�currLine[ 2] ����T�A�M���Uqlevel, qlevel �������h�Apred_x �i�w���o��
                                                                                                                          // hPos=6,7,8�ɡA�|�ϥΨ�currLine[ 5] ����T�A�M���Uqlevel, qlevel �������h�Apred_x �i�w���o��
  //                           else  // DECODER:
  //                           {
                                // Decoder takes error from bitstream
                                err_q = dsc_state->quantizedResidual[cpnt][sampModCnt];

                                qlevel = MapQpToQlevel(dsc_state, qp, cpnt);

                                // Use midpoint prediction if selected
                                if (dsc_state->useMidpoint[cpnt]) {
                                        pred_x = FindMidpoint(dsc_state, cpnt, qlevel, slicenum);

                                }
  //                           }

//ppp("     |05__480| <recon_x> g%d, %c, (v,h)=(%d,%d), err_q[%c][samp%d]=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, c_cpnt, sampModCnt, err_q);
//ppp("     |05__481| <recon_x> g%d, %c, (v,h)=(%d,%d), qp=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, qp);
//ppp("     |05__482| <recon_x> g%d, %c, (v,h)=(%d,%d), qlevel=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, qlevel);
//ppp("     |05__483| <recon_x> g%d, %c, (v,h)=(%d,%d), pred_x[%c]=%d (final) \n", dsc_state->groupCount, c_cpnt, vPos, hPos, c_cpnt, pred_x);
//ppp("     |05__484| <recon_x> g%d, %c, (v,h)=(%d,%d), useMidpoint[%c]=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, c_cpnt, dsc_state->useMidpoint[cpnt]);
  fppp(gold_err_q, "g%d,s%d,err_q[%c]=%d\n", dsc_state->groupCount, slicenum, c_cpnt, err_q);
  fppp(gold_pred_x, "g%d,s%d,pred_x[%c]=%d\n", dsc_state->groupCount, slicenum, c_cpnt, pred_x);
                        //-----------------------------------------------------------------
                        // reconstruct
                        // *MODEL NOTE* MN_IQ_RECON
                        maxval = range[cpnt] - 1;       // ���`�ƭ�

//ppp("     |05__485| <recon_x> g%d, %c, (v,h)=(%d,%d), maxval[cpnt=%d]=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, cpnt, maxval);
//ppp("     |05__486| <recon_x> g%d, %c, (v,h)=(%d,%d), recon_x_unclamp=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos,pred_x+(err_q<<qlevel));

                        recon_x = CLAMP(pred_x + (err_q << qlevel), 0, maxval); // hPos=0,1,2�ɡA�|�ϥΨ�currLine[-1] ����T�A�M���Uqlevel, qlevel �������h�Aerr_q�i�w���o��Arecon_x �i�w���o��
                                                                                // hPos=3,4,5�ɡA�|�ϥΨ�currLine[ 2] ����T�A�M���Uqlevel, qlevel �������h�Aerr_q�i�w���o��Arecon_x �i�w���o��
                                                                                // hPos=6,7,8�ɡA�|�ϥΨ�currLine[ 5] ����T�A�M���Uqlevel, qlevel �������h�Aerr_q�i�w���o��Arecon_x �i�w���o��

//ppp("     |05__487| <recon_x> g%d, %c, (v,h)=(%d,%d), recon_x_clamp[%c]=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, c_cpnt, recon_x);
  fppp(gold_recon_x_clamp, "g%d,s%d,recon_x_clamp[%c]=%d\n", dsc_state->groupCount, slicenum, c_cpnt, recon_x);

//ppp("     |05__488| <recon_x> g%d, %c, (v,h)=(%d,%d), ichSelected[%c]=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, c_cpnt, dsc_state->ichSelected);

                        if (!isEncoder && dsc_state->ichSelected) {  // IC$ selected on decoder - do an ICH look-up
                                unsigned int p[NUM_COMPONENTS];
//ppp("     |05__489| <recon_x> g%d, %c, (v,h)=(%d,%d), ichLookup[%d]=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, sampModCnt, dsc_state->ichLookup[sampModCnt]);
                                HistoryLookup(dsc_cfg, dsc_state, dsc_state->ichLookup[sampModCnt]/*entry*/, p, hPos, (vPos==0)/*1st_line_flg*/, slicenum);
                                recon_x = p[cpnt];

                        }

//ppp("     |05__490| <recon_x> g%d, %c, (v,h)=(%d,%d), recon_x[%c]=%d (final)\n", dsc_state->groupCount, c_cpnt, vPos, hPos, c_cpnt, recon_x);

                        // Save reconstructed value in line store
                        currLine[cpnt][hPos+hSkew] = recon_x;               // �ѩ�Ccycle���|�Ϋe��currLine�A�G�Ccycle���n���ȥߧY�s�JcurrLine
//ppp("     |05__491| <recon_x> g%d, %c, (v,h)=(%d,%d), currLine[%c][%d+5]=%d \n", dsc_state->groupCount, c_cpnt, vPos, hPos, c_cpnt, hPos, currLine[cpnt][hPos+hSkew]);
  fppp(gold_recon_x_final, "g%d,s%d,currLine[%c][%d+5]=%d\n", dsc_state->groupCount, slicenum, c_cpnt, hPos, currLine[cpnt][hPos+hSkew]);

                        // Copy reconstructed samples to output picture structure
                        if ((vPos+dsc_cfg->ystart < op->h) && (hPos+dsc_cfg->xstart < op->w)) {
                                switch ( cpnt ) {
                                case  0: op->data.yuv.y[vPos+dsc_cfg->ystart][hPos+dsc_cfg->xstart] = recon_x; break; ////////////////////////////////////////////////////////////////////////////////////////////
                                case  1: op->data.yuv.u[vPos+dsc_cfg->ystart][hPos+dsc_cfg->xstart] = recon_x; break; ////////////////////////////////////////////////////////////////////////////////////////////
                                case  2: op->data.yuv.v[vPos+dsc_cfg->ystart][hPos+dsc_cfg->xstart] = recon_x; break; ////////////////////////////////////////////////////////////////////////////////////////////
                                }
                        }

//ppp("      # -------- recon_x END ------------------------------------- \n");
//ppp("      # ---------------------------------------------------------- \n\n");
                }


//ppp("      # ----------------------------------------------------------- \n");
//ppp("      # -------- update_qp BEGIN ---------------------------------- \n");
                // Update QP per group
//ppp("     |05__492| <update_qp> g%d, (v,h,s)=(%d,%d,%d), groupCount=%d \n", dsc_state->groupCount, vPos, hPos, sampModCnt, dsc_state->groupCount);

                // in cfg, RC_MAXQP = 19
                if ((sampModCnt==PIXELS_PER_GROUP-1) || (hPos==dsc_cfg->slice_width-1))
                {
  fppp(gold_qp, "g%d,s%d,qp=%d\n", dsc_state->groupCount, slicenum, qp);

                        // *MODEL NOTE* MN_FLAT_QP_ADJ
                        if (dsc_state->origIsFlat/*localking*/ && (dsc_state->masterQp < dsc_cfg->rc_range_parameters[NUM_BUF_RANGES/*15*/-1].range_max_qp))
                        {
                                if ((dsc_state->flatnessType==0) || (dsc_state->masterQp<SOMEWHAT_FLAT_QP_THRESH)) // Somewhat flat
                                {
                                        dsc_state->stQp = MAX(dsc_state->stQp - 4, 0);
                                        qp = MAX(new_quant-4, 0);
//ppp("     |05__493| <update_qp> g%d, B. qp=%x, stQp=%x \n", dsc_state->groupCount, qp, dsc_state->stQp);
                                } else {                // very flat
                                        dsc_state->stQp = 1+(2*(dsc_cfg->bits_per_component-8));
                                        qp = 1+(2*(dsc_cfg->bits_per_component-8));
//ppp("     |05__494| <update_qp> g%d, C. qp=%x, stQp=%x \n", dsc_state->groupCount, qp, dsc_state->stQp);
                                }
                        }
                        else
                        {
                                qp = new_quant;
//ppp("     |05__495| <update_qp> g%d, D. qp=%x, stQp=%x \n", dsc_state->groupCount, qp, dsc_state->stQp);
                        }

//ppp("     |05__496| <update_qp> g%d, <update_qp> (v,h,s)=(%d,%d,%d), stQp  =%x \n", dsc_state->groupCount, vPos, hPos, sampModCnt, dsc_state->stQp );
//ppp("     |05__497| <update_qp> g%d, <update_qp> (v,h,s)=(%d,%d,%d), qp    =%x \n", dsc_state->groupCount, vPos, hPos, sampModCnt, qp   );
                }
//ppp("      # -------- update_qp END ------------------------------------ \n");
//ppp("      # ----------------------------------------------------------- \n\n");


//ppp("      # ----------------------------------------------------------- \n");
//ppp("      # -------- ICH_ERROR BEGIN ---------------------------------- \n");
//                   if (!isEncoder)  // Update decoder QP
                        dsc_state->masterQp = qp;

//ppp("      # -------- ICH_ERROR END ------------------------------------ \n");
//ppp("      # ----------------------------------------------------------- \n\n");


//ppp("      # ----------------------------------------------------------- \n");
//ppp("      # -------- GRP_DONE BEGIN ------------------------------- \n");

                sampModCnt++;

                if ( (sampModCnt >= PIXELS_PER_GROUP ) || (hPos+1 == dsc_cfg->slice_width))
                {
                        // Pad partial group at the end of the line
                        if (sampModCnt < PIXELS_PER_GROUP)
                        {
                                for (i = sampModCnt; i<PIXELS_PER_GROUP; ++i)
                                {
                                        // Set ICH values to the rightmost value
                                        dsc_state->ichLookup[i] = dsc_state->ichLookup[sampModCnt-1];

                                        for (cpnt = 0; cpnt<NUM_COMPONENTS; cpnt++)
                                        {
                                                char c_cpnt;
                                                if(cpnt==0) c_cpnt='Y'; else if(cpnt==1) c_cpnt='U'; else c_cpnt='V';

                                                dsc_state->quantizedResidual[cpnt][i] = 0;    // it seems useless for dec
                                                dsc_state->quantizedResidualMid[cpnt][i] = 0; // useless for dec
//ppp("     |05__498| <G_DONE> g%d, (v,h)=(%d,%d), qR[%c][samp%d]=%d \n", dsc_state->groupCount, vPos, hPos, c_cpnt, i, dsc_state->quantizedResidual[cpnt][i]);
                                        }
                                        hPos++;
                                }
                        }

                        dsc_state->hPos = hPos;

//                           else  // isEncoder == 0
//                           {
                                // Calculate scale & offset for RC
                                CalcFullnessOffset(dsc_cfg, dsc_state, vPos, group_count, &scale, &bpg_offset, slicenum);
                                group_count++;
                                dsc_state->groupCount = group_count;
                                throttle_offset = dsc_state->rcXformOffset;
                                //printf("%d\n", throttle_offset);
                                // Do rate control
                                RateControl( dsc_cfg, dsc_state, throttle_offset, bpg_offset, group_count, scale, sampModCnt, slicenum);
                                for (cpnt=0; cpnt < NUM_COMPONENTS; ++cpnt)
                                        dsc_state->leftRecon[cpnt] = currLine[cpnt][MIN(dsc_cfg->slice_width-1, hPos)+PADDING_LEFT];

//ppp("     |05__499| <G_DONE> gC_inc1=%d, (v,h)=(%d,%d), currLine[Y][%d]=%d \n", dsc_state->groupCount, vPos, hPos, MIN(dsc_cfg->slice_width-1, hPos)+PADDING_LEFT, currLine[0][MIN(dsc_cfg->slice_width-1, hPos)+PADDING_LEFT]);
//ppp("     |05__500| <G_DONE> gC_inc1=%d, (v,h)=(%d,%d), currLine[U][%d]=%d \n", dsc_state->groupCount, vPos, hPos, MIN(dsc_cfg->slice_width-1, hPos)+PADDING_LEFT, currLine[1][MIN(dsc_cfg->slice_width-1, hPos)+PADDING_LEFT]);
//ppp("     |05__501| <G_DONE> gC_inc1=%d, (v,h)=(%d,%d), currLine[V][%d]=%d \n", dsc_state->groupCount, vPos, hPos, MIN(dsc_cfg->slice_width-1, hPos)+PADDING_LEFT, currLine[2][MIN(dsc_cfg->slice_width-1, hPos)+PADDING_LEFT]);

                                new_quant = dsc_state->stQp;
//ppp("     |05__502| <G_DONE> gC_inc1=%d, (v,h)=(%d,%d), new_quant=%x \n", dsc_state->groupCount, vPos, hPos, new_quant);

                                //printf("%d\n", dsc_state->groupCountLine);



//                                   if (dsc_state->bufferFullness < 0)
//                                   {
//                                           if (dsc_cfg->vbr_enable)
//                                           {
//                                                   dsc_state->bitsClamped += -dsc_state->bufferFullness;
//                                                   dsc_state->bufferFullness = 0;
//                                           }
//                                           else
//                                           {
//                                                   printf("The buffer model encountered an underflow.  This may have occurred due to\n");
//                                                   printf("an excessively high constant bit rate or due to an attempt to decode an\n");
//                                                   printf("invalid DSC stream.\n");
//                                                   exit(1);
//                                           }
//                                   }

                                if (hPos>=dsc_cfg->slice_width-1)
                                        dsc_state->groupCountLine = 0; // useless
                                if ((hPos<dsc_cfg->slice_width-1) || (vPos<dsc_cfg->slice_height-1))  // Don't decode if we're done
                                        VLDGroup( dsc_cfg, dsc_state, &cmpr_buf, &cnt_mw, slicenum, gold_ichSelected, gold_useMidpoint);
//                           }

                        sampModCnt = 0;
                }

//ppp("      # -------- GRP_DONE END --------------------------------- \n");
//ppp("      # ----------------------------------------------------------- \n\n");
                //printf("%d\n",dsc_cfg->vbr_enable);

#ifdef PRINTDEBUG
                fflush(g_fp_dbg);
#endif

//ppp("      # ----------------------------------------------------------- \n");
//ppp("      # -------- SLICE_END BEGIN --------------------------------- \n");
                hPos++;
//ppp("     |05__503| (v,h)=(%d,%d) \n", vPos, hPos);
                if ( hPos >= dsc_cfg->slice_width ) {
                        int mod_hPos;
                        int Y = 0, U = 1, V = 2;
                        // end of line
                        // Update block prediction based on real reconstructed values

                        for (mod_hPos=0; mod_hPos<dsc_cfg->slice_width; ++mod_hPos)
                        {
//ppp("     |05__504| (v,h, mod_h)=(%d,%d,%d) \n", vPos, hPos, mod_hPos);
//ppp("      # ----  BPS Y  --------------------------------------------------------\n");
                           BlockPredSearch_Y( dsc_cfg, dsc_state, currLine, mod_hPos/*mod_hPos*/, currLine[Y][mod_hPos+PADDING_LEFT] /*B_recon_x*/, currLine[Y][mod_hPos+PADDING_LEFT-1]/*B_recon_x_prev*/, slicenum);
//ppp("      # ----  BPS U  --------------------------------------------------------\n");
                           BlockPredSearch_U( dsc_cfg, dsc_state, currLine, mod_hPos/*mod_hPos*/, currLine[U][mod_hPos+PADDING_LEFT] /*B_recon_x*/, currLine[U][mod_hPos+PADDING_LEFT-1]/*B_recon_x_prev*/, slicenum);
//ppp("      # ----  BPS V  --------------------------------------------------------\n");
                           BlockPredSearch_V( dsc_cfg, dsc_state, currLine, mod_hPos/*mod_hPos*/, currLine[V][mod_hPos+PADDING_LEFT] /*B_recon_x*/, currLine[V][mod_hPos+PADDING_LEFT-1]/*B_recon_x_prev*/, slicenum);
//ppp("      # ---------------------------------------------------------------------\n");
                        }

//if(vPos==1)assert(0);
                        // reduce number of bits per sample in line buffer (replicate pixels in left/right padding)
                        for ( i=0; i<lbufWidth; i++ )
                        {
                            prevLine[Y][i] = SampToLineBuf( dsc_cfg, dsc_state, currLine[Y][CLAMP(i,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)]/*x*/, Y/*cpnt*/, slicenum); // if linebuf_depth >=11, prevLine = currLine
                            prevLine[U][i] = SampToLineBuf( dsc_cfg, dsc_state, currLine[U][CLAMP(i,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)]/*x*/, U/*cpnt*/, slicenum); // if linebuf_depth >=11, prevLine = currLine
                            prevLine[V][i] = SampToLineBuf( dsc_cfg, dsc_state, currLine[V][CLAMP(i,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)]/*x*/, V/*cpnt*/, slicenum); // if linebuf_depth >=11, prevLine = currLine
                        }
//ppp("     |05__505| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 0   , currLine[Y][CLAMP(0 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__506| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 1   , currLine[Y][CLAMP(1 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__507| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2   , currLine[Y][CLAMP(2 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__508| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 3   , currLine[Y][CLAMP(3 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__509| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 4   , currLine[Y][CLAMP(4 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__510| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 5   , currLine[Y][CLAMP(5 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__511| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 6   , currLine[Y][CLAMP(6 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__512| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 7   , currLine[Y][CLAMP(7 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__513| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 8   , currLine[Y][CLAMP(8 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__514| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 9   , currLine[Y][CLAMP(9 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__515| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 10  , currLine[Y][CLAMP(10,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__516| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2558, currLine[Y][CLAMP(2558,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__517| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2559, currLine[Y][CLAMP(2559,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__518| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2560, currLine[Y][CLAMP(2560,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__519| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2561, currLine[Y][CLAMP(2561,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__520| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2562, currLine[Y][CLAMP(2562,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__521| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2563, currLine[Y][CLAMP(2563,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__522| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2564, currLine[Y][CLAMP(2564,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__523| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2565, currLine[Y][CLAMP(2565,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__524| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2566, currLine[Y][CLAMP(2566,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__525| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2567, currLine[Y][CLAMP(2567,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__526| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2568, currLine[Y][CLAMP(2568,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__527| (v,h)=(%d,%d), currLine[Y][%d]=%d \n", vPos, hPos, 2569, currLine[Y][CLAMP(2569,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);

//ppp("     |05__528| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 0   , prevLine[Y][CLAMP(0 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__529| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 1   , prevLine[Y][CLAMP(1 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__530| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2   , prevLine[Y][CLAMP(2 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__531| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 3   , prevLine[Y][CLAMP(3 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__532| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 4   , prevLine[Y][CLAMP(4 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__533| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 5   , prevLine[Y][CLAMP(5 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__534| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 6   , prevLine[Y][CLAMP(6 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__535| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 7   , prevLine[Y][CLAMP(7 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__536| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 8   , prevLine[Y][CLAMP(8 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__537| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 9   , prevLine[Y][CLAMP(9 ,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__538| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 10  , prevLine[Y][CLAMP(10,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1)   ]);
//ppp("     |05__539| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2558, prevLine[Y][CLAMP(2558,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__540| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2559, prevLine[Y][CLAMP(2559,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__541| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2560, prevLine[Y][CLAMP(2560,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__542| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2561, prevLine[Y][CLAMP(2561,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__543| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2562, prevLine[Y][CLAMP(2562,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__544| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2563, prevLine[Y][CLAMP(2563,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__545| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2564, prevLine[Y][CLAMP(2564,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__546| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2565, prevLine[Y][CLAMP(2565,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__547| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2566, prevLine[Y][CLAMP(2566,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__548| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2567, prevLine[Y][CLAMP(2567,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__549| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2568, prevLine[Y][CLAMP(2568,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);
//ppp("     |05__550| (v,h)=(%d,%d), prevLine[Y][%d]=%d \n", vPos, hPos, 2569, prevLine[Y][CLAMP(2569,PADDING_LEFT,PADDING_LEFT+dsc_cfg->slice_width-1) ]);


                        hPos = 0;
                        vPos++;


//                           if (dsc_state->isEncoder)
//                                   dsc_state->groupCountLine = 0;

                        if ( vPos >= dsc_cfg->slice_height )
                                done = 1;
//                           else if (isEncoder)
//                                   PopulateOrigLine(dsc_cfg, dsc_state, pic, vPos);

                }
//ppp("      # -------- SLICE_END END ----------------------------------- \n");
//ppp("      # ----------------------------------------------------------- \n");

//ppp(" \n");
//ppp("      # -------- WHILE_%d END ------------------------------------- \n", while_cnt);
//ppp("      # ----------------------------------------------------------- \n\n\n\n\n\n\n");
           while_cnt++;
        }

        if ( dsc_cfg->convert_rgb ) {
                // Convert YCoCg back to RGB again
                ycocg2rgb(op, orig_op, dsc_cfg, slicenum, gold_rgb);
        }
        //printf("%d\n", ip->bits);
        //printf("%d\n", dsc_cfg->ystart);
        for ( cpnt = 0; cpnt<NUM_COMPONENTS; cpnt++ )
        {
                free(currLine[cpnt]);
                free(prevLine[cpnt]);
                free(dsc_state->origLine[cpnt]);
                fifo_free(&(dsc_state->shifter[cpnt]));
                fifo_free(&(dsc_state->encBalanceFifo[cpnt]));
                fifo_free(&(dsc_state->seSizeFifo[cpnt]));
                free(dsc_state->history.pixels[cpnt]);
        }

        free(dsc_state->prevLinePred);
        free(dsc_state->history.valid);

//           if (isEncoder && (dsc_state->bufferFullness > ((dsc_cfg->initial_xmit_delay * dsc_cfg->bits_per_pixel) >> 4)))
//           {
//                   printf("Too many bits are left in the rate buffer at the end of the slice.  This is most likely\n");
//                   printf("due to an invalid RC configuration.\n");
//                   exit(1);
//           }
#ifdef PRINTDEBUG
        fclose(g_fp_dbg);
#endif

        return dsc_state->postMuxNumBits;

}


// ======================================================================================== begin
//! Wrapper function for encode
/*! \param dsc_cfg   DSC configuration structure
    \param p_in      Input picture
        \param p_out     Output picture
        \param cmpr_buf  Pointer to empty buffer to hold compressed bitstream
        \param temp_pic  Array of two pictures to use as temporary storage for YCoCg conversions
        \return          Number of bits in the resulting compressed bitstream */
int DSC_Encode(dsc_cfg_t *dsc_cfg, pic_t *p_in, pic_t *p_out, unsigned char *cmpr_buf, pic_t **temp_pic, int *chunk_sizes, int slicecount, FILE *gold_ICH           ,
                                                                                                                                           FILE *gold_ichSelected   ,
                                                                                                                                           FILE *gold_useMidpoint   ,
                                                                                                                                           FILE *gold_pred_x_SP     ,
                                                                                                                                           FILE *gold_err_q         ,
                                                                                                                                           FILE *gold_pred_x        ,
                                                                                                                                           FILE *gold_recon_x_clamp ,
                                                                                                                                           FILE *gold_recon_x_final ,
                                                                                                                                           FILE *gold_qp            ,
                                                                                                                                           FILE *gold_rgb           )
{
  int slicenum=slicecount-1;

  printf("     |05__551| # int DSC_Encode \n");

        return DSC_Algorithm(1, dsc_cfg, p_in, p_out, cmpr_buf, temp_pic, chunk_sizes, slicenum, gold_ICH           ,
                                                                                                 gold_ichSelected   ,
                                                                                                 gold_useMidpoint   ,
                                                                                                 gold_pred_x_SP     ,
                                                                                                 gold_err_q         ,
                                                                                                 gold_pred_x        ,
                                                                                                 gold_recon_x_clamp ,
                                                                                                 gold_recon_x_final ,
                                                                                                 gold_qp            ,
                                                                                                 gold_rgb           );
}


// ======================================================================================== begin
//! Wrapper function for decode
/*! \param dsc_cfg   DSC configuration structure
        \param p_out     Output picture
        \param cmpr_buf  Pointer to buffer containing compressed bitstream
        \param temp_pic  Array of two pictures to use as temporary storage for YCoCg conversions */
void DSC_Decode(dsc_cfg_t *dsc_cfg, pic_t *p_out, unsigned char *cmpr_buf, pic_t **temp_pic, int slicecount, FILE *gold_ICH           ,
                                                                                                             FILE *gold_ichSelected   ,
                                                                                                             FILE *gold_useMidpoint   ,
                                                                                                             FILE *gold_pred_x_SP     ,
                                                                                                             FILE *gold_err_q         ,
                                                                                                             FILE *gold_pred_x        ,
                                                                                                             FILE *gold_recon_x_clamp ,
                                                                                                             FILE *gold_recon_x_final ,
                                                                                                             FILE *gold_qp            ,
                                                                                                             FILE *gold_rgb           )
{
        int slicenum=slicecount-1;

  printf("     |05__552| # int DSC_Decode \n");

        DSC_Algorithm(0, dsc_cfg, p_out, p_out, cmpr_buf, temp_pic, NULL, slicenum, gold_ICH           ,
                                                                                    gold_ichSelected   ,
                                                                                    gold_useMidpoint   ,
                                                                                    gold_pred_x_SP     ,
                                                                                    gold_err_q         ,
                                                                                    gold_pred_x        ,
                                                                                    gold_recon_x_clamp ,
                                                                                    gold_recon_x_final ,
                                                                                    gold_qp            ,
                                                                                    gold_rgb           );
}
