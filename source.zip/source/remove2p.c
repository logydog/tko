// ======================================================================================== begin
//! Function to remove one pixel's worth of bits from the encoder buffer model
/*! \param dsc_cfg   DSC configuration structure
    \param dsc_state DSC state structure */
void RemoveBitsEncoderBuffer(dsc_cfg_t *dsc_cfg, dsc_state_t *dsc_state)
{


        //========================================================================================
        dsc_state->bpgFracAccum   += (dsc_cfg->bits_per_pixel & 0xf);
        dsc_state->bufferFullness -= (dsc_cfg->bits_per_pixel >> 4) + (dsc_state->bpgFracAccum>>4);
        dsc_state->numBitsChunk   += (dsc_cfg->bits_per_pixel >> 4) + (dsc_state->bpgFracAccum>>4);
        dsc_state->bpgFracAccum   &= 0xf;
        dsc_state->chunkPixelTimes++;

        if (dsc_state->chunkPixelTimes >= dsc_cfg->slice_width)
        {
                int adjustment_bits;
                if (dsc_cfg->vbr_enable)
                {
                        int R_size;
                        R_size                      = (dsc_state->numBitsChunk - dsc_state->bitsClamped + 7) / 8;
                        adjustment_bits             = R_size * 8 - (dsc_state->numBitsChunk - dsc_state->bitsClamped);
                        dsc_state->bufferFullness  -= adjustment_bits;
                        dsc_state->bitsClamped      = 0;
                        if (dsc_state->isEncoder)
                                dsc_state->chunkSizes[dsc_state->chunkCount] = R_size;
                }
                else   // CBR mode
                {
                        adjustment_bits             = dsc_cfg->chunk_size * 8 - dsc_state->numBitsChunk;
                        dsc_state->bufferFullness  -= adjustment_bits;
                }

                dsc_state->bpgFracAccum = 0;
                dsc_state->numBitsChunk = 0;
                dsc_state->chunkCount++;
                dsc_state->chunkPixelTimes = 0;
        }



        //========================================================================================
        dsc_state->bpgFracAccum   += (dsc_cfg->bits_per_pixel & 0xf);
        dsc_state->bufferFullness -= (dsc_cfg->bits_per_pixel >> 4) + (dsc_state->bpgFracAccum>>4);
        dsc_state->numBitsChunk   += (dsc_cfg->bits_per_pixel >> 4) + (dsc_state->bpgFracAccum>>4);
        dsc_state->bpgFracAccum   &= 0xf;
        dsc_state->chunkPixelTimes++;

        if (dsc_state->chunkPixelTimes >= dsc_cfg->slice_width)
        {
                int adjustment_bits;
                if (dsc_cfg->vbr_enable)
                {
                        int R_size;
                        R_size                      = (dsc_state->numBitsChunk - dsc_state->bitsClamped + 7) / 8;
                        adjustment_bits             = R_size * 8 - (dsc_state->numBitsChunk - dsc_state->bitsClamped);
                        dsc_state->bufferFullness  -= adjustment_bits;
                        dsc_state->bitsClamped      = 0;
                        if (dsc_state->isEncoder)
                                dsc_state->chunkSizes[dsc_state->chunkCount] = R_size;
                }
                else   // CBR mode
                {
                        adjustment_bits             = dsc_cfg->chunk_size * 8 - dsc_state->numBitsChunk;
                        dsc_state->bufferFullness  -= adjustment_bits;
                }

                dsc_state->bpgFracAccum = 0;
                dsc_state->numBitsChunk = 0;
                dsc_state->chunkCount++;
                dsc_state->chunkPixelTimes = 0;
        }





}
