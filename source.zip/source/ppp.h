//#define ppp if(slicenum==1&&dsc_state->vPos==0)printf
//#define ppp if(slicenum==1&&dsc_state->groupCount>=1100&&dsc_state->groupCount<=1120)printf
//#define ppp if(slicenum==1&&dsc_state->groupCount>=0&&dsc_state->groupCount<=173)printf
//#define ppp if(slicenum==0&&dsc_state->groupCount>=39&&dsc_state->groupCount<=39)printf
//#define ppp if(slicenum==24)printf
  #define ppp                                    printf
//===================================================================================================
//#define fppp if(slicenum==1&&dsc_state->vPos==0)fprintf
//#define fppp if(slicenum==1&&dsc_state->groupCount>=1100&&dsc_state->groupCount<=1120)fprintf
//#define fppp if(slicenum==1&&dsc_state->groupCount>=0&&dsc_state->groupCount<=173)fprintf
//#define fppp if(slicenum==0&&dsc_state->groupCount>=39&&dsc_state->groupCount<=39)fprintf
//#define fppp if(slicenum==24)fprintf
  #define fppp                                    fprintf
