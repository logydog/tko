#include "main.h"

static void ReadSource_y_u_v(int nframe, FrameInfo *AFrame)
{
	FILE *fd;
	char name[256], name_t[256];
	int i;
	unsigned char *pbTemp;

	pbTemp = (unsigned char*)malloc(SrcInfo.Size_Y*sizeof(unsigned char));

	sprintf(name_t, SrcInfo.FileName, nframe);
	sprintf(name, "%s.Y", name_t);
	if (!(fd = fopen(name, "rb")))
	{
        	sprintf(errortext, "Couldn't open %s\n", name);
        	error(errortext);
	}

	fseek(fd, 0, SEEK_END);
	if (ftell(fd) != SrcInfo.Size_Y) {
		printf("Warning............image size don't match the input size !!!\n");
	}
	rewind(fd);

	fread(pbTemp, sizeof(unsigned char), SrcInfo.Size_Y, fd);
	for(i=0;i<SrcInfo.Size_Y;i++)
	{
		*(AFrame->y_data+i) = (int)((*(pbTemp+i))<<PIXEL_BITS);
	}

	fclose(fd);

	sprintf(name,"%s.U",name_t);
	if (!(fd = fopen(name,"rb")))
	{
       	sprintf(errortext,"Couldn't open %s\n",name);
       	error(errortext);
	}

	fread(pbTemp, sizeof(unsigned char), SrcInfo.Size_UV, fd);
	for(i=0;i<SrcInfo.Size_UV;i++)
	{
		*(AFrame->u_data+i) = (int)((*(pbTemp+i))<<PIXEL_BITS);
	}

	fclose(fd);

	sprintf(name,"%s.V",name_t);
	if (!(fd = fopen(name,"rb")))
	{
       	sprintf(errortext,"Couldn't open %s\n", name);
       	error(errortext);
	}

	fread(pbTemp, sizeof(unsigned char), SrcInfo.Size_UV, fd);
	for(i=0;i<SrcInfo.Size_UV;i++)
	{
		*(AFrame->v_data+i) = (int)((*(pbTemp+i))<<PIXEL_BITS);
	}

	printf( "read frame count = %d\n", nframe);
	AFrame->frame_w = SrcInfo.frame_w;
	AFrame->frame_h = SrcInfo.frame_h;
	AFrame->DisplayMode = SrcInfo.DisplayMode;


	free(pbTemp);
	fclose(fd);
}


static void ReadSource_yuv(int nframe, FrameInfo *AFrame)
{
	FILE *fd;
	char name[256], name_t[256];
	int i;
	unsigned char *pbTemp;

	pbTemp = (unsigned char*)malloc(SrcInfo.Size_Y*sizeof(unsigned char));

	sprintf(name_t, SrcInfo.FileName);
	sprintf(name, "%s.YUV", name_t);
	if (!(fd = fopen(name, "rb")))
	{
       	sprintf(errortext,"Couldn't open %s\n",name);
       	error(errortext);
	}
	fseek(fd, (nframe) * (SrcInfo.Size_Y+SrcInfo.Size_UV * 2),0);


	fread(pbTemp, sizeof(unsigned char), SrcInfo.Size_Y, fd);
	for(i=0;i<SrcInfo.Size_Y;i++)
	{
		*(AFrame->y_data+i) = (int)((*(pbTemp+i))<<PIXEL_BITS);
	}

	fread(pbTemp, sizeof(unsigned char), SrcInfo.Size_UV, fd);
	for(i=0;i<SrcInfo.Size_UV;i++)
	{
		*(AFrame->u_data+i) = (int)((*(pbTemp+i))<<PIXEL_BITS);
	}

	fread(pbTemp, sizeof(unsigned char), SrcInfo.Size_UV, fd);
	for(i=0;i<SrcInfo.Size_UV;i++)
	{
		*(AFrame->v_data+i) = (int)((*(pbTemp+i))<<PIXEL_BITS);
	}

	printf( "read frame count = %d\n", nframe);
	AFrame->frame_w = SrcInfo.frame_w;
	AFrame->frame_h = SrcInfo.frame_h;
	AFrame->DisplayMode = SrcInfo.DisplayMode;


	free(pbTemp);
	fclose(fd);
}

static void Read_bmp(int nframe,FrameInfo *AFrame)
{
    FILE *stream;
	char name[256], name_t[256];
    BmpInfo YUVbmp;
	int namesize;
	unsigned char *pbTemp;
	int i, iBmpDataSize;

    int width,height,size;
    int linesize,linecount,lineleft;
    int R,G,B;


	namesize = strlen(SrcInfo.FileName);
	if((SrcInfo.FileName[namesize-2]=='%') || (SrcInfo.FileName[namesize-4]=='%'))
		sprintf(name_t, SrcInfo.FileName, nframe);
	else
		sprintf(name_t, SrcInfo.FileName);

	sprintf(name, "%s.bmp", name_t);
	if (!(stream = fopen(name, "rb")))
	{
        sprintf(errortext,"Couldn't open %s\n",name);
        error(errortext);
	}

    fread( &YUVbmp.FileHeader.bfType,2,1,stream );
    fread( &YUVbmp.FileHeader.bfSize,4,1,stream );
    fread( &YUVbmp.FileHeader.bfReserved,4,1,stream );
    fread( &YUVbmp.FileHeader.bfOffBits,4,1,stream );

    fread( &YUVbmp.InfoHeader,sizeof(tagBmpInfoHeader),1,stream );

	iBmpDataSize = YUVbmp.FileHeader.bfSize-YUVbmp.FileHeader.bfOffBits;
	YUVbmp.data = (int*)malloc(iBmpDataSize * sizeof(int));
	pbTemp = (unsigned char*)malloc( iBmpDataSize * sizeof(unsigned char));
	fread(pbTemp,iBmpDataSize,1,stream );
	for(i=0;i<iBmpDataSize;i++)
	{
	    *(YUVbmp.data+i) = (int)((*(pbTemp+i))<<PIXEL_BITS);
	}
	AFrame->frame_w = YUVbmp.InfoHeader.biWidth;
	AFrame->frame_h = YUVbmp.InfoHeader.biHeight;
	AFrame->DisplayMode = CHROMA444;

    width=YUVbmp.InfoHeader.biWidth;
    height=YUVbmp.InfoHeader.biHeight;
    linesize=((YUVbmp.InfoHeader.biWidth*3)+3)>>2<<2;
    size=width*height;
    for (i=0;i<size ;i++)
    {
        linecount=i/width;
        lineleft=i%width;

        R=*(YUVbmp.data+(height-1-linecount)*linesize+3*lineleft+2);
        G=*(YUVbmp.data+(height-1-linecount)*linesize+3*lineleft+1);
        B=*(YUVbmp.data+(height-1-linecount)*linesize+3*lineleft);

	    *(AFrame->y_data+i) = R;
	    *(AFrame->u_data+i) = G;
	    *(AFrame->v_data+i) = B;
	}

    free(YUVbmp.data);
    free(pbTemp);
    fclose(stream);
}

void ReadBmpDimension(int nframe,FrameInfo *AFrame, int *frame_w, int *frame_h)
{
    FILE *stream;
	char name[256], name_t[256];
    BmpInfo YUVbmp;
	int namesize;
	namesize = strlen(SrcInfo.FileName);
	if((SrcInfo.FileName[namesize-2]=='%') || (SrcInfo.FileName[namesize-4]=='%'))
		sprintf(name_t, SrcInfo.FileName, nframe);
	else
		sprintf(name_t, SrcInfo.FileName);

	sprintf(name, "%s.bmp", name_t);
	if (!(stream = fopen(name, "rb")))
	{
        sprintf(errortext,"Couldn't open %s\n",name);
        error(errortext);
	}

    fread( &YUVbmp.FileHeader.bfType,2,1,stream );
    fread( &YUVbmp.FileHeader.bfSize,4,1,stream );
    fread( &YUVbmp.FileHeader.bfReserved,4,1,stream );
    fread( &YUVbmp.FileHeader.bfOffBits,4,1,stream );

    fread( &YUVbmp.InfoHeader,sizeof(tagBmpInfoHeader),1,stream );

	*frame_w = YUVbmp.InfoHeader.biWidth;
	*frame_h = YUVbmp.InfoHeader.biHeight;

    fclose(stream);
}

void ReadSourceFrame(int nframe, FrameInfo *AFrame)
{
	switch (SrcInfo.InType)
	{
        case T_Y_U_V:
            ReadSource_y_u_v(nframe, AFrame);
            break;
        case T_YUV:
            ReadSource_yuv(nframe, AFrame);
            break;
        case T_BMP:
            Read_bmp(nframe, AFrame);
            break;
	}
}




