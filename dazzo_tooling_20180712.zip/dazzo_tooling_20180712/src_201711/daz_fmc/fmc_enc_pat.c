/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

static uint8 pdec_pat5_R[BLK_SIZE];
static uint8 pdec_pat5_G[BLK_SIZE];
static uint8 pdec_pat5_B[BLK_SIZE];

static uint8 pdec_pat4_R[BLK_SIZE];
static uint8 pdec_pat4_G[BLK_SIZE];
static uint8 pdec_pat4_B[BLK_SIZE];

static uint8 pdec_pat3_R[BLK_SIZE];
static uint8 pdec_pat3_G[BLK_SIZE];
static uint8 pdec_pat3_B[BLK_SIZE];

static uint8 pdec_pat2_R[BLK_SIZE];
static uint8 pdec_pat2_G[BLK_SIZE];
static uint8 pdec_pat2_B[BLK_SIZE];

static uint8 pdec_pat1_R[BLK_SIZE];
static uint8 pdec_pat1_G[BLK_SIZE];
static uint8 pdec_pat1_B[BLK_SIZE];

static uint8 pdec_pat0_R[BLK_SIZE];
static uint8 pdec_pat0_G[BLK_SIZE];
static uint8 pdec_pat0_B[BLK_SIZE];

void fmc_dec_pat0_2kc_2v(uint8 enc_v0, uint8 enc_v1, uint8 enc_kc0, uint8 enc_kc1, uint8 *enc_px_sel, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b)
{
    int i;

    uint8 r_kc0 = ((enc_kc0>>1) & 1) ? enc_v1 : enc_v0;
    uint8 g_kc0 = (enc_kc0 & 1) ? enc_v1 : enc_v0;
    uint8 b_kc0 = enc_v0;

    uint8 r_kc1 = ((enc_kc1>>2) & 1) ? enc_v1 : enc_v0;
    uint8 g_kc1 = ((enc_kc1>>1) & 1) ? enc_v1 : enc_v0;
    uint8 b_kc1 = (enc_kc1 & 1) ? enc_v1 : enc_v0;

    for(i=0; i<3; i++)
    {
        dec_r[i] = enc_px_sel[i] ? r_kc1 : r_kc0;
        dec_g[i] = enc_px_sel[i] ? g_kc1 : g_kc0;
        dec_b[i] = enc_px_sel[i] ? b_kc1 : b_kc0;
    }
    dec_r[3] = r_kc0;
    dec_g[3] = g_kc0;
    dec_b[3] = b_kc0;
}

void fmc_enc_pat0_2kc_2v(int *diff_sum)
{
    int i;
    uint8 bplane[11];
    enc_pat0_v0 = Bin2x2[3];
    enc_pat0_v1 = (Bin2x2[3] == RGB_min) ? RGB_max : RGB_min;

    for(i=0; i<4; i++)
    {
        bplane[i] = (Rin2x2[i] == enc_pat0_v1);
        bplane[i+4] = (Gin2x2[i] == enc_pat0_v1);
        if(i<3)
            bplane[i+8] = (Bin2x2[i] == enc_pat0_v1);
    }
    uint8 bp_p0 = (bplane[0]<<2) | (bplane[4]<<1) | (bplane[8]);
    uint8 bp_p1 = (bplane[1]<<2) | (bplane[5]<<1) | (bplane[9]);
    uint8 bp_p2 = (bplane[2]<<2) | (bplane[6]<<1) | (bplane[10]);
    uint8 bp_p3 = (bplane[3]<<2) | (bplane[7]<<1);

    enc_pat0_kc0 = (bp_p3>>1);

    if(bp_p0 != bp_p3)
        enc_pat0_kc1 = bp_p0;
    else if(bp_p1 != bp_p3)
        enc_pat0_kc1 = bp_p1;
    else if(bp_p2 != bp_p3)
        enc_pat0_kc1 = bp_p2;
    else
        enc_pat0_kc1 = bp_p3;

    enc_pat0_px_sel[0] = (bp_p0 == enc_pat0_kc1);
    enc_pat0_px_sel[1] = (bp_p1 == enc_pat0_kc1);
    enc_pat0_px_sel[2] = (bp_p2 == enc_pat0_kc1);

    fmc_dec_pat0_2kc_2v(enc_pat0_v0, enc_pat0_v1, enc_pat0_kc0, enc_pat0_kc1, enc_pat0_px_sel, pdec_pat0_R, pdec_pat0_G, pdec_pat0_B);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_pat0_R, pdec_pat0_G, pdec_pat0_B, diff_sum);
}


void fmc_dec_pat1_core(uint8 enc_1v, uint8 *enc_4v, uint8 enc_4v_min, uint8 enc_4v_quant,
    uint8 enc_c_sel, uint8 *dec_1v, uint8 *dec_4v, uint8 *dec_c, uint8 *rnb)
{
    int i;
    if(enc_4v_quant)
    {
        for(i=0; i<4; i++)
            dec_4v[i] = round_dq(enc_4v[i], rnb[i]);
    }
    else
    {
        for(i=0; i<4; i++)
            dec_4v[i] = enc_4v_min + enc_4v[i];
    }
    for(i=0; i<4; i++)
    {
        dec_1v[i] = enc_1v;
        dec_c[i] = enc_c_sel ? dec_4v[i] : dec_1v[i];
    }
}

void fmc_dec_pat1_ch_ab_c(uint8 enc_ab_sel, uint8 enc_c_sel, uint8 enc_1v, uint8 enc_4v_quant, uint8 enc_4v_min, uint8 *enc_4v,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    uint8 dec_1v[4];
    uint8 dec_4v[4];
    uint8 dec_c[4];

    fmc_dec_pat1_core(enc_1v, enc_4v, enc_4v_min, enc_4v_quant, enc_c_sel, dec_1v, dec_4v, dec_c, rnb);

    switch(enc_ab_sel)
    {
        case 0:
            copy_block(BLK_SIZE, dec_r, dec_1v);
            copy_block(BLK_SIZE, dec_g, dec_4v);
            copy_block(BLK_SIZE, dec_b, dec_c);
            break;
        case 1:
            copy_block(BLK_SIZE, dec_r, dec_1v);
            copy_block(BLK_SIZE, dec_b, dec_4v);
            copy_block(BLK_SIZE, dec_g, dec_c);
            break;
        case 2:
            copy_block(BLK_SIZE, dec_g, dec_1v);
            copy_block(BLK_SIZE, dec_r, dec_4v);
            copy_block(BLK_SIZE, dec_b, dec_c);
            break;
        case 3:
            copy_block(BLK_SIZE, dec_g, dec_1v);
            copy_block(BLK_SIZE, dec_b, dec_4v);
            copy_block(BLK_SIZE, dec_r, dec_c);
            break;
        case 4:
            copy_block(BLK_SIZE, dec_b, dec_1v);
            copy_block(BLK_SIZE, dec_r, dec_4v);
            copy_block(BLK_SIZE, dec_g, dec_c);
            break;
        default:
            copy_block(BLK_SIZE, dec_b, dec_1v);
            copy_block(BLK_SIZE, dec_g, dec_4v);
            copy_block(BLK_SIZE, dec_r, dec_c);
            break;
    }

}

uint8 fmc_enc_pat1_core(uint8 ch4v_min, uint8 ch4v_range, uint8 *ch4v_in, uint8* enc_4v, uint8 *rnb)
{
    int i;

    uint8 quant = (ch4v_range > 10);
    if(quant)
    {
        for(i=0; i<4; i++)
            enc_4v[i] = round_q(ch4v_in[i], rnb[i]);
    }
    else
    {
        for(i=0; i<4; i++)
        {
            enc_4v[i] = ch4v_in[i] - ch4v_min;
            if(enc_4v[i] > 3)
                enc_4v[i] = 3;
        }
    }
    return quant;
}

void fmc_enc_pat1_ch_ab_c(int *diff_sum)
{
    int i;
    uint8 rnb[4] = {4,4,4,4};

    uint8 ch_1v = CH_most_smooth;
    uint8 ch_4v = CH_most_sharp;

    uint8 rg_diff = get_abs_diff(R_mean, G_mean);
    uint8 rb_diff = get_abs_diff(R_mean, B_mean);
    uint8 gb_diff = get_abs_diff(G_mean, B_mean);

    uint8 r_close_to_g = (rg_diff < rb_diff);
    uint8 r_close_to_b = !r_close_to_g;

    uint8 g_close_to_r = (rg_diff < gb_diff);
    uint8 g_close_to_b = !g_close_to_r;

    uint8 b_close_to_r = (rb_diff < gb_diff);
    uint8 b_close_to_g = !b_close_to_r;

    enc_pat1_ab_sel = (ch_1v == 0 && ch_4v == 1) ? 0 :
                      (ch_1v == 0 && ch_4v == 2) ? 1 :
                      (ch_1v == 1 && ch_4v == 0) ? 2 :
                      (ch_1v == 1 && ch_4v == 2) ? 3 :
                      (ch_1v == 2 && ch_4v == 0) ? 4 : 5;

    enc_pat1_c_sel = (enc_pat1_ab_sel == 0) ? b_close_to_g :
                     (enc_pat1_ab_sel == 1) ? g_close_to_b :
                     (enc_pat1_ab_sel == 2) ? b_close_to_r :
                     (enc_pat1_ab_sel == 3) ? r_close_to_b :
                     (enc_pat1_ab_sel == 4) ? g_close_to_r : r_close_to_g;

    switch(enc_pat1_ab_sel)
    {
        case 0:
            enc_pat1_1v = R_mean;
            enc_pat1_4v_min = G_min;
            enc_pat1_quant = fmc_enc_pat1_core(G_min, G_range, Gin2x2, enc_pat1_4v, rnb);
            break;
        case 1:
            enc_pat1_1v = R_mean;
            enc_pat1_4v_min = B_min;
            enc_pat1_quant = fmc_enc_pat1_core(B_min, B_range, Bin2x2, enc_pat1_4v, rnb);

            if(!enc_pat1_c_sel && pzc_bc)
            {
                enc_pat1_1v = 0;
                enc_pat1_4v_min = 0;
                enc_pat1_quant = 0;
                for(i=0; i<4; i++)
                    enc_pat1_4v[i] = 0;
            }
            break;
        case 2:
            enc_pat1_1v = G_mean;
            enc_pat1_4v_min = R_min;
            enc_pat1_quant = fmc_enc_pat1_core(R_min, R_range, Rin2x2, enc_pat1_4v, rnb);
            break;
        case 3:
            enc_pat1_1v = G_mean;
            enc_pat1_4v_min = B_min;
            enc_pat1_quant = fmc_enc_pat1_core(B_min, B_range, Bin2x2, enc_pat1_4v, rnb);
            break;
        case 4:
            enc_pat1_1v = B_mean;
            enc_pat1_4v_min = R_min;
            enc_pat1_quant = fmc_enc_pat1_core(R_min, R_range, Rin2x2, enc_pat1_4v, rnb);

            if(!enc_pat1_c_sel && pzc_rc)
            {
                enc_pat1_1v = 0;
                enc_pat1_4v_min = 0;
                enc_pat1_quant = 0;
                for(i=0; i<4; i++)
                    enc_pat1_4v[i] = 0;
            }
            break;
        default:
            enc_pat1_1v = B_mean;
            enc_pat1_4v_min = G_min;
            enc_pat1_quant = fmc_enc_pat1_core(G_min, G_range, Gin2x2, enc_pat1_4v, rnb);
            break;
    }


    fmc_dec_pat1_ch_ab_c(enc_pat1_ab_sel, enc_pat1_c_sel, enc_pat1_1v, enc_pat1_quant, enc_pat1_4v_min, enc_pat1_4v,
        pdec_pat1_R, pdec_pat1_G, pdec_pat1_B, rnb);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_pat1_R, pdec_pat1_G, pdec_pat1_B, diff_sum);

    copy_block(4, rnb_pat1, rnb);
}

void fmc_dec_pat2_2kc_gray_color(uint8 enc_idx, uint8 enc_px3_gray, uint8 enc_gray, uint8 *enc_color,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;
    uint8 bp[4];

    for(i=0;i<3;i++)
        bp[i] = ((enc_idx >> i) & 1);
    bp[3] = 0;

    uint8 v_gray = round_dq(enc_gray, rnb[0]);
    uint8 v_color[3];

    for(i=0; i<3; i++)
        v_color[i] = round_dq(enc_color[i], rnb[i+1]);

    if(enc_px3_gray)
    {
        for(i=0; i<4; i++)
        {
            dec_r[i] = bp[i] ? v_color[0] : v_gray;
            dec_g[i] = bp[i] ? v_color[1] : v_gray;
            dec_b[i] = bp[i] ? v_color[2] : v_gray;
        }
    }
    else
    {
        for(i=0; i<4; i++)
        {
            dec_r[i] = bp[i] ? v_gray : v_color[0];
            dec_g[i] = bp[i] ? v_gray : v_color[1];
            dec_b[i] = bp[i] ? v_gray : v_color[2];
        }
    }

}

void fmc_enc_pat2_2kc_gray_color(int *diff_sum)
{
    uint8 rgb_px3[3] = {full_rgb2_R[0], full_rgb2_G[0], full_rgb2_B[0]};
    uint8 rgb_px3_max = get_max(3, rgb_px3);
    uint8 rgb_px3_min = get_min(3, rgb_px3);
    uint8 rgb_px3_range = rgb_px3_max - rgb_px3_min;

    uint8 full_gray;
    uint8 rnb[4] ={1, 3,3,3};

    enc_pat2_px3_gray = (rgb_px3_range<16);
    if(enc_pat2_px3_gray)
    {
        full_gray = get_mean3(full_rgb2_R[0], full_rgb2_G[0], full_rgb2_B[0]);
        enc_pat2_gray = round_q(full_gray, rnb[0]);
        enc_pat2_color[0] = round_q(full_rgb2_R[1], rnb[1]);
        enc_pat2_color[1] = round_q(full_rgb2_G[1], rnb[2]);
        enc_pat2_color[2] = round_q(full_rgb2_B[1], rnb[3]);
    }
    else
    {
        full_gray = get_mean3(full_rgb2_R[1], full_rgb2_G[1], full_rgb2_B[1]);
        enc_pat2_gray = round_q(full_gray, rnb[0]);
        enc_pat2_color[0] = round_q(full_rgb2_R[0], rnb[1]);
        enc_pat2_color[1] = round_q(full_rgb2_G[0], rnb[2]);
        enc_pat2_color[2] = round_q(full_rgb2_B[0], rnb[3]);
    }

    fmc_dec_pat2_2kc_gray_color(enc_Ybp2_idx, enc_pat2_px3_gray, enc_pat2_gray, enc_pat2_color,
        pdec_pat2_R, pdec_pat2_G, pdec_pat2_B, rnb);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_pat2_R, pdec_pat2_G, pdec_pat2_B, diff_sum);

    copy_block(4, rnb_pat2, rnb);
}

void fmc_dec_pat3_pzc1(uint8 enc_ch4v_sel, uint8 enc_1v, uint8 enc_4v_quant, uint8 enc_4v_min, uint8 *enc_4v,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;
    uint8 v_mean = enc_1v ? 255 :0;
    uint8 v_min = enc_4v_min;

    if(enc_ch4v_sel == 0)
    {
        for(i=0; i<4; i++)
        {
            dec_g[i] = v_mean;
            dec_b[i] = v_mean;
        }

        if(enc_4v_quant)
        {
            for(i=0; i<4; i++)
                dec_r[i] = round_dq(enc_4v[i], rnb[i]);
        }
        else
        {
            for(i=0; i<4; i++)
                dec_r[i] = v_min + enc_4v[i];
        }
    }
    else if(enc_pat3_ch4v_sel == 1)
    {
        for(i=0; i<4; i++)
        {
            dec_r[i] = v_mean;
            dec_b[i] = v_mean;
        }

        if(enc_4v_quant)
        {
            for(i=0; i<4; i++)
                dec_g[i] = round_dq(enc_4v[i], rnb[i]);
        }
        else
        {
            for(i=0; i<4; i++)
                dec_g[i] = v_min + enc_4v[i];
        }
    }
    else
    {
        for(i=0; i<4; i++)
        {
            dec_r[i] = v_mean;
            dec_g[i] = v_mean;
        }

        if(enc_4v_quant)
        {
            for(i=0; i<4; i++)
                dec_b[i] = round_dq(enc_4v[i], rnb[i]);
        }
        else
        {
            for(i=0; i<4; i++)
                dec_b[i] = v_min + enc_4v[i];
        }
    }
}

void fmc_enc_pat3_pzc1(int *diff_sum)
{
    int i;
    uint8 rm = (R_mean>>7);
    uint8 gm = (G_mean>>7);

    uint8 rnb[4] = {3,3,3,3};

    enc_pat3_ch4v_sel = CH_most_sharp;

    uint8 mean_1v[3] = {gm, rm, rm};
    uint8 min_4v[3] = {R_min, G_min, B_min};
    uint8 range_4v[3] = {R_range, G_range, B_range};
    uint8 *in_4v[3] = {Rin2x2, Gin2x2, Bin2x2};

    uint8 v_1v = mean_1v[enc_pat3_ch4v_sel];
    uint8 V_min = min_4v[enc_pat3_ch4v_sel];
    uint8 V_range = range_4v[enc_pat3_ch4v_sel];
    uint8 *Vin = in_4v[enc_pat3_ch4v_sel];

    enc_pat3_1v = v_1v;
    enc_pat3_4v_min = V_min;
    enc_pat3_4v_quant = (V_range > 11);

    uint8 dq_4v_min = V_min;

    uint8 delta;
    if(enc_pat3_4v_quant)
    {
        for(i=0; i<4; i++)
            enc_pat3_4v[i] = round_q(Vin[i], rnb[i]);
    }
    else
    {
        for(i=0; i<4; i++)
        {
            delta = Vin[i] - dq_4v_min;
            if(delta > 7)
                delta = 7;

            enc_pat3_4v[i] = delta;
        }
    }

    fmc_dec_pat3_pzc1(enc_pat3_ch4v_sel, enc_pat3_1v, enc_pat3_4v_quant, enc_pat3_4v_min, enc_pat3_4v,
        pdec_pat3_R, pdec_pat3_G, pdec_pat3_B, rnb);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_pat3_R, pdec_pat3_G, pdec_pat3_B, diff_sum);

    copy_block(4, rnb_pat3, rnb);
}


void fmc_dec_pat4_pzc2(uint8 enc_ch4v_sel, uint8 enc_1v, uint8 *enc_4v,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;
    uint8 v_mean = round_dq(enc_1v, rnb[0]);

    uint8 v_4v[4];
    for(i=0; i<4; i++)
        v_4v[i] = round_dq(enc_4v[i], rnb[i+1]);


    if(enc_ch4v_sel == 0)
    {
        for(i=0; i<4; i++)
        {
            dec_r[i] = v_4v[i];
            dec_g[i] = v_mean;
            dec_b[i] = v_mean;
        }
    }
    else if(enc_pat3_ch4v_sel == 1)
    {
        for(i=0; i<4; i++)
        {
            dec_g[i] = v_4v[i];
            dec_r[i] = v_mean;
            dec_b[i] = v_mean;
        }
    }
    else
    {
        for(i=0; i<4; i++)
        {
            dec_b[i] = v_4v[i];
            dec_r[i] = v_mean;
            dec_g[i] = v_mean;
        }
    }
}

void fmc_enc_pat4_pzc2(int *diff_sum)
{
    int i;
    uint8 rnb[5] = {2, 4,4,4,4};

    uint8 rm = round_q(R_mean, rnb[0]);
    uint8 gm = round_q(G_mean, rnb[0]);

    enc_pat4_ch4v_sel = CH_most_sharp;

    uint8 mean_1v[3] = {gm, rm, rm};
    uint8 *in_4v[3] = {Rin2x2, Gin2x2, Bin2x2};

    enc_pat4_1v = (pzc_bc || pzc_rc) ? 0 : mean_1v[enc_pat4_ch4v_sel];
    uint8 *Vin = in_4v[enc_pat4_ch4v_sel];

    for(i=0; i<4; i++)
        enc_pat4_4v[i] = round_q(Vin[i], rnb[i+1]);

    fmc_dec_pat4_pzc2(enc_pat4_ch4v_sel, enc_pat4_1v, enc_pat4_4v, pdec_pat4_R, pdec_pat4_G, pdec_pat4_B, rnb);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_pat4_R, pdec_pat4_G, pdec_pat4_B, diff_sum);

    copy_block(5, rnb_pat4, rnb);
}

void fmc_dec_pat5_pzc_rcbc(uint8 enc_bc, uint8 enc_idx, uint8 *enc_g, uint8 *enc_rb,
        uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;
    uint8 dec_rb[4];
    fmc_dec_3kc(enc_idx, enc_g, dec_g, rnb);
    fmc_dec_3kc(enc_idx, enc_rb, dec_rb, rnb+3);
    for(i=0; i<4; i++)
    {
        dec_r[i] = enc_bc ? 128 : dec_rb[i];
        dec_b[i] = enc_bc ? dec_rb[i] : 128;
    }
}

void fmc_enc_pat5_pzc_rcbc(int *diff_sum)
{
    enc_pat5_bc = (R_range==0) && (R_mean==128);
    uint8 bp3_idx_rb = enc_pat5_bc ? Bbp3_idx : Rbp3_idx;
    enc_pat5_bp3_idx = (enc_Ybp3_idx != Gbp3_idx && enc_Ybp3_idx != bp3_idx_rb) ? Gbp3_idx : enc_Ybp3_idx;

#ifdef DAZ_ICH_MODE_EN
    uint8 rnb[6] = {3,3,3, 5,5,5};
#else
    uint8 rnb[6] = {2,3,3, 5,5,5};
#endif

    if(enc_pat5_bp3_idx==2 || enc_pat5_bp3_idx==3)
        rnb[3] = 4;

    fmc_enc_3kc(enc_pat5_bp3_idx, Gin2x2, enc_pat5_g, rnb);

    if(enc_pat5_bc)
        fmc_enc_3kc(enc_pat5_bp3_idx, Bin2x2, enc_pat5_rb, rnb+3);
    else
        fmc_enc_3kc(enc_pat5_bp3_idx, Rin2x2, enc_pat5_rb, rnb+3);

    fmc_dec_pat5_pzc_rcbc(enc_pat5_bc, enc_pat5_bp3_idx, enc_pat5_g, enc_pat5_rb,
        pdec_pat5_R, pdec_pat5_G, pdec_pat5_B, rnb);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_pat5_R, pdec_pat5_G, pdec_pat5_B, diff_sum);

    copy_block(6, rnb_pat5, rnb);
}

uint8 fmc_pat_enc_dec_top(int *diff_sum)
{
    const uint8 mode_cnt = 6;
    int df_sum[mode_cnt];

    fmc_enc_pat0_2kc_2v(df_sum+1);
    fmc_enc_pat1_ch_ab_c(df_sum+2);
    fmc_enc_pat2_2kc_gray_color(df_sum+0);
    fmc_enc_pat3_pzc1(df_sum+3);
    fmc_enc_pat4_pzc2(df_sum+4);
    fmc_enc_pat5_pzc_rcbc(df_sum+5);

    uint8 min_diff_idx = get_min_idx_i32(mode_cnt, df_sum);

    uint8 pat_enc_mode;
    switch(min_diff_idx)
    {
        case 1:
            pat_enc_mode = FMC_ENC_MODE_PAT0_2KC_2V;
            copy_block(BLK_SIZE, pdec_pat_R, pdec_pat0_R);
            copy_block(BLK_SIZE, pdec_pat_G, pdec_pat0_G);
            copy_block(BLK_SIZE, pdec_pat_B, pdec_pat0_B);
            break;
        case 2:
            pat_enc_mode = FMC_ENC_MODE_PAT1_CH_AB_C;
            copy_block(BLK_SIZE, pdec_pat_R, pdec_pat1_R);
            copy_block(BLK_SIZE, pdec_pat_G, pdec_pat1_G);
            copy_block(BLK_SIZE, pdec_pat_B, pdec_pat1_B);
            break;
        case 0:
            pat_enc_mode = FMC_ENC_MODE_PAT2_2KC_GR_CLR;
            copy_block(BLK_SIZE, pdec_pat_R, pdec_pat2_R);
            copy_block(BLK_SIZE, pdec_pat_G, pdec_pat2_G);
            copy_block(BLK_SIZE, pdec_pat_B, pdec_pat2_B);
            break;
        case 3:
            pat_enc_mode = FMC_ENC_MODE_PAT3_PZC1;
            copy_block(BLK_SIZE, pdec_pat_R, pdec_pat3_R);
            copy_block(BLK_SIZE, pdec_pat_G, pdec_pat3_G);
            copy_block(BLK_SIZE, pdec_pat_B, pdec_pat3_B);
            break;
        case 4:
            pat_enc_mode = FMC_ENC_MODE_PAT4_PZC2;
            copy_block(BLK_SIZE, pdec_pat_R, pdec_pat4_R);
            copy_block(BLK_SIZE, pdec_pat_G, pdec_pat4_G);
            copy_block(BLK_SIZE, pdec_pat_B, pdec_pat4_B);
            break;
        default:
            pat_enc_mode = FMC_ENC_MODE_PAT5_PZC_RCBC;
            copy_block(BLK_SIZE, pdec_pat_R, pdec_pat5_R);
            copy_block(BLK_SIZE, pdec_pat_G, pdec_pat5_G);
            copy_block(BLK_SIZE, pdec_pat_B, pdec_pat5_B);
            break;
    }

    *diff_sum = df_sum[min_diff_idx];

    return pat_enc_mode;
}

