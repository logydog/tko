#ifndef __DAZ_FMC_ENC_ICH_H__
#define __DAZ_FMC_ENC_ICH_H__

#include "const_def.h"
#include "data_type.h"
#include "main.h"

uint8 fmc_ich_enc_dec_top(bool slice_start, int *diff_sum);
void update_ich_buf(bool slice_start,
					uint8 (*R_buf)[ICH_BUF_SIZE_X], uint8 (*G_buf)[ICH_BUF_SIZE_X], uint8 (*B_buf)[ICH_BUF_SIZE_X],
					uint8 *R_prev_dec, uint8 *G_prev_dec, uint8 *B_prev_dec);
void fmc_dec_ich(uint8 enc_mode, uint8 enc_idx, uint8 *enc_r, uint8 *enc_g, uint8 *enc_b,
				uint8 (*ich_buf_r)[ICH_BUF_SIZE_X], uint8 (*ich_buf_g)[ICH_BUF_SIZE_X], uint8 (*ich_buf_b)[ICH_BUF_SIZE_X],
				uint8 *dec_r, uint8 *dec_g, uint8 *dec_b);


#endif
