/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "../main.h"

#define COLOR_SPACE_CONV_ROUND_TO_NEAREST 1

double r2y_coef_flt[5] =
{
     (0.257*1.164),  (0.504*1.164),  (0.098*1.164),
     (1/2.018),
     (1/1.596),
};

double y2r_coef_flt[4] =
{
     1.596,
     2.018,
     -0.391, -0.813,
};

int r2y_coef[5];
int y2r_coef[4];

#define CSC_COEF_FRAC_BITS 8

static
int rounding(double din)
{
    double din_abs;
    int y;

    din_abs = (din<0) ? -din : din;
    y = (int)(din_abs + 0.5);
    return ((din<0) ? -y : y);
}

void rgb2ycbcr(int blk_size, uint8 *Rin, uint8 *Gin, uint8 *Bin,
    uint8 *Yin, uint8 *CBin, uint8 *CRin);

void csc_table_init(void)
{
    int i;

    int n = (1L<<CSC_COEF_FRAC_BITS);

    for(i=0; i<5; i++)
    {
        r2y_coef[i] = rounding(r2y_coef_flt[i] * n);
    }

    for(i=0; i<4; i++)
    {
        y2r_coef[i] = rounding(y2r_coef_flt[i] * n);
    }
}

void rgb2ycbcr(int blk_size, uint8 *Rin, uint8 *Gin, uint8 *Bin,
    uint8 *Yin, uint8 *CBin, uint8 *CRin)
{
    int i;
    int16 y, cb, cr;
    int16 rin, gin, bin;
    int v32;
    int add_for_rounding = COLOR_SPACE_CONV_ROUND_TO_NEAREST ? (1<<(CSC_COEF_FRAC_BITS-1)): 0;

    for(i=0; i<blk_size; i++)
    {
        rin = (int16) Rin[i];
        gin = (int16) Gin[i];
        bin = (int16) Bin[i];

        v32 = (r2y_coef[0]*rin + r2y_coef[1]*gin  + r2y_coef[2]*bin);
        y = (int16)((v32+add_for_rounding) >> CSC_COEF_FRAC_BITS);

        v32 = r2y_coef[3] * (bin - y);
        cb = ((v32+add_for_rounding)>>CSC_COEF_FRAC_BITS);
        cb += 128;

        v32 = r2y_coef[4] * (rin - y);
        cr = ((v32+add_for_rounding)>>CSC_COEF_FRAC_BITS);
        cr += 128;

        Yin[i] = (uint8)y;
        CBin[i] = (uint8)cb;
        CRin[i] = (uint8)cr;
    }
}


void ycbcr2rgb(int blk_size, uint8 *Rout, uint8 *Gout, uint8 *Bout,
    uint8 *Yout, uint8 *CBout, uint8 *CRout)
{
    int i;
    int v32;
    int16 y, cb, cr;
    int16 rout, gout, bout;
    int add_for_rounding = COLOR_SPACE_CONV_ROUND_TO_NEAREST ? (1<<(CSC_COEF_FRAC_BITS-1)): 0;

    for(i=0; i<blk_size; i++)
    {
        y = (int16)Yout[i];
        cb = (int16)CBout[i] - 128;
        cr = (int16)CRout[i] - 128;

        v32 = y2r_coef[0]*cr;
        rout = (int16)((v32+add_for_rounding)>>CSC_COEF_FRAC_BITS);
        rout += y;

        v32 = y2r_coef[1]*cb;
        bout = (int16)((v32+add_for_rounding)>>CSC_COEF_FRAC_BITS);
        bout += y;

        v32 = y2r_coef[3]*cr + y2r_coef[2]*cb;
        gout = (int16)((v32+add_for_rounding)>>CSC_COEF_FRAC_BITS);
        gout += y;

        if(rout<0)
            rout=0;
        else if(rout>255)
            rout=255;

        if(gout<0)
            gout=0;
        else if(gout>255)
            gout=255;

        if(bout<0)
            bout=0;
        else if(bout>255)
            bout=255;

        Rout[i] = (uint8)rout;
        Gout[i] = (uint8)gout;
        Bout[i] = (uint8)bout;
    }
}
