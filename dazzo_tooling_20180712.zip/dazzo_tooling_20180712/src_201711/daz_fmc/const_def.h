#ifndef __DAZ_FMC_CONST_DEF_H__
#define __DAZ_FMC_CONST_DEF_H__


#define BLK_SIZE (4)
#define BSTREAM_BYTE_CNT (4)
//#define DAZ_ICH_MODE_EN --> comment out for 2x2 block (or would be full line)

#define ICH_BUF_SIZE_X (9)
#define ICH_BUF_SIZE_Y (2)

#define RAYDIUM_EN_M12
#define RAYDIUM_EN_M3
#define RAYDIUM_EN_M4
#define RAYDIUM_EN_M5
#define RAYDIUM_EN_M6


enum
{
    FMC_ENC_MODE_YUV2 = 0,
    FMC_ENC_MODE_YUV3,
    FMC_ENC_MODE_YUV4,
    FMC_ENC_MODE_RGB1,
    FMC_ENC_MODE_RGB2,
    FMC_ENC_MODE_RGB3,
    FMC_ENC_MODE_RGB4,
    FMC_ENC_MODE_GRAY3,
    FMC_ENC_MODE_GRAY4,
    FMC_ENC_MODE_PAT0_2KC_2V,
    FMC_ENC_MODE_PAT1_CH_AB_C,
    FMC_ENC_MODE_PAT2_2KC_GR_CLR,
    FMC_ENC_MODE_PAT3_PZC1,
    FMC_ENC_MODE_PAT4_PZC2,
    FMC_ENC_MODE_PAT5_PZC_RCBC,
    FMC_ENC_MODE_ICH0,
    FMC_ENC_MODE_ICH1,
    FMC_ENC_MODE_ICH2,
    FMC_ENC_MODE_ICH3,
    FMC_ENC_MODE_ICH4,
    FMC_ENC_MODE_ICH5,
    FMC_ENC_MODE_ICH6,
    FMC_ENC_MODE_ICH7,
    FMC_ENC_MODE_INVALID
};

#define MODE_CNT (FMC_ENC_MODE_INVALID+1)

enum
{
    BS_HDR_YUV2         = 0x00,
    BS_HDR_YUV3         = 0x01,
    BS_HDR_YUV4         = 0x02,
    BS_HDR_RGB3         = 0x03,

    BS_HDR_PAT1_CH_AB_C = 0x05,

#ifdef DAZ_ICH_MODE_EN
    BS_HDR_GRAY4        = 0x04,
   	BS_HDR_ICH          = 0x0e,
   	BS_HDR_PAT5_PZC_RCBC = 0x06,
#else
    BS_HDR_GRAY4        = 0x04,
    BS_HDR_PAT5_PZC_RCBC = 0x06,
    BS_HDR_ICH          = 0,
#endif

    BS_HDR_RGB2         = 0x07,
    BS_HDR_GRAY3        = 0x0f,
    BS_HDR_RGB4         = 0x17,

    BS_HDR_PAT2_GR_COLR = 0x1f,

    BS_HDR_RGB1         = 0x3f,
    BS_HDR_PAT0_2KC_2V  = 0x7f,
    BS_HDR_PAT3_PZC1    = 0xbf,
    BS_HDR_PAT4_PZC2    = 0xff,

    BS_HDR_RESERVED     = 0
};

#endif
