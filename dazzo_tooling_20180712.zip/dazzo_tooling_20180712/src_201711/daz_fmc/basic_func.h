#ifndef __DAZ_FMC_BASIC_FUNC_H__
#define __DAZ_FMC_BASIC_FUNC_H__

#include "data_type.h"
#include "main.h"

void copy_block(int blk_size, uint8 *tgt_blk, uint8 *src_blk);
uint8 get_abs_diff(uint8 va, uint8 vb);
int get_sum(int blk_size, uint8 *Vin);
uint8 get_mean2(uint8 va, uint8 vb);
uint8 get_mean3(uint8 va, uint8 vb, uint8 vc);
uint8 get_mean4(uint8 *v);
void get_diff_info(int blk_size, uint8 *Yin, uint8 *Ypdec, int *diff_sum);
void get_diff_info3(int blk_size, uint8 *Rin, uint8 *Gin, uint8 *Bin,
        uint8 *Rpdec, uint8 *Gpdec, uint8 *Bpdec, int *diff_sum);
uint8 round_q(uint8 vin, uint8 reduce_bits);
uint8 round_dq(uint8 vin, uint8 reduce_bits);
uint8 get_min(int blk_size, uint8 *values);
uint8 get_min_idx_i32(int blk_size, int *values);
uint8 get_min_idx_u8(int blk_size, uint8 *values);
uint8 get_max_idx_u8(int blk_size, uint8 *values);
uint8 get_max(int blk_size, uint8 *values);
uint8 div_123(uint16 sum, uint8 cnt);

#endif
