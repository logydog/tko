/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "../main.h"
#include "data_type.h"
#include "main.h"

void input_block(int src_x, int src_y, int blk_w, int blk_h,
    uint8 *Rin, uint8 *Gin, uint8 *Bin, FrameInfo *SrcFrame)
{
    int i, j, k;
	int frm_w = SrcFrame->frame_w;
	int frm_h = SrcFrame->frame_h;
    int idx_line;
    int idx_pxl;
    int idx_blk = 0;

    for(j=0; j<blk_h; j++)
    {
		k = src_y + j;
		if(k >= frm_h)
			k = frm_h-1;

        idx_line = k * frm_w;

        idx_pxl = idx_line + src_x;
        for(i=0; i<blk_w; i++)
        {
            if(src_x +i >= frm_w)
				k = idx_line+frm_w-1;
			else
				k = idx_pxl+i;

            Rin[idx_blk] = SrcFrame->y_data[k];
            Gin[idx_blk] = SrcFrame->u_data[k];
            Bin[idx_blk] = SrcFrame->v_data[k];
            idx_blk ++;
        }
    }
}

void output_block(int src_x, int src_y, int blk_w, int blk_h,
    uint8 *Rout, uint8 *Gout, uint8 *Bout, FrameInfo *TgtFrame)
{
    int i, j;
	int frm_w = TgtFrame->frame_w;
	int frm_h = TgtFrame->frame_h;
    int idx_line = src_y * frm_w;
    int idx_img = idx_line + src_x;
    int idx_blk = 0;

    for(j=0; j<blk_h; j++)
    {
        for(i=0; i<blk_w; i++)
        {
            if((src_y+j < frm_h) && (src_x +i < frm_w))
            {
                TgtFrame->y_data[idx_img+i] = Rout[idx_blk];
                TgtFrame->u_data[idx_img+i] = Gout[idx_blk];
                TgtFrame->v_data[idx_img+i] = Bout[idx_blk];
            }
            idx_blk ++;
        }
        idx_img += frm_w;
    }
}
