#ifndef __DAZ_FMC_ENC_PREP_H__
#define __DAZ_FMC_ENC_PREP_H__

#include "data_type.h"
#include "main.h"

void fmc_enc_prepare(void);
uint8 fmc_enc_3kc_get_idx(uint8 *Vin);
uint8 fmc_enc_2kc_get_bplane(uint8 *Vin, uint8 Vthr);
void fmc_enc_2kc_get_color(uint8 *Vin, uint8 idx, uint8 *Vkc);
void fmc_enc_3kc(uint8 idx, uint8 *Vin, uint8 *Venc, uint8 *rnb);
void fmc_dec_3kc(uint8 idx, uint8 *Venc, uint8 *Vdec, uint8 *rnb);

#endif
