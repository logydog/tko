/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: DAZZO_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "daz_fmc.h"
#include "data_type.h"
#include "main.h"

void copy_block(int blk_size, uint8 *tgt_blk, uint8 *src_blk)
{
    int i;
    for(i=0; i<blk_size; i++)
        tgt_blk[i] = src_blk[i];
}

uint8 get_abs_diff(uint8 va, uint8 vb)
{
    uint8 diff;
    int16 aa = (int16)va;
    int16 bb = (int16)vb;

    int16 diff9 = aa - bb;
    if(diff9 < 0)
        diff9 = -diff9;

    diff = (uint8)(diff9 & 0xff);

    return diff;
}

int get_sum(int blk_size, uint8 *Vin)
{
    int i;
    int sum = 0;
    for(i=0; i<blk_size; i++)
        sum += Vin[i];
    return sum;
}

uint8 get_mean2(uint8 va, uint8 vb)
{
    int i_tmp = (int)va + (int)vb;
    i_tmp ++;
    i_tmp >>= 1;

    return (uint8)i_tmp;
}

uint8 get_mean3(uint8 va, uint8 vb, uint8 vc)
{
    int i_tmp = (int)va + (int)vb + (int)vc;
    i_tmp *=171;
    i_tmp >>= 9;

    return (uint8)i_tmp;
}

uint8 get_mean4(uint8 *v)
{
    int i_tmp = (int)v[0] + (int)v[1] + (int)v[2] + (int)v[3];

#ifdef RAYDIUM_EN_M5
    uint8 i1 = (uint8)((i_tmp >> 1) & 1);
    i_tmp >>= 2;
    i_tmp += i1;
#else
    i_tmp +=2;
    i_tmp >>= 2;
#endif


    return (uint8)i_tmp;
}

void get_diff_info(int blk_size, uint8 *Yin, uint8 *Ypdec, int *diff_sum)
{
    int i;
    int diffY;
    int sum_diff = 0;
    int sum_diff_sq = 0;
    for(i=0; i<blk_size; i++)
    {
        diffY = get_abs_diff(Yin[i], Ypdec[i]);

        if(diffY>31)
            diffY <<= 3;
        else if(diffY>15)
            diffY <<= 2;
        else if(diffY>7)
            diffY <<= 1;

        sum_diff += diffY;
        sum_diff_sq += ((int)diffY * (int)diffY);
    }
    *diff_sum = sum_diff;
}

#ifdef RAYDIUM_EN_M3
void get_diff_info_ray(int blk_size, uint8 *Yin, uint8 *Ypdec, int *diff_sum)
{
    int i;
    int diffY;
    int sum_diff = 0;
    int sum_diff_sq = 0;
    for(i=0; i<blk_size; i++)
    {
        diffY = get_abs_diff(Yin[i], Ypdec[i]);

        if(diffY>31)
            diffY <<= 2;
        else if(diffY>15)
            diffY <<= 1;

        sum_diff += diffY;
        sum_diff_sq += ((int)diffY * (int)diffY);
    }
    *diff_sum = sum_diff;
}
#endif

void get_diff_info3(int blk_size, uint8 *Rin, uint8 *Gin, uint8 *Bin,
        uint8 *Rpdec, uint8 *Gpdec, uint8 *Bpdec, int *diff_sum)
{
    int diff[3];

#ifdef RAYDIUM_EN_M3
    get_diff_info_ray(blk_size, Rin, Rpdec, diff+0);
#else
    get_diff_info(blk_size, Rin, Rpdec, diff+0);
#endif

    get_diff_info(blk_size, Gin, Gpdec, diff+1);

#ifdef RAYDIUM_EN_M3
    get_diff_info_ray(blk_size, Bin, Bpdec, diff+2);
#else
    get_diff_info(blk_size, Bin, Bpdec, diff+2);
#endif

    *diff_sum = diff[0] + diff[1] + diff[2];
}

uint8 round_q2(uint8 vin, uint8 reduce_bits)
{
    uint8 vout = vin;
    if(reduce_bits > 0)
    {
        vout >>= reduce_bits;
    }

#ifdef RAYDIUM_EN_M12
    if(reduce_bits == 6)
    {
        if(vin>224)
            vout = 3;
        else if(vin>160)
            vout = 2;
        else if(vin>64)
            vout = 1;
        else
            vout = 0;
    }
#endif

    return vout;
}

uint8 round_dq2(uint8 vin, uint8 reduce_bits)
{
    uint8 vout = vin;

    if(reduce_bits > 0)
    {
        uint8 add = (1<<(reduce_bits - 1));
        vout <<= reduce_bits;

        if(reduce_bits > 1)
            vout += add;
    }

#ifdef RAYDIUM_EN_M12
    if(reduce_bits == 6)
    {
        vout = (vin==3) ? 255 :
                (vin==2) ? 192 :
                (vin==1) ? 128 : 0;
    }
#endif

    return vout;
}

uint8 round_q(uint8 vin, uint8 reduce_bits)
{
    return round_q2(vin, reduce_bits);
}


uint8 round_dq(uint8 vin, uint8 reduce_bits)
{
    return round_dq2(vin, reduce_bits);
}


uint8 get_min(int blk_size, uint8 *values)
{
    int i;
    uint8 vmin = values[0];
    for(i=1; i<blk_size; i++)
    {
        if(values[i] < vmin)
            vmin = values[i];
    }
    return vmin;
}

uint8 get_min_idx_i32(int blk_size, int *values)
{
    int i;
    uint8 idx = 0;
    int vmin = values[0];

    for(i=1; i<blk_size; i++)
    {
        if(values[i] < vmin)
        {
            vmin = values[i];
            idx = i;
        }
    }

    return idx;
}

uint8 get_min_idx_u8(int blk_size, uint8 *values)
{
    uint8 i;
    uint8 idx = 0;
    uint8 vmin = values[0];

    for(i=1; i<blk_size; i++)
    {
        if(values[i] < vmin)
        {
            vmin = values[i];
            idx = i;
        }
    }

    return idx;
}

uint8 get_max_idx_u8(int blk_size, uint8 *values)
{
    uint8 i;
    uint8 idx = 0;
    uint8 vmax = values[0];

    for(i=1; i<blk_size; i++)
    {
        if(values[i] > vmax)
        {
            vmax = values[i];
            idx = i;
        }
    }

    return idx;
}


uint8 get_max(int blk_size, uint8 *values)
{
    int i;
    uint8 vmax = values[0];
    for(i=1; i<blk_size; i++)
    {
        if(values[i] > vmax)
            vmax = values[i];
    }
    return vmax;
}
