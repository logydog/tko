/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

static uint8 pdec_yuv2_Y[BLK_SIZE];
static uint8 pdec_yuv2_CB[BLK_SIZE];
static uint8 pdec_yuv2_CR[BLK_SIZE];

static uint8 pdec_yuv3_Y[BLK_SIZE];
static uint8 pdec_yuv3_CB[BLK_SIZE];
static uint8 pdec_yuv3_CR[BLK_SIZE];

static uint8 pdec_yuv4_Y[BLK_SIZE];
static uint8 pdec_yuv4_CB[BLK_SIZE];
static uint8 pdec_yuv4_CR[BLK_SIZE];

void fmc_dec_yuv3(uint8 idx, uint8 *enc_y, uint8 enc_cb, uint8 enc_cr, uint8 *dec_y, uint8 *dec_cb, uint8 *dec_cr, uint8 *rnb)
{
    int i;
    fmc_dec_3kc(idx, enc_y, dec_y, rnb);
    for(i=0; i<4; i++)
    {
        dec_cb[i] = round_dq(enc_cb, rnb[3]);
        dec_cr[i] = round_dq(enc_cr, rnb[4]);
    }
}

void fmc_enc_yuv3(int *diff_sum)
{
    uint8 rnb[5] = {3,3,4,2,2};
    if(enc_Ybp3_idx < 2)
        rnb[2] = 3;

    fmc_enc_3kc(enc_Ybp3_idx, Yin2x2, enc_yuv3_Y, rnb);
    enc_yuv3_CB = round_q(CB_mean, rnb[3]);
    enc_yuv3_CR = round_q(CR_mean, rnb[4]);

    fmc_dec_yuv3(enc_Ybp3_idx, enc_yuv3_Y, enc_yuv3_CB, enc_yuv3_CR, pdec_yuv3_Y, pdec_yuv3_CB, pdec_yuv3_CR, rnb);

    get_diff_info(BLK_SIZE, Yin2x2, pdec_yuv3_Y, diff_sum);

    copy_block(5, rnb_yuv3, rnb);
}

void fmc_dec_yuv4(uint8 *enc_y, uint8 enc_cb, uint8 enc_cr, uint8 *dec_y, uint8 *dec_cb, uint8 *dec_cr, uint8 *rnb)
{
    int i;
    for(i=0; i<4; i++)
    {
        dec_y[i] = round_dq(enc_y[i], rnb[i]);
        dec_cb[i] = round_dq(enc_cb, rnb[4]);
        dec_cr[i] = round_dq(enc_cr, rnb[5]);
    }
}

void fmc_enc_yuv4(int *diff_sum)
{
    int i;

    uint8 rnb[6] = {4,4,4,4,2,1};

    for(i=0; i<4; i++)
        enc_yuv4_Y[i] = round_q(Yin2x2[i], rnb[i]);

    enc_yuv4_CB = round_q(CB_mean, rnb[4]);
    enc_yuv4_CR = round_q(CR_mean, rnb[5]);

    fmc_dec_yuv4(enc_yuv4_Y, enc_yuv4_CB, enc_yuv4_CR, pdec_yuv4_Y, pdec_yuv4_CB, pdec_yuv4_CR, rnb);
    get_diff_info(BLK_SIZE, Yin2x2, pdec_yuv4_Y, diff_sum);

    copy_block(6, rnb_yuv4, rnb);
}


void fmc_dec_yuv2(uint8 enc_idx, uint8 *enc_y, uint8 enc_cb, uint8 enc_cr, uint8 *dec_y, uint8 *dec_cb, uint8 *dec_cr, uint8 *rnb)
{
    int i;
    uint8 dq_y[2];

    uint8 enc_bp[4];
    for(i=0; i<3; i++)
        enc_bp[i] = ((enc_idx >> i) & 1);
    enc_bp[3] = 0;

    for(i=0; i<2; i++)
        dq_y[i] = round_dq(enc_y[i], rnb[i]);

    for(i=0; i<BLK_SIZE; i++)
    {
        dec_y[i] = enc_bp[i] ? dq_y[1] : dq_y[0];

        dec_cb[i] = round_dq(enc_cb, rnb[2]);
        dec_cr[i] = round_dq(enc_cr, rnb[3]);
    }
}

void fmc_enc_yuv2(int *diff_sum)
{
    uint8 rnb[4] = {2,2,1,1};
    copy_block(4, rnb_yuv2, rnb);

    fmc_enc_2kc_get_color(Yin2x2, enc_Ybp2_idx, full_yuv2_Y);

    enc_yuv2_Y[0] = round_q(full_yuv2_Y[0], rnb[0]);
    enc_yuv2_Y[1] = round_q(full_yuv2_Y[1], rnb[1]);
    enc_yuv2_CB = round_q(CB_mean, rnb[2]);
    enc_yuv2_CR = round_q(CR_mean, rnb[3]);

    fmc_dec_yuv2(enc_Ybp2_idx, enc_yuv2_Y, enc_yuv2_CB, enc_yuv2_CR, pdec_yuv2_Y, pdec_yuv2_CB, pdec_yuv2_CR, rnb);

    get_diff_info(BLK_SIZE, Yin2x2, pdec_yuv2_Y, diff_sum);
}

uint8 fmc_yuv_enc_dec_top(int *diff_sum)
{
    int df_sum[3];
    fmc_enc_yuv2(df_sum+0);
    fmc_enc_yuv3(df_sum+1);
    fmc_enc_yuv4(df_sum+2);

    uint8 min_diff_idx = get_min_idx_i32(3, df_sum);

    uint8 yuv_enc_mode;
    switch(min_diff_idx)
    {
        case 0:
            yuv_enc_mode = FMC_ENC_MODE_YUV2;
            copy_block(BLK_SIZE, pdec_yuv_Y, pdec_yuv2_Y);
            copy_block(BLK_SIZE, pdec_yuv_CB, pdec_yuv2_CB);
            copy_block(BLK_SIZE, pdec_yuv_CR, pdec_yuv2_CR);
            break;
        case 1:
            yuv_enc_mode = FMC_ENC_MODE_YUV3;
            copy_block(BLK_SIZE, pdec_yuv_Y, pdec_yuv3_Y);
            copy_block(BLK_SIZE, pdec_yuv_CB, pdec_yuv3_CB);
            copy_block(BLK_SIZE, pdec_yuv_CR, pdec_yuv3_CR);
            break;
        default:
            yuv_enc_mode = FMC_ENC_MODE_YUV4;
            copy_block(BLK_SIZE, pdec_yuv_Y, pdec_yuv4_Y);
            copy_block(BLK_SIZE, pdec_yuv_CB, pdec_yuv4_CB);
            copy_block(BLK_SIZE, pdec_yuv_CR, pdec_yuv4_CR);
            break;
    }

    ycbcr2rgb(BLK_SIZE, pdec_yuv_R, pdec_yuv_G, pdec_yuv_B, pdec_yuv_Y, pdec_yuv_CB, pdec_yuv_CR);

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_yuv_R, pdec_yuv_G, pdec_yuv_B, diff_sum);

    return yuv_enc_mode;

}
