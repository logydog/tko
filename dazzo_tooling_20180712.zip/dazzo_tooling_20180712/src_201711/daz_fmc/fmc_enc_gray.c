/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

static uint8 pdec_gray4_R[BLK_SIZE];
static uint8 pdec_gray4_G[BLK_SIZE];
static uint8 pdec_gray4_B[BLK_SIZE];

static uint8 pdec_gray3_R[BLK_SIZE];
static uint8 pdec_gray3_G[BLK_SIZE];
static uint8 pdec_gray3_B[BLK_SIZE];

void fmc_dec_gray4(uint8 enc_quant, uint8 enc_min, uint8 *enc_data, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;
    uint8 enc_min2 = enc_min;

    if(enc_quant)
    {
        for(i=0; i<4; i++)
            dec_r[i] = round_dq(enc_data[i], rnb[i]);
    }
    else
    {
        for(i=0; i<4; i++)
            dec_r[i] = enc_min2 + enc_data[i];
    }

    for(i=0; i<4; i++)
    {
        dec_g[i] = dec_r[i];
        dec_b[i] = dec_r[i];
    }
}
void fmc_enc_gray4(int *diff_sum)
{
    int i;
    uint8 gray_min_after_dec;

    uint8 rnb[4] = {1,1,1,1};

	enc_gray4_min = Gray_min;
    gray_min_after_dec = Gray_min;
    enc_gray4_quant = (Gray_range > 31);

    if(enc_gray4_quant)
    {
        for(i=0; i<4; i++)
            enc_gray4[i] = round_q(GRAYin2x2[i], rnb[i]);
    }
    else
    {
        for(i=0; i<4; i++)
            enc_gray4[i] = GRAYin2x2[i] - gray_min_after_dec;
    }
    fmc_dec_gray4(enc_gray4_quant, enc_gray4_min, enc_gray4, pdec_gray4_R, pdec_gray4_G, pdec_gray4_B, rnb);

    get_diff_info(BLK_SIZE, GRAYin2x2, pdec_gray4_R, diff_sum);

    copy_block(4, rnb_gray4, rnb);
}

void fmc_dec_gray3(uint8 idx, uint8 *enc_data, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb)
{
    int i;
    fmc_dec_3kc(idx, enc_data, dec_r, rnb);

    for(i=0; i<4; i++)
    {
        dec_g[i] = dec_r[i];
        dec_b[i] = dec_r[i];
    }
}

void fmc_enc_gray3(int *diff_sum)
{
    uint8 rnb[3] = {0,0,0};
    fmc_enc_3kc(enc_Ybp3_idx, GRAYin2x2, enc_gray3, rnb);
    fmc_dec_gray3(enc_Ybp3_idx, enc_gray3, pdec_gray3_R, pdec_gray3_G, pdec_gray3_B, rnb);

    get_diff_info(BLK_SIZE, GRAYin2x2, pdec_gray3_R, diff_sum);

    copy_block(3, rnb_gray3, rnb);
}

uint8 fmc_gray_enc_dec_top(int *diff_sum)
{
    int df_sum[2];

    fmc_enc_gray3(df_sum+0);
    fmc_enc_gray4(df_sum+1);

    uint8 min_diff_idx = get_min_idx_i32(2, df_sum);

    uint8 gray_enc_mode;
    switch(min_diff_idx)
    {
        case 0:
            gray_enc_mode = FMC_ENC_MODE_GRAY3;
            copy_block(BLK_SIZE, pdec_gray_R, pdec_gray3_R);
            copy_block(BLK_SIZE, pdec_gray_G, pdec_gray3_G);
            copy_block(BLK_SIZE, pdec_gray_B, pdec_gray3_B);
            break;
        default:
            gray_enc_mode = FMC_ENC_MODE_GRAY4;
            copy_block(BLK_SIZE, pdec_gray_R, pdec_gray4_R);
            copy_block(BLK_SIZE, pdec_gray_G, pdec_gray4_G);
            copy_block(BLK_SIZE, pdec_gray_B, pdec_gray4_B);
    }

    get_diff_info3(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, pdec_gray_R, pdec_gray_G, pdec_gray_B, diff_sum);

    return gray_enc_mode;

}
