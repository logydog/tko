#ifndef __DAZ_FMC_ENC_RGB_H__
#define __DAZ_FMC_ENC_RGB_H__

#include "data_type.h"
#include "main.h"

uint8 fmc_rgb_enc_dec_top(int *diff_sum);
void fmc_enc_rgb1(int *diff_sum);
void fmc_enc_rgb2(int *diff_sum);
void fmc_enc_rgb3(int *diff_sum);
uint8 fmc_enc_rgb4(int *diff_sum);
void fmc_dec_rgb1(uint8 *enc_data, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b);
void fmc_dec_rgb2(uint8 idx, uint8 *enc_r, uint8 *enc_g, uint8 *enc_b, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);
void fmc_dec_rgb3(uint8 idx, uint8 *enc_r, uint8 *enc_g, uint8 *enc_b, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);
void fmc_dec_rgb4(uint8 enc_qmode, uint8 *enc_data, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);

#endif
