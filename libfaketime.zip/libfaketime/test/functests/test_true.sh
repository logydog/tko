# test suite that always succeeds - for testing framework

run()
{
	run_testcase true
	return 0
}
