/**********************************
/*     BMP to RGB
/*
/*
/*
/*************************************/
#include <stdio.h>

main(argc, argv)
   int argc;
   char **argv;
{
int width,height;
unsigned long c;
FILE *fptri,*fptro;
int i,j,h,w;
unsigned long **mem; 
int UD;

if((argc!=5)&&(argc!=3) &&(argc!=6) &&(argc!=4))
{printf("Error !\n USE : bmp2rgb input output (width height) (UD)\n"); exit(0);}

if((fptri=fopen(argv[1],"rb"))==NULL)
{printf("Error open input file");
 exit(0);}
if((fptro=fopen(argv[2],"w"))==NULL)
{printf("Error open output file");
 exit(0);}

if(argc==5)
{
  width=atoi(argv[3]);
  height=atoi(argv[4]);
  UD = 1;
}

else if(argc==6)
{
  width=atoi(argv[3]);
  height=atoi(argv[4]);
  UD = 1;
}

else if(argc==4)
{
  fseek(fptri,18,SEEK_SET);
  fread(&width,sizeof(char),4,fptri);
  fread(&height,sizeof(char),4,fptri);
  printf("width=%d  height=%d\n",width,height);
  UD= 1;
}

else
{
  fseek(fptri,18,SEEK_SET);
  fread(&width,sizeof(char),4,fptri);
  fread(&height,sizeof(char),4,fptri);
  printf("width=%d  height=%d\n",width,height);
  UD=1;
}




fseek(fptri,54,SEEK_SET);
c=0;


if ((mem = (unsigned long **) malloc(height*sizeof(unsigned long *))) == NULL)
  {   printf("Not enough memory to allocate buffer 1\n");
      exit(0);
  }
  
  for(i=0;i<height;i++)
  { if ((mem[i] = (unsigned long *) malloc(width*sizeof(unsigned long))) == NULL)
    {   printf("Not enough memory to allocate buffer 1\n");
        exit(0); 
    }
  }


for (h=0;h<height;h++)
{
for (w=0;w<width;w++)
{
   fread(&c,sizeof(char),3,fptri);
   mem[h][w] = c;
}

   if(((width*3)%4)==1)
     fread(&c,sizeof(char),3,fptri);
   else if(((width*3)%4)==2)
     fread(&c,sizeof(char),2,fptri);
   else if(((width*3)%4)==3)
     fread(&c,sizeof(char),1,fptri);
}

for (j=0;j<height;j++)
{  for (i=0;i<width;i++)
   {
      if(UD==1)
         c = mem[height-1-j][i];
      else
         c = mem[j][i];

      fprintf(fptro,"%06X\n",c);
   }
//   if(((width*3)%4)==1)
//     fread(&c,sizeof(unsigned char),3,fptri);
//   else if(((width*3)%4)==2)
//     fread(&c,sizeof(char),2,fptri);
//   else if(((width*3)%4)==3)
//     fread(&c,sizeof(unsigned char),1,fptri);
}

fclose(fptri);
fclose(fptro);
}
