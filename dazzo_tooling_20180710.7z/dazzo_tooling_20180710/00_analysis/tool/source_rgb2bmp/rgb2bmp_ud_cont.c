/***************************
/*    RGB to BMP
/*    input format : continuous RGB
/*    output  : continuous bmp
/*
/*************************************/
#include<stdio.h>

int stox(char* str,  unsigned long* ans);

main(argc, argv)
   int argc;
   char **argv;
{
FILE *fptri,*fptro;	
int width,height;
int i,h,w;
char filename[80];
unsigned long c;
unsigned long **mem; 
int UD;
int bfSize;
int bfReserved=0;
int bf0ffBits=0x36;
int biSize=0x28;
int biPlanes=0x1;
int biBitCount=24;
int biCompression=0;
int biSizeImage;
int biXPelsPerMeter=0xec4;
int biYPelsPerMeter=0xec4;
int biClrUsed=0;
int biClrImportant=0;
int num;
int pix_R, pix_G, pix_B;
char   BUFFER;
char   str[256];


if((argc!=5)&&(argc!=6))
{printf("Error : rgb2bmp input output width height (UD)\n"); exit(0);}

width=atoi(argv[3]);
height=atoi(argv[4]);

if(argc==6)
{  UD=1; }
else
{  UD=0; }  	


if ((mem = (unsigned long **) malloc(height*sizeof(unsigned long *))) == NULL)
  {   printf("Not enough memory to allocate buffer 1\n");
      exit(0);
  }
  
  for(i=0;i<height;i++)
  { if ((mem[i] = (unsigned long *) malloc(width*sizeof(unsigned long))) == NULL)
    {   printf("Not enough memory to allocate buffer 1\n");
        exit(0); 
    }
  }

	
if((fptri=fopen(argv[1],"r"))==NULL)
{printf("Error open input file");
 exit(0);
}	

num =0;

//printf("\n%d\n",feof(fptri));

while(!feof(fptri))
{   num ++;
    if(num<10)
      sprintf(filename,"%s_000%d.bmp",argv[2],num);
    else if (num<100)
      sprintf(filename,"%s_00%d.bmp",argv[2],num);
    else if (num<1000)
      sprintf(filename,"%s_0%d.bmp",argv[2],num);
    else
      sprintf(filename,"%s_%d.bmp",argv[2],num);
    
    if((fptro=fopen(filename,"wb"))==NULL)
    {printf("Error open output file");
     exit(0);
    }
//    if(num>2000)
//    if(num>300)
//    {printf("too many pictures\n");
//     exit(0);
//    }
    printf("OUTPUT FILE : %s\n",filename);
    
    fwrite("BM",sizeof(char),2,fptro);
    bfSize=width*height*3+54;
    //fwrite(&bfSize,sizeof(char),4,fptro);         
    BUFFER = (bfSize&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bfSize&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bfSize&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bfSize&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    	
    //fwrite(&bfReserved,sizeof(char),4,fptro);
    BUFFER = (bfReserved&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bfReserved&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bfReserved&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bfReserved&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    //fwrite(&bf0ffBits,sizeof(char),4,fptro);
    BUFFER = (bf0ffBits&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bf0ffBits&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bf0ffBits&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (bf0ffBits&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    //fwrite(&biSize,sizeof(char),4,fptro);
    BUFFER = (biSize&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biSize&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biSize&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biSize&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    //fwrite(&width,sizeof(char),4,fptro);
    BUFFER = (width&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (width&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (width&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (width&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    //fwrite(&height,sizeof(char),4,fptro);
    BUFFER = (height&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (height&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (height&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (height&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    
    //fwrite(&biPlanes,sizeof(char),2,fptro);	
    BUFFER = (biPlanes&0x00ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biPlanes&0xff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);

    
    //fwrite(&biBitCount,sizeof(char),2,fptro);
    BUFFER = (biBitCount&0x00ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biBitCount&0xff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    
    
    //fwrite(&biCompression,sizeof(char),4,fptro);
    BUFFER = (biCompression&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biCompression&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biCompression&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biCompression&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    biSizeImage=width*height*3;
    //fwrite(&biSizeImage,sizeof(char),4,fptro);
    BUFFER = (biSizeImage&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biSizeImage&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biSizeImage&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biSizeImage&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    

    //fwrite(&biXPelsPerMeter,sizeof(char),4,fptro);
    BUFFER = (biXPelsPerMeter&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biXPelsPerMeter&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biXPelsPerMeter&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biXPelsPerMeter&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    
    //fwrite(&biYPelsPerMeter,sizeof(char),4,fptro);
    BUFFER = (biYPelsPerMeter&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biYPelsPerMeter&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biYPelsPerMeter&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biYPelsPerMeter&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    
    //fwrite(&biClrUsed,sizeof(char),4,fptro);
    BUFFER = (biClrUsed&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biClrUsed&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biClrUsed&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biClrUsed&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    
    
    //fwrite(&biClrImportant,sizeof(char),4,fptro);
    BUFFER = (biClrImportant&0x000000ff);
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biClrImportant&0x0000ff00)>>8;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biClrImportant&0x00ff0000)>>16;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    BUFFER = (biClrImportant&0xff000000)>>24;
    fwrite(&BUFFER,sizeof(char),1,fptro);
    
    
    c=0;
    for(h=0;h<height;h++)
    {  for(w=0;w<width;w++)
       {   fscanf(fptri,"%s \n" ,str);
           if(stox(str, &c))
           {
              if(UD==1) 
                mem[height-h-1][w] = c;  
              else
                mem[h][w] = c; 
           }
           else
           {
              printf("Unknown value exist.\n");
              exit(0);
           }
       }
    }
    
    
    for(h=0;h<height;h++)
    {  for(w=0;w<width;w++)
       {  c = mem[h][w];
          pix_R = c>>16;
          pix_G =(c&0x00ff00)>>8;
          pix_B =(c&0x0000ff);
          
          //fwrite(&c,sizeof(char),3,fptro);
          
          BUFFER=pix_B;
          
          fwrite(&BUFFER,sizeof(char),1,fptro);

          BUFFER=pix_G;

          fwrite(&BUFFER,sizeof(char),1,fptro);

          BUFFER=pix_R;

          fwrite(&BUFFER,sizeof(char),1,fptro);
          
          
          
       }
       c=0;
       if(((width*3)%4)==3)	
           fwrite(&c,sizeof(char),1,fptro); 	
       else if(((width*3)%4)==2)	
           fwrite(&c,sizeof(char),2,fptro); 	
       else if(((width*3)%4)==1)	
           fwrite(&c,sizeof(char),3,fptro); 
       
       
    }
    
    
  
    fclose(fptro);

}


}

int stox(char* str, unsigned long* ans)
{
    int i;
    unsigned long sum=0;
    for(i=0; str[i]!='\0'; i++)
    {
	if(isxdigit(str[i]))
        {
	   if(isdigit(str[i]))
	     sum = sum * 16 + (str[i]-'0');
           else if(isupper(str[i]))
             sum = sum * 16 + (str[i]-'A'+10);
           else
             sum = sum * 16 + (str[i]-'a'+10);
	}
        else 
        {
	   *ans = 0;
           return 0;
        }
    }
    
    *ans = sum;
    return 1;
}
