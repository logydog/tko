/**********************************
/*     BMP to RGB
/*
/*
/*
/*************************************/
#include <stdio.h>
#include <math.h>

int char_reverse(FILE *f_ori);
int line_reverse(FILE *f_ori);
long count_characters(FILE *);

main(argc, argv)
   int argc;
   char **argv;
{
   int width1,height1;
   int width2,height2;
   unsigned long c1,c2;
   FILE *fptri1,*fptri2,*fptro;
   FILE *f_diffval_r, *f_diffval_g, *f_diffval_b, *f_diffval_RGB, *f_diffval_Y, *f_diffval_U, *f_diffval_V, *f_diffval_YUV;
   FILE *f_diffrat_r, *f_diffrat_g, *f_diffrat_b, *f_diffrat_RGB, *f_diffrat_Y, *f_diffrat_U, *f_diffrat_V, *f_diffrat_YUV;
   FILE *f_log;
   int UD;
   int cont;
   int start_num;
   int num;
   char filename1[80];
   char filename2[80];
   int h,w;
   int err_cnt;

   if((argc!=3)&&(argc!=5))
   {printf("Error !\n USE : compbmp file1 file2 (cont start_num) \n");
    printf(" example1 : compbmp A.bmp B.bmp (compare A.bmp vs B.bmp file)\n");
    printf(" example2 : compbmp A B cont 0 (compare A_0000.bmp vs B_0000.bmp, A_0001.bmp vs B_0001.bmp ......file)\n\n");
    exit(0);
   }


   if(argc==5)
   {
     cont=1;
     start_num = atoi(argv[4]);
   }
   else
   {
     cont=0;
     start_num = 0;
   }


   num=start_num;


   while((cont==0 & num<=start_num) ||(cont==1))
   {
       err_cnt=0;
   if(cont==1)
   {
       if(num<10)
       {   sprintf(filename1,"%s_000%d.bmp",argv[1],num);
           sprintf(filename2,"%s_000%d.bmp",argv[2],num);
       }
       else if (num<100)
       { sprintf(filename1,"%s_00%d.bmp",argv[1],num);
         sprintf(filename2,"%s_00%d.bmp",argv[2],num);
       }
       else if (num<1000)
       { sprintf(filename1,"%s_0%d.bmp",argv[1],num);
         sprintf(filename2,"%s_0%d.bmp",argv[2],num);
       }
       else
       { sprintf(filename1,"%s_%d.bmp",argv[1],num);
         sprintf(filename2,"%s_%d.bmp",argv[2],num);
       }
   }
   else
   {   sprintf(filename1,"%s",argv[1],num);
       sprintf(filename2,"%s",argv[2],num);
   }

   if(cont==0)
   {
      if((fptri1=fopen(argv[1],"rb"))==NULL)
      { printf("  compare %s vs %s\n",argv[1],argv[2]);
        printf("      Error open input file1 %s\n\n",argv[1]);
        exit(0);}
      if((fptri2=fopen(argv[2],"rb"))==NULL)
      { printf("  compare %s vs %s\n",argv[1],argv[2]);
        printf("      Error open input file2 %s\n\n",argv[2]);
        exit(0);}
   }
   else
   {
      if((fptri1=fopen(filename1,"rb"))==NULL)
      {  if((fptri2=fopen(filename2,"rb"))!=NULL)
         {    printf("  compare %s vs %s\n",filename1,filename2);
              printf("      Error open input file1 : %s\n\n",filename1);
              exit(0) ;
         }
         else
         {   printf("\n");
             exit(0) ;
         }

      }

      if((fptri2=fopen(filename2,"rb"))==NULL)
      {  if((fptri1=fopen(filename1,"rb"))!=NULL)
         {    printf("  compare %s vs %s\n",filename1,filename2);
              printf("      Error open input file2 : %s\n\n",filename2);
              exit(0);
         }
         else
         {   printf("\n");
             exit(0) ;
         }
      }
   }


   fseek(fptri1,18,SEEK_SET);
   fread(&width1,sizeof(char),4,fptri1);
   fread(&height1,sizeof(char),4,fptri1);

   fseek(fptri2,18,SEEK_SET);
   fread(&width2,sizeof(char),4,fptri2);
   fread(&height2,sizeof(char),4,fptri2);


   if((width1!=width2) || (height1!=height2))
   { printf("Error : width or height error\n");
     exit(0);}

   printf("  compare %s vs %s\n",filename1,filename2);

   fseek(fptri1,54,SEEK_SET);
   fseek(fptri2,54,SEEK_SET);
   c1=0;
   c2=0;
   int r0, r1, g0, g1, b0, b1;
   int diffval_r, diffval_g, diffval_b;


   f_log   = fopen("all.log", "wb");
   char cmd[1025];
   char arr_diffval_r[]  ="diffval_r.rgb"  ;
   char arr_diffval_g[]  ="diffval_g.rgb"  ;
   char arr_diffval_b[]  ="diffval_b.rgb"  ;
// char arr_diffval_RGB[]="diffval_RGB.rgb";

   char arr_diffrat_r[]  ="diffrat_r.rgb"  ;
   char arr_diffrat_g[]  ="diffrat_g.rgb"  ;
   char arr_diffrat_b[]  ="diffrat_b.rgb"  ;
// char arr_diffrat_RGB[]="diffrat_RGB.rgb";

   f_diffval_r   = fopen(arr_diffval_r  ,"wb");
   f_diffval_g   = fopen(arr_diffval_g  ,"wb");
   f_diffval_b   = fopen(arr_diffval_b  ,"wb");
// f_diffval_RGB = fopen(arr_diffval_RGB,"wb");

   f_diffrat_r   = fopen(arr_diffrat_r  ,"wb");
   f_diffrat_g   = fopen(arr_diffrat_g  ,"wb");
   f_diffrat_b   = fopen(arr_diffrat_b  ,"wb");
// f_diffrat_RGB = fopen(arr_diffrat_RGB,"wb");

   int diffrat_r;
   int diffrat_g;
   int diffrat_b;

   for (h=0;h<height1;h++)
   {
       for (w=0;w<width1;w++)
       {
          fread(&c1,sizeof(char),3,fptri1);
          fread(&c2,sizeof(char),3,fptri2);
          r0 = (c1&0xFF0000)>>16;
          r1 = (c2&0xFF0000)>>16;

          g0 = (c1&0x00FF00)>>8;
          g1 = (c2&0x00FF00)>>8;

          b0 = (c1&0x0000FF)>>0;
          b1 = (c2&0x0000FF)>>0;

          diffval_r=abs(r0-r1);
          diffval_g=abs(g0-g1);
          diffval_b=abs(b0-b1);

          diffrat_r= (diffval_r==0 &&r0==0) ? 0                                     :
                     (diffval_r<=10&&r0==0) ? 10                                    :
                     (diffval_r> 10&&r0==0) ? (int)round(100*(float)diffval_r/1)    :
                                              (int)round(100*(float)diffval_r/r0)   ;

          diffrat_g= (diffval_g==0 &&g0==0) ? 0                                     :
                     (diffval_g<=10&&g0==0) ? 10                                    :
                     (diffval_g> 10&&g0==0) ? (int)round(100*(float)diffval_g/1)    :
                                              (int)round(100*(float)diffval_g/g0)   ;

          diffrat_b= (diffval_b==0 &&b0==0) ? 0                                     :
                     (diffval_b<=10&&b0==0) ? 10                                    :
                     (diffval_b> 10&&b0==0) ? (int)round(100*(float)diffval_b/1)    :
                                              (int)round(100*(float)diffval_b/b0)   ;

          if(c1!=c2)
          {
            fprintf(f_log, "(y,x)=%04d,%04d : %06x != %06x, diff_r/r0=%02d/%02d(% 3d%%), diff_g/g0=%02d/%02d(% 3d%%), diff_b/b0=%02d/%02d(% 3d%%)\n", height1-h-1, w, c1, c2,
                            diffval_r, r0, diffrat_r,
                            diffval_g, g0, diffrat_g,
                            diffval_b, b0, diffrat_b
                   );
//if(w==502 && height1-h-1==60)
//{
//printf("(y,x)=(%d,%d) : r0=%d, diffval_r=%d, diffrat_r=%d\n", height1-h-1, w, r0, diffval_r, diffrat_r);
//getchar();
//}
//          printf("Error : data compare error : %x vs %x (w=%d, h=%d)\n",c1,c2,w,height1-h-1);
//          err_cnt = err_cnt+1;
//          if(err_cnt==10)
//          { h = height1;
//            w = width1;
//          }
          }

int enhance_factor=16;


          int diffval_r_enh = enhance_factor*diffval_r;
          int diffval_g_enh = enhance_factor*diffval_g;
          int diffval_b_enh = enhance_factor*diffval_b;

          diffval_r_enh = diffval_r_enh>255 ? 255 : diffval_r_enh;
          diffval_g_enh = diffval_g_enh>255 ? 255 : diffval_g_enh;
          diffval_b_enh = diffval_b_enh>255 ? 255 : diffval_b_enh;

          if((h==height1-1) && (w==width1-1))
          {
             if(r0==r1)fprintf(f_diffval_r  , "000000"); else fprintf(f_diffval_r  , "%02x0000"     , diffval_r_enh);
             if(g0==g1)fprintf(f_diffval_g  , "000000"); else fprintf(f_diffval_g  , "00%02x00"     , diffval_g_enh);
             if(b0==b1)fprintf(f_diffval_b  , "000000"); else fprintf(f_diffval_b  , "0000%02x"     , diffval_b_enh);
//           if(c1==c2)fprintf(f_diffval_RGB, "000000"); else fprintf(f_diffval_RGB, "%02x%02x%02x" , diffval_r_enh, diffval_g_enh, diffval_b_enh);
          }
          else
          {
             if(r0==r1)fprintf(f_diffval_r  , "000000\n"); else fprintf(f_diffval_r  , "%02x0000\n"     , diffval_r_enh);
             if(g0==g1)fprintf(f_diffval_g  , "000000\n"); else fprintf(f_diffval_g  , "00%02x00\n"     , diffval_g_enh);
             if(b0==b1)fprintf(f_diffval_b  , "000000\n"); else fprintf(f_diffval_b  , "0000%02x\n"     , diffval_b_enh);
//           if(c1==c2)fprintf(f_diffval_RGB, "000000\n"); else fprintf(f_diffval_RGB, "%02x%02x%02x\n" , diffval_r_enh, diffval_g_enh, diffval_b_enh);
          }

          int diffrat_r_filt = r0<=5   && diffval_r<8 ? 0 :
                               r0<=10  && diffrat_r<50? 0 :
                               r0<=20  && diffrat_r<30? 0 :
                               r0<=30  && diffrat_r<10? 0 :
                               r0>=240 && diffrat_r<5 ? 0 : diffrat_r;


          int diffrat_g_filt = g0<=5   && diffval_g<8 ? 0 :
                               g0<=10  && diffrat_g<50? 0 :
                               g0<=20  && diffrat_g<30? 0 :
                               g0<=30  && diffrat_g<10? 0 :
                               g0>=240 && diffrat_g<5 ? 0 : diffrat_g;

          int diffrat_b_filt = b0<=5   && diffval_b<8 ? 0 :
                               b0<=10  && diffrat_b<50? 0 :
                               b0<=20  && diffrat_b<30? 0 :
                               b0<=30  && diffrat_b<10? 0 :
                               b0>=240 && diffrat_b<5 ? 0 : diffrat_b;
//if(w==502 && height1-h-1==60)
//{
//printf("(y,x)=(%d,%d) : r0=%d, diffval_r=%d, diffrat_r=%d, diffrat_r_filt=%d\n", height1-h-1, w, r0, diffval_r, diffrat_r, diffrat_r_filt);
//getchar();
//}


int renhance_factor=10;
          int diffrat_r_filt_enh = renhance_factor*diffrat_r_filt;
          int diffrat_g_filt_enh = renhance_factor*diffrat_g_filt;
          int diffrat_b_filt_enh = renhance_factor*diffrat_b_filt;

          diffrat_r_filt_enh = diffrat_r_filt_enh>255 ? 255 : diffrat_r_filt_enh;
          diffrat_g_filt_enh = diffrat_g_filt_enh>255 ? 255 : diffrat_g_filt_enh;
          diffrat_b_filt_enh = diffrat_b_filt_enh>255 ? 255 : diffrat_b_filt_enh;

          if((h==height1-1) && (w==width1-1))
          {
             if(r0==r1)fprintf(f_diffrat_r  , "000000"); else fprintf(f_diffrat_r  , "%02x0000"     , diffrat_r_filt_enh);
             if(g0==g1)fprintf(f_diffrat_g  , "000000"); else fprintf(f_diffrat_g  , "00%02x00"     , diffrat_g_filt_enh);
             if(b0==b1)fprintf(f_diffrat_b  , "000000"); else fprintf(f_diffrat_b  , "0000%02x"     , diffrat_b_filt_enh);
//           if(c1==c2)fprintf(f_diffrat_RGB, "000000"); else fprintf(f_diffrat_RGB, "%02x%02x%02x" , diffrat_r_filt_enh, diffrat_g_filt_enh, diffrat_b_filt_enh);
          }
          else
          {
             if(r0==r1)fprintf(f_diffrat_r  , "000000\n"); else fprintf(f_diffrat_r  , "%02x0000\n"     , diffrat_r_filt_enh);
             if(g0==g1)fprintf(f_diffrat_g  , "000000\n"); else fprintf(f_diffrat_g  , "00%02x00\n"     , diffrat_g_filt_enh);
             if(b0==b1)fprintf(f_diffrat_b  , "000000\n"); else fprintf(f_diffrat_b  , "0000%02x\n"     , diffrat_b_filt_enh);
//           if(c1==c2)fprintf(f_diffrat_RGB, "000000\n"); else fprintf(f_diffrat_RGB, "%02x%02x%02x\n" , diffrat_r_filt_enh, diffrat_g_filt_enh, diffrat_b_filt_enh);
          }





       }
   }

   fclose(f_log);
   fclose(f_diffval_r);
   fclose(f_diffval_g);
   fclose(f_diffval_b);
   fclose(f_diffrat_r);
   fclose(f_diffrat_g);
   fclose(f_diffrat_b);
// fclose(f_diffval_RGB);

   f_diffval_r   = fopen(arr_diffval_r  ,"rb");
   f_diffval_g   = fopen(arr_diffval_g  ,"rb");
   f_diffval_b   = fopen(arr_diffval_b  ,"rb");
   f_diffrat_r   = fopen(arr_diffrat_r  ,"rb");
   f_diffrat_g   = fopen(arr_diffrat_g  ,"rb");
   f_diffrat_b   = fopen(arr_diffrat_b  ,"rb");
// f_diffval_RGB = fopen(arr_diffval_RGB,"rb");

// line_reverse(f_diffval_r); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diffval_r);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diffval_r, arr_diffval_r, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diffval_r, arr_diffval_r, width1, height1);
#ifdef WIN32
   sprintf(cmd, "tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffval_r, arr_diffval_r, width1, height1); system(cmd);
   sprintf(cmd, "tool\\source_bmp2rgb\\bmp2rgb.exe         %s_0001.bmp %s", arr_diffval_r, arr_diffval_r                 ); system(cmd);
#else
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffval_r, arr_diffval_r, width1, height1); system(cmd);
   sprintf(cmd, "tool/source_bmp2rgb/bmp2rgb.exe         %s_0001.bmp %s", arr_diffval_r, arr_diffval_r                 ); system(cmd);
#endif

// line_reverse(f_diffval_g); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diffval_g);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diffval_g, arr_diffval_g, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diffval_g, arr_diffval_g, width1, height1);
#ifdef WIN32
   sprintf(cmd, "tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffval_g, arr_diffval_g, width1, height1); system(cmd);
   sprintf(cmd, "tool\\source_bmp2rgb\\bmp2rgb.exe         %s_0001.bmp %s", arr_diffval_g, arr_diffval_g                 ); system(cmd);
#else
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffval_g, arr_diffval_g, width1, height1); system(cmd);
   sprintf(cmd, "tool/source_bmp2rgb/bmp2rgb.exe         %s_0001.bmp %s", arr_diffval_g, arr_diffval_g                 ); system(cmd);
#endif

// line_reverse(f_diffval_b); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diffval_b);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diffval_b, arr_diffval_b, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diffval_b, arr_diffval_b, width1, height1);
#ifdef WIN32
   sprintf(cmd, "tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffval_b, arr_diffval_b, width1, height1); system(cmd);
   sprintf(cmd, "tool\\source_bmp2rgb\\bmp2rgb.exe         %s_0001.bmp %s", arr_diffval_b, arr_diffval_b                 ); system(cmd);
#else
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffval_b, arr_diffval_b, width1, height1); system(cmd);
   sprintf(cmd, "tool/source_bmp2rgb/bmp2rgb.exe         %s_0001.bmp %s", arr_diffval_b, arr_diffval_b                 ); system(cmd);
#endif

// line_reverse(f_diffrat_r); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diffrat_r);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diffrat_r, arr_diffrat_r, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diffrat_r, arr_diffrat_r, width1, height1);
#ifdef WIN32
   sprintf(cmd, "tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffrat_r, arr_diffrat_r, width1, height1); system(cmd);
   sprintf(cmd, "tool\\source_bmp2rgb\\bmp2rgb.exe         %s_0001.bmp %s", arr_diffrat_r, arr_diffrat_r                 ); system(cmd);
#else
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffrat_r, arr_diffrat_r, width1, height1); system(cmd);
   sprintf(cmd, "tool/source_bmp2rgb/bmp2rgb.exe         %s_0001.bmp %s", arr_diffrat_r, arr_diffrat_r                 ); system(cmd);
#endif

// line_reverse(f_diffrat_g); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diffrat_g);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diffrat_g, arr_diffrat_g, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diffrat_g, arr_diffrat_g, width1, height1);
#ifdef WIN32
   sprintf(cmd, "tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffrat_g, arr_diffrat_g, width1, height1); system(cmd);
   sprintf(cmd, "tool\\source_bmp2rgb\\bmp2rgb.exe         %s_0001.bmp %s", arr_diffrat_g, arr_diffrat_g                 ); system(cmd);
#else
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffrat_g, arr_diffrat_g, width1, height1); system(cmd);
   sprintf(cmd, "tool/source_bmp2rgb/bmp2rgb.exe         %s_0001.bmp %s", arr_diffrat_g, arr_diffrat_g                 ); system(cmd);
#endif

// line_reverse(f_diffrat_b); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diffrat_b);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diffrat_b, arr_diffrat_b, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diffrat_b, arr_diffrat_b, width1, height1);
#ifdef WIN32
   sprintf(cmd, "tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffrat_b, arr_diffrat_b, width1, height1); system(cmd);
   sprintf(cmd, "tool\\source_bmp2rgb\\bmp2rgb.exe         %s_0001.bmp %s", arr_diffrat_b, arr_diffrat_b                 ); system(cmd);
#else
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diffrat_b, arr_diffrat_b, width1, height1); system(cmd);
   sprintf(cmd, "tool/source_bmp2rgb/bmp2rgb.exe         %s_0001.bmp %s", arr_diffrat_b, arr_diffrat_b                 ); system(cmd);
#endif


   fclose(fptri1);
   fclose(fptri2);

   num++;
   }
}


int line_reverse(FILE *f_ori)
{

     long cnt;
     int  cnt_byte=0;
     char ch;
     char R_lsb, R_msb, G_lsb, G_msb, B_lsb, B_msb;
     FILE *f_tmp = fopen("line_reverse.txt", "w");
     cnt = count_characters(f_ori);

        /*
            Make the pointer fp1 to point at the
            last character of the file
        */
        fseek(f_ori, -1L, 2);
        printf("Number of characters to be copied %d\n", ftell(f_ori));

        while (cnt)
        {
                 if(cnt_byte==0) B_lsb = fgetc(f_ori);
            else if(cnt_byte==1) B_msb = fgetc(f_ori);
            else if(cnt_byte==2) G_lsb = fgetc(f_ori);
            else if(cnt_byte==3) G_msb = fgetc(f_ori);
            else if(cnt_byte==4) R_lsb = fgetc(f_ori);
            else if(cnt_byte==5) R_msb = fgetc(f_ori);
            else if(cnt_byte==6) ch    = fgetc(f_ori);

            if(cnt_byte==5) fprintf(f_tmp, "%c%c%c%c%c%c\n", R_msb, R_lsb, G_msb, G_lsb, B_msb, B_lsb);

            if(cnt_byte==6) cnt_byte=0; // when cnt_byte==6, it is new line symbol
            else            cnt_byte++;

            fseek(f_ori, -2L, 1); // shifts the pointer to the previous character
            cnt--;
        }

     printf("\n**File copied successfully in reverse order**\n");
     fclose(f_tmp);
}


int char_reverse(FILE *f_ori)
{

     long cnt;
     char ch;
     FILE *f_tmp = fopen("File_2.txt", "w");
     cnt = count_characters(f_ori);

        /*
            Make the pointer fp1 to point at the
            last character of the file
        */
        fseek(f_ori, -1L, 2);
        printf("Number of characters to be copied %d\n", ftell(f_ori));

        while (cnt)
        {
            ch = fgetc(f_ori);
            fputc(ch, f_tmp);
            fseek(f_ori, -2L, 1); // shifts the pointer to the previous character
            cnt--;
        }
        printf("\n**File copied successfully in reverse order**\n");
     fclose(f_tmp);
}


/*
    Count the total number of characters in the file
    that *f points to
*/
long count_characters(FILE *f)
{
    fseek(f, -1L, 2);
    /*
        returns the position of the
        last element of the file
    */
    long last_pos = ftell(f);
    last_pos++;
    return last_pos;
}
