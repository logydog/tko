#ifndef __DAZZO_DATA_TYPE_H__
#define __DAZZO_DATA_TYPE_H__

typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef unsigned long DWORD;

typedef unsigned char bool;
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;

typedef char int8;
typedef short int16;
typedef int int32;

typedef long long int64;
typedef unsigned long long uint64;

#endif
