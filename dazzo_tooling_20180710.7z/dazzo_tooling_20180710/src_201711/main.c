#include <math.h>
#include <time.h>
#include "main.h"

#ifdef WIN32
#include "daz_fmc\daz_fmc.h"
#else
#include "daz_fmc/daz_fmc.h"
#endif

char errortext[256];

SourceInfo SrcInfo;
TargetInfo TgtInfo;

int FrameWidth, FrameHeight;
void ReadBmpDimension(int nframe,FrameInfo *AFrame, int *frame_w, int *frame_h);

void error(char *text)
{
   fprintf(stderr,text);
   putc('\n',stderr);
   exit(1);
}

void readparmfile(char *fname)
{
	FILE *fd;
	char line[256];

	if (!(fd = fopen(fname,"r")))
      printf("Couldn't open parameter file %s",fname);

	fgets(line,254,fd);  sscanf(line,"%s",SrcInfo.FileName);


    strcpy(TgtInfo.FileName, SrcInfo.FileName);
    SrcInfo.InType = 2;
    TgtInfo.OutType = 2;
    SrcInfo.nframes = 1;
    SrcInfo.frame0 = 1;
    SrcInfo.DisplayMode = 3;

	if(SrcInfo.InType == T_BMP)
		SrcInfo.DisplayMode = CHROMA444;

	SrcInfo.Size_Y = SrcInfo.frame_w * SrcInfo.frame_h;
	SrcInfo.Size_UV = (SrcInfo.DisplayMode==CHROMA420)? (SrcInfo.Size_Y>>2) : \
		              (SrcInfo.DisplayMode==CHROMA422)? (SrcInfo.Size_Y>>1) : SrcInfo.Size_Y;

	TgtInfo.frame_w = SrcInfo.frame_w;
	TgtInfo.frame_h = SrcInfo.frame_h;

	TgtInfo.Size_Y = TgtInfo.frame_w * TgtInfo.frame_h;
	TgtInfo.Size_UV = TgtInfo.Size_Y;
}

static void print_usage(void)
{
	printf("Usage: daz_fmc config_filename\n");
	printf("Example: daz_fmc config.par\n");
}

void parsing_cmd(int argc, char *argv[])
{
    printf("\n***********************************************************\n");
    printf("  FMC_3X C-Model  (DAZZO Technology, Version: 17.1121.2x2)\n");
    printf("***********************************************************\n\n");

	if (argc == 1) {
		print_usage();
		exit(-1);
	}

	readparmfile(argv[1]);
}

int main(int argc, char *argv[])
{
	int i;
	int big_size ;
        char cmd[1025];

	FrameInfo InFrame, SrcFrame, FMCFramePrev;
    FrameInfo TmpFrame;

	char fmc_out_filename[60];

    parsing_cmd(argc, argv);

    int dump_algo_distribution = argc>=3;

	sprintf(fmc_out_filename, "%s_fmc", TgtInfo.FileName);

    ReadBmpDimension(0+SrcInfo.frame0, &TmpFrame, &FrameWidth, &FrameHeight);
    printf("W=%d, H=%d\n", FrameWidth, FrameHeight);
    SrcInfo.frame_w = FrameWidth;
    SrcInfo.frame_h = FrameHeight;

	if(SrcInfo.frame_w*SrcInfo.frame_h > TgtInfo.frame_w*TgtInfo.frame_h)
		big_size = SrcInfo.frame_w*SrcInfo.frame_h ;
	else
		big_size = TgtInfo.frame_w*TgtInfo.frame_h ;

	init_FrameInfo(&InFrame, SrcInfo.frame_w*SrcInfo.frame_h);
	init_FrameInfo(&SrcFrame, big_size);
	init_FrameInfo(&FMCFramePrev, big_size);

    daz_fmc_init(SrcInfo.frame_w, SrcInfo.frame_h);

    for(i=0;i<SrcInfo.nframes;i++)
    {
		ReadSourceFrame(i+SrcInfo.frame0, &InFrame);

		frame_copy(&SrcFrame, &InFrame);

        daz_fmc_frame_top(&FMCFramePrev, &SrcFrame, dump_algo_distribution);

	    int result = WriteTargetFrame(SrcInfo.frame0, i, fmc_out_filename, TgtInfo.OutType, &FMCFramePrev);

#ifdef WIN32
    if(dump_algo_distribution)
    {
       sprintf(cmd, "00_analysis\\tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe use_yuv.rgb use_yuv %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis\\tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe use_rgb.rgb use_rgb %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis\\tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe use_gra.rgb use_gra %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis\\tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe use_pat.rgb use_pat %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis\\tool\\source_rgb2bmp\\rgb2bmp_ud_cont.exe use_ich.rgb use_ich %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis\\tool\\NConvert-win\\nconvert.exe -out bmp -resize %d %d *.bmp"         , FrameWidth  , FrameHeight  ); system(cmd);
    }
#else
    if(dump_algo_distribution)
    {
       sprintf(cmd, "00_analysis/tool/source_rgb2bmp/rgb2bmp_ud_cont.exe use_yuv.rgb use_yuv %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis/tool/source_rgb2bmp/rgb2bmp_ud_cont.exe use_rgb.rgb use_rgb %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis/tool/source_rgb2bmp/rgb2bmp_ud_cont.exe use_gra.rgb use_gra %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis/tool/source_rgb2bmp/rgb2bmp_ud_cont.exe use_pat.rgb use_pat %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis/tool/source_rgb2bmp/rgb2bmp_ud_cont.exe use_ich.rgb use_ich %d %d UD", FrameWidth/2, FrameHeight/2); system(cmd);
       sprintf(cmd, "00_analysis\\tool\\NConvert-win\\nconvert.exe -out bmp -resize %d %d *.bmp"      , FrameWidth  , FrameHeight  ); system(cmd);
    }
#endif

	    if (result < 0)
	    {
	        printf("Frame %d: Failed\n", i);
	        break;
	    }
        printf("Frame %d: OK\n", i);
	}

    printf("Finished.\n");
	free_FrameInfo(&InFrame);
	free_FrameInfo(&SrcFrame);
	free_FrameInfo(&FMCFramePrev);

	return 0;
}
