#include "main.h"



void Write_y_u_v(int f0, int fcount, char *fname, int y_size, int uv_size, FrameInfo *AFrame)
{
	FILE *fd;
	char name[256],name_t[256];
	int nframe, i;
	unsigned char *pbTemp;


	pbTemp = (unsigned char*)malloc(y_size*sizeof(unsigned char));

	nframe = f0 + fcount;
	sprintf(name_t, fname , nframe);
	sprintf(name,"%s.Y", name_t);
	if (!(fd = fopen(name,"wb")))
	{
         sprintf(errortext,"Couldn't create %s\n",name);
         error(errortext);
	}

    for(i=0;i<y_size;i++)
    {
        *(pbTemp+i) = (unsigned char)(*(AFrame->y_data+i)>>PIXEL_BITS);
    }
    fwrite(pbTemp, sizeof(unsigned char), y_size, fd);
    fclose(fd);

    sprintf(name,"%s.U",name_t);
	if (!(fd = fopen(name,"wb")))
	{
         sprintf(errortext,"Couldn't create %s\n",name);
         error(errortext);
	}

    for(i=0;i<uv_size;i++)
    {
        *(pbTemp+i) = (unsigned char)(*(AFrame->u_data+i)>>PIXEL_BITS);
    }
    fwrite(pbTemp, sizeof(unsigned char), uv_size, fd);
    fclose(fd);

    sprintf(name,"%s.V",name_t);
	if (!(fd = fopen(name,"wb")))
	{
         sprintf(errortext,"Couldn't create %s\n",name);
         error(errortext);
	}
    for(i=0;i<uv_size;i++)
    {
        *(pbTemp+i) = (unsigned char)(*(AFrame->v_data+i)>>PIXEL_BITS);
    }
    fwrite(pbTemp, sizeof(unsigned char), uv_size, fd);

	printf( "write frame count = %d\n", nframe);
    free(pbTemp);
    fclose(fd);
}


void Write_yuv(int fcount, char *fname, int y_size, int uv_size, FrameInfo *AFrame)
{
	FILE *fd;
	char name[256],name_t[256];
    unsigned char *pbTemp;
	int i;


	pbTemp = (unsigned char*)malloc(y_size*sizeof(unsigned char));

	sprintf(name_t, fname);
	sprintf(name,"%s.YUV",name_t);

	if(fcount==0){
		if (!(fd = fopen(name,"wb"))){
			sprintf(errortext,"Couldn't create %s\n",name);
			error(errortext);
		}
	}
	else{
		if (!(fd = fopen(name,"ab"))){
			sprintf(errortext,"Couldn't create %s\n",name);
			error(errortext);
		}
	}

    for(i=0;i<y_size;i++)
    {
        *(pbTemp+i) = (unsigned char)(*(AFrame->y_data+i)>>PIXEL_BITS);
    }
    fwrite(pbTemp, sizeof(unsigned char), y_size, fd);
    for(i=0;i<uv_size;i++)
    {
        *(pbTemp+i) = (unsigned char)(*(AFrame->u_data+i)>>PIXEL_BITS);
    }
    fwrite(pbTemp, sizeof(unsigned char), uv_size, fd);
    for(i=0;i<uv_size;i++)
    {
        *(pbTemp+i) = (unsigned char)(*(AFrame->v_data+i)>>PIXEL_BITS);
    }
    fwrite(pbTemp, sizeof(unsigned char), uv_size, fd);


    free(pbTemp);
    fclose(fd);
}

void init_Bmp(BmpInfo *YUVBmp,FrameInfo *AFrame)
{

    int i;
    int width,height,size;
    int linesize,linecount,lineleft;
    int iY,iU,iV;

	YUVBmp->InfoHeader.biWidth=AFrame->frame_w;
	YUVBmp->InfoHeader.biHeight=AFrame->frame_h;

	linesize = ((YUVBmp->InfoHeader.biWidth*3)+3)>>2<<2;
	YUVBmp->InfoHeader.biSizeImage =linesize * YUVBmp->InfoHeader.biHeight;
	YUVBmp->data = (int *)malloc(YUVBmp->InfoHeader.biSizeImage * sizeof(int));

	if(YUVBmp->data == NULL)
	{
        sprintf(errortext,"Memory allocate error in %s",YUVBmp->FileName);
        exit(1);
    }


    YUVBmp->InfoHeader.biSize        =0x28;
	YUVBmp->InfoHeader.biPlanes      =1;
	YUVBmp->InfoHeader.biBitCount    =24;
	YUVBmp->InfoHeader.biCompression =0;
	YUVBmp->InfoHeader.biX           =0;
	YUVBmp->InfoHeader.biY           =0;
	YUVBmp->InfoHeader.biClrUsed     =0;
	YUVBmp->InfoHeader.biClrImportant=0;


	YUVBmp->FileHeader.bfType        =0x4d42;
    YUVBmp->FileHeader.bfReserved    =0;
	YUVBmp->FileHeader.bfOffBits     =0x36;
	YUVBmp->FileHeader.bfSize        =YUVBmp->InfoHeader.biSizeImage + YUVBmp->FileHeader.bfOffBits;



    width=YUVBmp->InfoHeader.biWidth;
    height=YUVBmp->InfoHeader.biHeight;
    linesize=((YUVBmp->InfoHeader.biWidth*3)+3)>>2<<2;
    size=width*height;


    for(i=0;i<size ;i++)
    {
        linecount=i/width;
        lineleft=i%width;

        if( (lineleft==433) && (linecount==125) )
        {
            //printf("aa\n");
        }

        iY = *(AFrame->y_data+i);
        iU = *(AFrame->u_data+i);
        iV = *(AFrame->v_data+i);


        *(YUVBmp->data+(height-1-linecount)*linesize+3*lineleft+2)= iY;
        *(YUVBmp->data+(height-1-linecount)*linesize+3*lineleft+1)= iU;
        *(YUVBmp->data+(height-1-linecount)*linesize+3*lineleft+0)= iV;
    }
}

void close_Bmp(BmpInfo *Bmpfile)
{

	if (Bmpfile->data!=NULL)
	    free(Bmpfile->data);

}



int Write_bmp(int f0, int fcount, char *fname, BmpInfo *Bmp)
{
	FILE    *stream;
	char    name[256], name_t[256];
	int     nframe;
    int i, iBmpDataSize;
	unsigned char *pbTemp;

    int result = 0;

	nframe = f0 + fcount;
	sprintf(name_t, fname , nframe);
	sprintf(name,"%s.bmp",name_t);
	if (!(stream = fopen(name,"wb")))
	{
         sprintf(errortext,"Couldn't create %s\n",name);
         error(errortext);
	}

    iBmpDataSize = Bmp->FileHeader.bfSize-Bmp->FileHeader.bfOffBits;

	fwrite(&(Bmp->FileHeader.bfType) ,2,1,stream);
	fwrite(&(Bmp->FileHeader.bfSize) ,4,1,stream);
	fwrite(&(Bmp->FileHeader.bfReserved) ,4,1,stream);
	fwrite(&(Bmp->FileHeader.bfOffBits) ,4,1,stream);

	fwrite(&(Bmp->InfoHeader) ,sizeof(tagBmpInfoHeader),1,stream);

	pbTemp = (unsigned char*)malloc(iBmpDataSize*sizeof(unsigned char));
	for(i=0;i<iBmpDataSize;i++)
	{
	    *(pbTemp+i) = (unsigned char) (*(Bmp->data+i)>>PIXEL_BITS);
	}
	int written_size = fwrite(pbTemp, iBmpDataSize, 1, stream);
	if (written_size != 1) {
	    result = -1;
	}

	free(pbTemp);
    fclose(stream);
    return result;
}

int WriteTargetFrame(int f0, int fcount, char *fname, unsigned int Otype, FrameInfo *AFrame )
{
    int y_w, y_h, uv_w, uv_h;
    BmpInfo Bmp;

    y_w = AFrame->frame_w;
    y_h = AFrame->frame_h;
    uv_w = (AFrame->DisplayMode==CHROMA420 || AFrame->DisplayMode==CHROMA422)? \
    	   (y_w>>1): y_w;
    uv_h = (AFrame->DisplayMode==CHROMA420)? (y_h>>1): y_h;

    int result = 0;

    switch (Otype)
    {
        case T_Y_U_V:
            Write_y_u_v(f0, fcount, fname, y_w*y_h, uv_w*uv_h, AFrame);
            break;
        case T_YUV:
            Write_yuv(fcount, fname, y_w*y_h, uv_w*uv_h, AFrame);
            break;
        case T_BMP:
            init_Bmp(&Bmp, AFrame);
            result = Write_bmp(f0, fcount, fname, &Bmp);
            close_Bmp(&Bmp);
            break;
	}

    return result;
}







