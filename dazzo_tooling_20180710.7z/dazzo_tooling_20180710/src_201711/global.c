#include "main.h"


void * zero_malloc(size_t size)
{
   void * ptr = malloc(size);
   return ptr;
}

int init_FrameInfo(FrameInfo *fi, int fsize)
{

	fi->frame_w = 0;
	fi->frame_h = 0;
	fi->DisplayMode = 0;

	fi->y_data = (int *)zero_malloc(fsize * sizeof(int));
	fi->u_data = (int *)zero_malloc(fsize * sizeof(int));
	fi->v_data = (int *)zero_malloc(fsize * sizeof(int));

	if(fi->y_data == NULL || fi->u_data == NULL || fi->v_data == NULL) {
		if(fi->y_data) free(fi->y_data);
		if(fi->u_data) free(fi->u_data);
		if(fi->v_data) free(fi->v_data);
		return -1;
	}

	return 0;
}

void free_FrameInfo(FrameInfo * fi)
{
	free(fi->y_data);
	free(fi->u_data);
	free(fi->v_data);
}

void frame_copy(FrameInfo *Dst, FrameInfo *Src)
{
	int Y_CpSize, UV_CpSize;

	Dst->frame_w = Src->frame_w;
	Dst->frame_h = Src->frame_h;
	Dst->DisplayMode = Src->DisplayMode;

	Y_CpSize = Src->frame_w * Src->frame_h;
	UV_CpSize = (Src->DisplayMode==CHROMA420)? (Y_CpSize>>2) : \
		         (Src->DisplayMode==CHROMA422)? (Y_CpSize>>1) : Y_CpSize;

	memcpy(Dst->y_data, Src->y_data, Y_CpSize*sizeof(int));
	memcpy(Dst->u_data, Src->u_data, UV_CpSize*sizeof(int));
	memcpy(Dst->v_data, Src->v_data, UV_CpSize*sizeof(int));

}

