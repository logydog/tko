#ifndef __DAZ_FMC_CODEC_H__
#define __DAZ_FMC_CODEC_H__

#include "data_type.h"
#include "main.h"
#include "../main.h"
#include "const_def.h"
#include "fmc_csc.h"
#include "fmc_global_var.h"
#include "block_io.h"
#include "basic_func.h"
#include "fmc_enc_prep.h"
#include "fmc_enc_yuv.h"
#include "fmc_enc_rgb.h"
#include "fmc_enc_gray.h"
#include "fmc_enc_pat.h"
#include "fmc_enc_ich.h"
#include "fmc_dec.h"
#include "dbg_func.h"

//uint8 fmc_enc_top(bool slice_start);
  uint8 fmc_enc_top(bool slice_start, FILE *f_use_yuv, FILE *f_use_rgb, FILE *f_use_gra, FILE *f_use_pat, FILE *f_use_ich, int x, int y, int pix_cnt, int dump_algo_distribution);
void daz_fmc_init(int src_frame_w, int src_frame_h);
void daz_fmc_frame_top(FrameInfo *TgtFrame, FrameInfo *SrcFrame, int dump_algo_distribution);

typedef struct _fmc_enc_bs_yuv2_
{
    uint32 hdr: 3;
    uint32 bp2: 3;
    uint32 y0:  6;
    uint32 y1:  6;
    uint32 cb:  7;
    uint32 cr:  7;
}
fmc_enc_bs_yuv2;

typedef struct _fmc_enc_bs_yuv3_
{
    uint32 hdr: 3;
    uint32 bp3_1bit: 1;
    uint32 bp3_y2: 6;
    uint32 y0:  5;
    uint32 y1:  5;
    uint32 cb:  6;
    uint32 cr:  6;
}
fmc_enc_bs_yuv3;

typedef struct _fmc_enc_bs_yuv4_
{
    uint32 hdr: 3;
    uint32 y0:  4;
    uint32 y1:  4;
    uint32 y2:  4;
    uint32 y3:  4;
    uint32 cb:  6;
    uint32 cr:  7;
}
fmc_enc_bs_yuv4;

typedef struct _fmc_enc_bs_rgb1_
{
    uint32 hdr: 8;
    uint32 r:   8;
    uint32 g:   8;
    uint32 b:   8;
}
fmc_enc_bs_rgb1;

typedef struct _fmc_enc_bs_rgb2_
{
    uint32 hdr: 5;
    uint32 bp2: 3;
    uint32 r0:  4;
    uint32 r1:  4;
    uint32 g0:  4;
    uint32 g1:  4;
    uint32 b0:  4;
    uint32 b1:  4;
}
fmc_enc_bs_rgb2;

typedef struct _fmc_enc_bs_rgb3_
{
    uint32 hdr: 3;
    uint32 bp3_1bit: 1;
    uint32 bp3_b2: 4;
    uint32 r0:  3;
    uint32 r1:  3;
    uint32 r2:  3;
    uint32 g0:  3;
    uint32 g1:  3;
    uint32 g2:  3;
    uint32 b0:  3;
    uint32 b1:  3;
}
fmc_enc_bs_rgb3;

typedef struct _fmc_enc_bs_rgb4_
{
    uint32 hdr: 5;
    uint32 qmode: 3;
    uint32 r0:  2;
    uint32 r1:  2;
    uint32 r2:  2;
    uint32 r3:  2;
    uint32 g0:  2;
    uint32 g1:  2;
    uint32 g2:  2;
    uint32 g3:  2;
    uint32 b0:  2;
    uint32 b1:  2;
    uint32 b2:  2;
    uint32 b3:  2;
}
fmc_enc_bs_rgb4;

typedef struct _fmc_enc_bs_gray3_
{
    uint32 hdr: 5;
    uint32 bp3: 3;
    uint32 v0:  8;
    uint32 v1:  8;
    uint32 v2:  8;
}
fmc_enc_bs_gray3;

typedef struct _fmc_enc_bs_gray4_
{
    uint32 hdr: 3;
    uint32 quant: 1;
    uint32 data: 28;
}
fmc_enc_bs_gray4;


typedef struct _fmc_enc_bs_ich_
{
    uint32 hdr: 4;
    uint32 idx: 2;
    uint32 mode: 2;

    uint32 r0:  2;
    uint32 r1:  2;
    uint32 r2:  2;
    uint32 r3:  2;
    uint32 g0:  2;
    uint32 g1:  2;
    uint32 g2:  2;
    uint32 g3:  2;
    uint32 b0:  2;
    uint32 b1:  2;
    uint32 b2:  2;
    uint32 b3:  2;
}
fmc_enc_bs_ich;

typedef struct _fmc_enc_bs_pat0_2kc_2v_
{
    uint32 hdr: 8;
    uint32 v0:  8;
    uint32 v1:  8;
    uint32 kc0: 2;
    uint32 kc1: 3;
    uint32 p0:  1;
    uint32 p1:  1;
    uint32 p2:  1;
}
fmc_enc_bs_pat0_2kc_2v;

typedef struct _fmc_enc_bs_pat1_ab_c_
{
    uint32 hdr:      3;
    uint32 ab_sel:   3;
    uint32 c_sel:    1;
    uint32 data_1v:  8;
    uint32 quant_4v: 1;
    uint32 data_4v:  16;
}
fmc_enc_bs_pat1_ab_c;

typedef struct _fmc_enc_bs_pat2_2kc_gr_col_
{
    uint32 hdr: 6;
    uint32 bp2: 3;
    uint32 p3_gray: 1;
    uint32 gray: 7;
    uint32 r:   5;
    uint32 g:   5;
    uint32 b:   5;
}
fmc_enc_bs_pat2_2kc_gr_col;

typedef struct _fmc_enc_bs_pat3_pzc1_
{
    uint32 hdr: 8;
    uint32 ch4v_sel: 2;
    uint32 data_1v: 1;
    uint32 quant_4v: 1;
    uint32 data_4v: 20;
}
fmc_enc_bs_pat3_pzc1;

typedef struct _fmc_enc_bs_pat4_pzc2_
{
    uint32 hdr: 8;
    uint32 ch4v_sel: 2;
    uint32 data_1v: 6;
    uint32 v0: 4;
    uint32 v1: 4;
    uint32 v2: 4;
    uint32 v3: 4;
}
fmc_enc_bs_pat4_pzc2;

typedef struct _fmc_enc_bs_pat5_pzc_rcbc_
{
#ifdef DAZ_ICH_MODE_EN
    uint32 hdr: 4;
    uint32 bc_sel: 1;
    uint32 bp3_1bit: 1;
    uint32 bp3_rb0: 5;
    uint32 g0: 5;
    uint32 g1: 5;
    uint32 g2: 5;
    uint32 rb1: 3;
    uint32 rb2: 3;
#else
    uint32 hdr: 3;
    uint32 bc_sel: 1;
    uint32 bp3_1bit: 1;
    uint32 bp3_rb0: 5;
    uint32 g0: 6;
    uint32 g1: 5;
    uint32 g2: 5;
    uint32 rb1: 3;
    uint32 rb2: 3;
#endif
}
fmc_enc_bs_pat5_pzc_rcbc;

union fmc_enc_bs
{
    fmc_enc_bs_yuv2 yuv2;
    fmc_enc_bs_yuv3 yuv3;
    fmc_enc_bs_yuv4 yuv4;

    fmc_enc_bs_rgb1 rgb1;
    fmc_enc_bs_rgb2 rgb2;
    fmc_enc_bs_rgb3 rgb3;
    fmc_enc_bs_rgb4 rgb4;

    fmc_enc_bs_gray3 gray3;
    fmc_enc_bs_gray4 gray4;

    fmc_enc_bs_ich ich;

    fmc_enc_bs_pat0_2kc_2v pat0;
    fmc_enc_bs_pat1_ab_c pat1;
    fmc_enc_bs_pat2_2kc_gr_col pat2;
    fmc_enc_bs_pat3_pzc1 pat3;
    fmc_enc_bs_pat4_pzc2 pat4;
    fmc_enc_bs_pat5_pzc_rcbc pat5;

    uint8 bs_byte[4];
};

#endif
