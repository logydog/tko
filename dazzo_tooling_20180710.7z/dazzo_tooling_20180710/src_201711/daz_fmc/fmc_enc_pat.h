#ifndef __DAZ_FMC_ENC_PAT_H__
#define __DAZ_FMC_ENC_PAT_H__

#include "data_type.h"
#include "main.h"

uint8 fmc_pat_enc_dec_top(int *diff_sum);

void fmc_enc_pat0_2kc_2v(int *diff_sum);
uint8 fmc_enc_pat1_core(uint8 ch4v_min, uint8 ch4v_range, uint8 *ch4v_in, uint8* enc_4v, uint8 *rnb);
void fmc_enc_pat1_ch_ab_c(int *diff_sum);
void fmc_enc_pat2_2kc_gray_color(int *diff_sum);
void fmc_enc_pat3_pzc1(int *diff_sum);
void fmc_enc_pat4_pzc2(int *diff_sum);
void fmc_enc_pat5_pzc_rcbc(int *diff_sum);

void fmc_dec_pat0_2kc_2v(uint8 enc_v0, uint8 enc_v1, uint8 enc_kc0, uint8 enc_kc1, uint8 *enc_px_sel, uint8 *dec_r, uint8 *dec_g, uint8 *dec_b);

void fmc_dec_pat1_core(uint8 enc_1v, uint8 *enc_4v, uint8 enc_4v_min, uint8 enc_4v_quant,
    uint8 enc_c_sel, uint8 *dec_1v, uint8 *dec_4v, uint8 *dec_c, uint8 *rnb);
void fmc_dec_pat1_ch_ab_c(uint8 enc_ab_sel, uint8 enc_c_sel, uint8 enc_1v, uint8 enc_4v_quant, uint8 enc_4v_min, uint8 *enc_4v,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);

void fmc_dec_pat2_2kc_gray_color(uint8 idx, uint8 enc_px3_gray, uint8 enc_gray, uint8 *enc_color,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);

void fmc_dec_pat3_pzc1(uint8 enc_ch4v_sel, uint8 enc_1v, uint8 enc_4v_quant, uint8 enc_4v_min, uint8 *enc_4v,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);

void fmc_dec_pat4_pzc2(uint8 enc_ch4v_sel, uint8 enc_1v, uint8 *enc_4v,
    uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);

void fmc_dec_pat5_pzc_rcbc(uint8 enc_bc, uint8 enc_idx, uint8 *enc_g, uint8 *enc_rb,
        uint8 *dec_r, uint8 *dec_g, uint8 *dec_b, uint8 *rnb);


#endif
