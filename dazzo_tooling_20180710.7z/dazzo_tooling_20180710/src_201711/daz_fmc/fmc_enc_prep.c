/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

uint8 fmc_enc_3kc_get_idx(uint8 *Vin)
{
    uint8 diff[6];
    diff[0] = get_abs_diff(Vin[0], Vin[1]);
    diff[1] = get_abs_diff(Vin[0], Vin[2]);
    diff[2] = get_abs_diff(Vin[0], Vin[3]);
    diff[3] = get_abs_diff(Vin[1], Vin[2]);
    diff[4] = get_abs_diff(Vin[1], Vin[3]);
    diff[5] = get_abs_diff(Vin[2], Vin[3]);
    uint8 idx = get_min_idx_u8(6, diff);
    return idx;
}

uint8 fmc_enc_2kc_get_bplane(uint8 *Vin, uint8 Vthr)
{
    int i;
    uint8 bplane[4];
    for(i=0; i<BLK_SIZE; i++)
        bplane[i] = (Vin[i] > Vthr) ? 1 : 0;

    if(bplane[3])
    {
        for(i=0; i<4; i++)
            bplane[i] = bplane[i] ? 0 : 1;
    }

    if(bplane[0] == 0 && bplane[1] == 0 && bplane[2] == 0 && bplane[3] == 0)
    {
        bplane[0] = 1;
        bplane[1] = 1;
    }

    uint8 bp2_idx = 0;
    for(i=0; i<3; i++)
        bp2_idx |= (bplane[i] << i);


#ifdef RAYDIUM_EN_M6
    uint8 ray_m6_df1[4];
    uint8 ray_m6_equ[4];
    uint8 vthr_dfst1;
    for(i=0; i<4; i++)
    {
        ray_m6_df1[i] = (Vthr > Vin[i]) ? (Vthr == (Vin[i]+1)) : (Vin[i] == (Vthr+1));
        ray_m6_equ[i] = (Vthr == Vin[i]);
    }
    vthr_dfst1 = (ray_m6_df1[0] || ray_m6_equ[0]) &&
                    (ray_m6_df1[1] || ray_m6_equ[1]) &&
                    (ray_m6_df1[2] || ray_m6_equ[2]) &&
                    (ray_m6_df1[3] || ray_m6_equ[3]);
    if(vthr_dfst1)
        bp2_idx = 3;
#endif

    return bp2_idx;
}

void fmc_enc_2kc_get_color(uint8 *Vin, uint8 idx, uint8 *Vkc)
{
    switch(idx)
    {
        case 1:
            Vkc[0] = get_mean3(Vin[1], Vin[2], Vin[3]);
            Vkc[1] = Vin[0];
            break;
        case 2:
            Vkc[0] = get_mean3(Vin[0], Vin[2], Vin[3]);
            Vkc[1] = Vin[1];
            break;
        case 3:
            Vkc[0] = get_mean2(Vin[2], Vin[3]);
            Vkc[1] = get_mean2(Vin[0], Vin[1]);
            break;
        case 4:
            Vkc[0] = get_mean3(Vin[0], Vin[1], Vin[3]);
            Vkc[1] = Vin[2];
            break;
        case 5:
            Vkc[0] = get_mean2(Vin[1], Vin[3]);
            Vkc[1] = get_mean2(Vin[0], Vin[2]);
            break;
        case 6:
            Vkc[0] = get_mean2(Vin[0], Vin[3]);
            Vkc[1] = get_mean2(Vin[1], Vin[2]);
            break;
        default:
            Vkc[0] = Vin[3];
            Vkc[1] = get_mean3(Vin[0], Vin[1], Vin[2]);
            break;
    }
}

void fmc_enc_3kc(uint8 idx, uint8 *Vin, uint8 *Venc, uint8 *rnb)
{
    uint8 v_mean[6];
    v_mean[0] = get_mean2(Vin[0], Vin[1]);
    v_mean[1] = get_mean2(Vin[0], Vin[2]);
    v_mean[2] = get_mean2(Vin[0], Vin[3]);
    v_mean[3] = get_mean2(Vin[1], Vin[2]);
    v_mean[4] = get_mean2(Vin[1], Vin[3]);
    v_mean[5] = get_mean2(Vin[2], Vin[3]);

    uint8 map[6][2] =
    {
        {2,3},
        {1,3},
        {1,2},
        {0,3},
        {0,2},
        {0,1}
    };

    Venc[0] = v_mean[idx];
    Venc[1] = Vin[map[idx][0]];
    Venc[2] = Vin[map[idx][1]];

    int i;
    for(i=0; i<3; i++)
        Venc[i] = round_q(Venc[i], rnb[i]);
}

void fmc_dec_3kc(uint8 idx, uint8 *Venc, uint8 *Vdec, uint8 *rnb)
{
    int i;
    uint8 venc_dq[3];

    for(i=0; i<3; i++)
        venc_dq[i] = round_dq(Venc[i], rnb[i]);

    uint8 map[6][4] =
    {
        {0,0,1,2},
        {0,1,0,2},
        {0,1,2,0},
        {1,0,0,2},
        {1,0,2,0},
        {1,2,0,0}
    };
    for(i=0; i<4; i++)
        Vdec[i] = venc_dq[map[idx][i]];
}

void fmc_enc_prepare(void)
{
    int i;

    
    R_mean = get_mean4(Rin2x2);
    G_mean = get_mean4(Gin2x2);
    B_mean = get_mean4(Bin2x2);

    R_min = get_min(BLK_SIZE, Rin2x2);
    G_min = get_min(BLK_SIZE, Gin2x2);
    B_min = get_min(BLK_SIZE, Bin2x2);

    R_max = get_max(BLK_SIZE, Rin2x2);
    G_max = get_max(BLK_SIZE, Gin2x2);
    B_max = get_max(BLK_SIZE, Bin2x2);

    R_range = R_max - R_min;
    G_range = G_max - G_min;
    B_range = B_max - B_min;

//  printf("A. Rinx2x2[0,1,2,3]=%d, %d, %d, %d, R_mean=%d, R_min=%d, R_max=%d, R_range=%d\n", Rin2x2[0], Rin2x2[1], Rin2x2[2], Rin2x2[3], R_mean, R_min, R_max, R_range);
//  printf("A. Ginx2x2[0,1,2,3]=%d, %d, %d, %d, G_mean=%d, G_min=%d, G_max=%d, G_range=%d\n", Gin2x2[0], Gin2x2[1], Gin2x2[2], Gin2x2[3], G_mean, G_min, G_max, G_range);
//  printf("A. Binx2x2[0,1,2,3]=%d, %d, %d, %d, B_mean=%d, B_min=%d, B_max=%d, B_range=%d\n", Bin2x2[0], Bin2x2[1], Bin2x2[2], Bin2x2[3], B_mean, B_min, B_max, B_range);

    uint8 range[3] = {R_range, G_range, B_range};
    CH_most_smooth = get_min_idx_u8(3, range);
    CH_most_sharp = get_max_idx_u8(3, range);

//  printf("A. CH_most_smooth=%d\n", CH_most_smooth);
//  printf("A. CH_most_sharp =%d\n", CH_most_sharp );

    for(i=0; i<4; i++)
        GRAYin2x2[i] = get_mean3(Rin2x2[i], Gin2x2[i], Bin2x2[i]);

//  printf("A. GRAYin2x2[p0]=%d\n", GRAYin2x2[0]);
//  printf("A. GRAYin2x2[p1]=%d\n", GRAYin2x2[1]);
//  printf("A. GRAYin2x2[p2]=%d\n", GRAYin2x2[2]);
//  printf("A. GRAYin2x2[p3]=%d\n", GRAYin2x2[3]);

    Gray_min = get_min(BLK_SIZE, GRAYin2x2);
    Gray_max = get_max(BLK_SIZE, GRAYin2x2);
    Gray_range = Gray_max - Gray_min;

//  printf("A. GRAY_min=%d\n"  , Gray_min  );
//  printf("A. GRAY_max=%d\n"  , Gray_max  );
//  printf("A. GRAY_range=%d\n", Gray_range);

    uint8 Vmax[3] = {R_max, G_max, B_max};
    uint8 Vmin[3] = {R_min, G_min, B_min};
    RGB_max = get_max(3, Vmax);
    RGB_min = get_min(3, Vmin);

//  printf("A. RGB_max =%d\n", Gray_max  );
//  printf("A. RGB_min =%d\n", Gray_range);

    pzc_bc = chk_pzc_bc_en && (G_range<96) && (B_range==255) && (R_range==0) && (R_mean==128);
    pzc_rc = chk_pzc_rc_en && (G_range<192) && (R_range==255) && (B_range==0) && (B_mean==128);

    rgb2ycbcr(BLK_SIZE, Rin2x2, Gin2x2, Bin2x2, Yin2x2, CBin2x2, CRin2x2);
    Y_mean = get_mean4(Yin2x2);
    CB_mean = get_mean4(CBin2x2);
    CR_mean = get_mean4(CRin2x2);

//  printf("A. Y_mean  =%d\n", Y_mean  );
//  printf("A. CB_mean =%d\n", CB_mean );
//  printf("A. CR_mean =%d\n", CR_mean );

    enc_Ybp3_idx = fmc_enc_3kc_get_idx(Yin2x2);

    enc_Ybp2_idx = fmc_enc_2kc_get_bplane(Yin2x2, Y_mean);

//  printf("A. enc_Ybp3_idx =%d\n", enc_Ybp3_idx);
//  printf("A. enc_Ybp2_idx =%d\n", enc_Ybp2_idx);


    for(i=0; i<4; i++)
        Ybp2x2[i] = ((enc_Ybp2_idx >> i) & 1);

    Rbp3_idx = fmc_enc_3kc_get_idx(Rin2x2);
    Gbp3_idx = fmc_enc_3kc_get_idx(Gin2x2);
    Bbp3_idx = fmc_enc_3kc_get_idx(Bin2x2);
}
