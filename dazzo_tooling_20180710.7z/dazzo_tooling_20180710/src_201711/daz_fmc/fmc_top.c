/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"
#include "time.h"

const uint8 blk_w = 2;
const uint8 blk_h = 2;

static int fmc_frm_cnt;
int frame_w;
int frame_h;
int frame_blk_w;
int frame_blk_h;
int frame_blk_cnt;

  uint8 fmc_enc_top(bool slice_start, FILE *f_use_yuv, FILE *f_use_rgb, FILE *f_use_gra, FILE *f_use_pat, FILE *f_use_ich, int x, int y, int pix_cnt, int dump_algo_distribution)
//uint8 fmc_enc_top(bool slice_start                                                                                     )
{
    uint8 fmc_enc_mode = FMC_ENC_MODE_INVALID;

    const uint8 mode_cnt = 5;
    int diff_sum[mode_cnt];

    fmc_enc_prepare();

#ifdef RAYDIUM_EN_M4
	#define ENC_TMP_IDX_YUV (2)
	#define ENC_TMP_IDX_RGB (3)
	#define ENC_TMP_IDX_GRA (4)
	#define ENC_TMP_IDX_PAT (1)
	#define ENC_TMP_IDX_ICH (0)
#else
	#define ENC_TMP_IDX_YUV (0)
	#define ENC_TMP_IDX_RGB (1)
	#define ENC_TMP_IDX_GRA (2)
	#define ENC_TMP_IDX_PAT (3)
	#define ENC_TMP_IDX_ICH (4)
#endif

    uint8 yuv_enc_mode = fmc_yuv_enc_dec_top(diff_sum + ENC_TMP_IDX_YUV);
    uint8 rgb_enc_mode = fmc_rgb_enc_dec_top(diff_sum + ENC_TMP_IDX_RGB);
    uint8 gray_enc_mode = fmc_gray_enc_dec_top(diff_sum + ENC_TMP_IDX_GRA);
    uint8 pat_enc_mode = fmc_pat_enc_dec_top(diff_sum + ENC_TMP_IDX_PAT);
    uint8 ich_enc_mode = fmc_ich_enc_dec_top(slice_start, diff_sum + ENC_TMP_IDX_ICH);

//  printf("B. yuv_enc_mode  =%d\n", yuv_enc_mode );
//  printf("B. rgb_enc_mode  =%d\n", rgb_enc_mode );
//  printf("B. gray_enc_mode =%d\n", gray_enc_mode);
//  printf("B. pat_enc_mode  =%d\n", pat_enc_mode );
//  printf("B. ich_enc_mode  =%d\n", ich_enc_mode );

#ifndef DAZ_ICH_MODE_EN
	diff_sum[ENC_TMP_IDX_ICH] = 0xffffff;
#endif

///*cyk*/if( (0x30+diff_sum[ENC_TMP_IDX_RGB]*140/100)>diff_sum[ENC_TMP_IDX_YUV] ){if((pix_cnt%9)>=7)   diff_sum[ENC_TMP_IDX_RGB]=0xffffff;} // to forbid RGB mode
///*cyk*/if( (0x30+diff_sum[ENC_TMP_IDX_RGB]*150/100)>diff_sum[ENC_TMP_IDX_YUV] ){                     diff_sum[ENC_TMP_IDX_RGB]=0xffffff;} // to forbid RGB mode
///*cyk*/if( (0x30+diff_sum[ENC_TMP_IDX_RGB]*120/100)>diff_sum[ENC_TMP_IDX_YUV] ){                     diff_sum[ENC_TMP_IDX_RGB]=0xffffff;} // to forbid RGB mode

  /*cyk*/if( (0x10+diff_sum[ENC_TMP_IDX_RGB]*110/100)>diff_sum[ENC_TMP_IDX_YUV] ){if( (x&0x2)^(y&0x2) ) diff_sum[ENC_TMP_IDX_RGB]=0xffffff;} // to forbid RGB mode
///*cyk*/if( (0x10+diff_sum[ENC_TMP_IDX_RGB]*110/100)>diff_sum[ENC_TMP_IDX_YUV] ){                      diff_sum[ENC_TMP_IDX_RGB]=0xffffff;} // to forbid RGB mode
///*cyk*/if( (0x10+diff_sum[ENC_TMP_IDX_RGB]*110/100)>diff_sum[ENC_TMP_IDX_YUV] ){if((pix_cnt&0x3)==0)  diff_sum[ENC_TMP_IDX_RGB]=0xffffff;} // to forbid RGB mode

///*cyk*/diff_sum[ENC_TMP_IDX_RGB]=0xffffff; // to forbid RGB mode
///*cyk*/diff_sum[ENC_TMP_IDX_RGB] = 0x80 + diff_sum[ENC_TMP_IDX_RGB]*11/10; // to forbid RGB mode
///*cyk*/diff_sum[ENC_TMP_IDX_RGB] =  (pix_cnt&0x3)==0 ? 0xffffff : 0x10 + diff_sum[ENC_TMP_IDX_RGB]*110/100; // to forbid RGB mode




///*cyk*/printf("diff_sum[ENC_TMP_IDX_RGB]=0x%06x\n", diff_sum[ENC_TMP_IDX_RGB]);
///*cyk*/getchar();

    uint8 min_diff_idx = get_min_idx_i32(mode_cnt, diff_sum);
//  printf("B. diff_sum[yuv_enc_mode (==%d)] =%d\n", ENC_TMP_IDX_YUV, diff_sum[ENC_TMP_IDX_YUV]);
//  printf("B. diff_sum[rgb_enc_mode (==%d)] =%d\n", ENC_TMP_IDX_RGB, diff_sum[ENC_TMP_IDX_RGB]);
//  printf("B. diff_sum[gray_enc_mode(==%d)] =%d\n", ENC_TMP_IDX_GRA, diff_sum[ENC_TMP_IDX_GRA]);
//  printf("B. diff_sum[pat_enc_mode (==%d)] =%d\n", ENC_TMP_IDX_PAT, diff_sum[ENC_TMP_IDX_PAT]);
//  printf("B. diff_sum[ich_enc_mode (==%d)] =%d\n", ENC_TMP_IDX_ICH, diff_sum[ENC_TMP_IDX_ICH]);
//  printf("B. min_diff_idx =%d\n", min_diff_idx);

    switch(min_diff_idx)
    {
        case ENC_TMP_IDX_YUV:
            fmc_enc_mode = yuv_enc_mode;
            if(dump_algo_distribution)
            {
  /*fuck*/    fprintf(f_use_yuv, "FFFFFF\n" );
  /*fuck*/    fprintf(f_use_rgb, "000000\n" );
  /*fuck*/    fprintf(f_use_gra, "000000\n" );
  /*fuck*/    fprintf(f_use_pat, "000000\n" );
  /*fuck*/    fprintf(f_use_ich, "000000\n" );
            }
            copy_block(4, pdec_R, pdec_yuv_R);
            copy_block(4, pdec_G, pdec_yuv_G);
            copy_block(4, pdec_B, pdec_yuv_B);
            break;
        case ENC_TMP_IDX_RGB:
            fmc_enc_mode = rgb_enc_mode;
            if(dump_algo_distribution)
            {
  /*fuck*/    fprintf(f_use_yuv, "000000\n" );
  /*fuck*/    fprintf(f_use_rgb, "FFFFFF\n" );
  /*fuck*/    fprintf(f_use_gra, "000000\n" );
  /*fuck*/    fprintf(f_use_pat, "000000\n" );
  /*fuck*/    fprintf(f_use_ich, "000000\n" );
            }
            copy_block(4, pdec_R, pdec_rgb_R);
            copy_block(4, pdec_G, pdec_rgb_G);
            copy_block(4, pdec_B, pdec_rgb_B);
            break;
        case ENC_TMP_IDX_GRA:
            fmc_enc_mode = gray_enc_mode;
            if(dump_algo_distribution)
            {
  /*fuck*/    fprintf(f_use_yuv, "000000\n" );
  /*fuck*/    fprintf(f_use_rgb, "000000\n" );
  /*fuck*/    fprintf(f_use_gra, "FFFFFF\n" );
  /*fuck*/    fprintf(f_use_pat, "000000\n" );
  /*fuck*/    fprintf(f_use_ich, "000000\n" );
            }
            copy_block(4, pdec_R, pdec_gray_R);
            copy_block(4, pdec_G, pdec_gray_G);
            copy_block(4, pdec_B, pdec_gray_B);
            break;
        case ENC_TMP_IDX_PAT:
            fmc_enc_mode = pat_enc_mode;
            if(dump_algo_distribution)
            {
  /*fuck*/    fprintf(f_use_yuv, "000000\n" );
  /*fuck*/    fprintf(f_use_rgb, "000000\n" );
  /*fuck*/    fprintf(f_use_gra, "000000\n" );
  /*fuck*/    fprintf(f_use_pat, "FFFFFF\n" );
  /*fuck*/    fprintf(f_use_ich, "000000\n" );
            }
            copy_block(4, pdec_R, pdec_pat_R);
            copy_block(4, pdec_G, pdec_pat_G);
            copy_block(4, pdec_B, pdec_pat_B);
            break;
        case ENC_TMP_IDX_ICH:
            fmc_enc_mode = ich_enc_mode;
            if(dump_algo_distribution)
            {
  /*fuck*/    fprintf(f_use_yuv, "000000\n" );
  /*fuck*/    fprintf(f_use_rgb, "000000\n" );
  /*fuck*/    fprintf(f_use_gra, "000000\n" );
  /*fuck*/    fprintf(f_use_pat, "000000\n" );
  /*fuck*/    fprintf(f_use_ich, "FFFFFF\n" );
            }
            copy_block(4, pdec_R, pdec_ich_R);
            copy_block(4, pdec_G, pdec_ich_G);
            copy_block(4, pdec_B, pdec_ich_B);
            break;
    }

    write_enc_bs(fmc_enc_mode);

    return fmc_enc_mode;
}

void daz_fmc_init(int src_frame_w, int src_frame_h)
{
    int k;
    frame_h = src_frame_h;
    frame_w = src_frame_w;

    k = (frame_w % blk_w);
    if(k)
        frame_w += (blk_w - k);

    k = (frame_h % blk_h);
    if(k)
        frame_h += (blk_h - k);

    frame_blk_w = frame_w / blk_w;
    frame_blk_h = frame_h / blk_h;
    frame_blk_cnt = frame_blk_w * frame_blk_h;
}

void fmc_frame_start(FrameInfo *TgtFrame, FrameInfo *SrcFrame)
{
    TgtFrame->DisplayMode = SrcFrame->DisplayMode;
    TgtFrame->frame_w = SrcFrame->frame_w;
    TgtFrame->frame_h = SrcFrame->frame_h;

    csc_table_init();

#ifdef SAVE_RAW_FILE
    save_bstream_file_open("enc_bs.raw");
#endif

    fmc_frm_cnt++;
}

void fmc_frame_end(FrameInfo *TgtFrame, FrameInfo *SrcFrame)
{
#ifdef SAVE_RAW_FILE
    save_bstream_file_close();
#endif

}

void fmc_enc_dec_block(bool slice_start, FILE *f_use_yuv, FILE *f_use_rgb, FILE *f_use_gra, FILE *f_use_pat, FILE *f_use_ich, int x, int y, int pix_cnt, int dump_algo_distribution)
{

    fmc_enc_top(slice_start, f_use_yuv, f_use_rgb, f_use_gra, f_use_pat, f_use_ich, x, y, pix_cnt, dump_algo_distribution);
//  fmc_enc_top(slice_start                                                       );

    fmc_dec_top(slice_start);

}

void fmc_frame_enc_dec(int frame_w, int frame_h, int blk_w, int blk_h, FrameInfo *TgtFrame, FrameInfo *SrcFrame, int dump_algo_distribution)
{
	int x, y;
	int blk_x, blk_y;
	bool slice_start;

        FILE *f_use_yuv, *f_use_rgb, *f_use_gra, *f_use_pat, *f_use_ich;
        
printf("debug0\n");

  if(dump_algo_distribution) // cyk analysis activated
  {
  /*fuck*/ f_use_yuv = fopen("use_yuv.rgb","wb");
  /*fuck*/ f_use_rgb = fopen("use_rgb.rgb","wb");
  /*fuck*/ f_use_gra = fopen("use_gra.rgb","wb");
  /*fuck*/ f_use_pat = fopen("use_pat.rgb","wb");
  /*fuck*/ f_use_ich = fopen("use_ich.rgb","wb");
  }
printf("debug1\n");
    int pix_cnt=0;

    blk_y = 0;
    for (y=0; y<frame_h; y+=blk_h)
    {
        blk_x = 0;
        for (x=0; x<frame_w; x+=blk_w)
	    {

            input_block(x, y, blk_w, blk_h, Rin2x2, Gin2x2, Bin2x2, SrcFrame);

            slice_start = (x==0);
            pix_cnt=x+y*frame_h;
            fmc_enc_dec_block(slice_start, f_use_yuv, f_use_rgb, f_use_gra, f_use_pat, f_use_ich, x, y, pix_cnt, dump_algo_distribution);

            output_block(x, y, blk_w, blk_h, Rout2x2, Gout2x2, Bout2x2, TgtFrame);

            blk_x ++;
		}
		blk_y++;
    }

  if(dump_algo_distribution) // cyk analysis activated
  {
  /*fuck*/ fclose(f_use_yuv);
  /*fuck*/ fclose(f_use_rgb);
  /*fuck*/ fclose(f_use_gra);
  /*fuck*/ fclose(f_use_pat);
  /*fuck*/ fclose(f_use_ich);
  }

}


void daz_fmc_frame_top(FrameInfo *TgtFrame, FrameInfo *SrcFrame, int dump_algo_distribution)
{
    fmc_frame_start(TgtFrame, SrcFrame);
    fmc_frame_enc_dec(frame_w, frame_h, blk_w, blk_h, TgtFrame, SrcFrame, dump_algo_distribution);
    fmc_frame_end(TgtFrame, SrcFrame);
}
