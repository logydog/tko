/********************************************************
 Copyright (C) DAZZO Technology - All Rights Reserved
 Project: Dazzo_FMC_3X
 Version: Nov-2017 (v2.6 / v3 ?)
 Author : SY Kuo
********************************************************/

#include "data_type.h"
#include "main.h"
#include "daz_fmc.h"

FILE *f_bstream;

void save_bstream_file_open(int8 *fname)
{
    f_bstream = fopen(fname, "wb");
}

void save_bstream_file_close(void)
{
    fclose(f_bstream);
}

void save_bstream_file(uint8 *w_data, uint8 byte_cnt)
{
    fwrite(w_data, byte_cnt, 1, f_bstream);
}
