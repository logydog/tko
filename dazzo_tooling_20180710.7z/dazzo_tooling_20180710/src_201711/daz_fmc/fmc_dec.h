#ifndef __DAZ_FMC_DEC_H__
#define __DAZ_FMC_DEC_H__

#include "data_type.h"
#include "main.h"

void write_enc_bs(uint8 enc_mode);
void fmc_dec_top(bool slice_start);

#endif
