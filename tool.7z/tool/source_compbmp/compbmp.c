/**********************************
/*     BMP to RGB
/*
/*
/*
/*************************************/
#include <stdio.h>
#include <math.h>

int char_reverse(FILE *f_ori);
int line_reverse(FILE *f_ori);
long count_characters(FILE *);

main(argc, argv)
   int argc;
   char **argv;
{
   int width1,height1;
   int width2,height2;
   unsigned long c1,c2;
   FILE *fptri1,*fptri2,*fptro;
   FILE *f_diff_R, *f_diff_G, *f_diff_B, *f_diff_RGB, *f_diff_Y, *f_diff_U, *f_diff_V, *f_diff_YUV;
   FILE *f_log;
   int UD;
   int cont;
   int start_num;
   int num;
   char filename1[80];
   char filename2[80];
   int h,w;
   int err_cnt;
   
   if((argc!=3)&&(argc!=5))
   {printf("Error !\n USE : compbmp file1 file2 (cont start_num) \n"); 
    printf(" example1 : compbmp A.bmp B.bmp (compare A.bmp vs B.bmp file)\n");
    printf(" example2 : compbmp A B cont 0 (compare A_0000.bmp vs B_0000.bmp, A_0001.bmp vs B_0001.bmp ......file)\n\n");
    exit(0);
   }
   
   
   if(argc==5)
   {
     cont=1;
     start_num = atoi(argv[4]);
   }
   else
   {
     cont=0;
     start_num = 0;
   }
   
   
   num=start_num;
   
   
   while((cont==0 & num<=start_num) ||(cont==1))
   { 
       err_cnt=0;
   if(cont==1)
   {
       if(num<10) 
       {   sprintf(filename1,"%s_000%d.bmp",argv[1],num);
           sprintf(filename2,"%s_000%d.bmp",argv[2],num);
       }
       else if (num<100)
       { sprintf(filename1,"%s_00%d.bmp",argv[1],num);
         sprintf(filename2,"%s_00%d.bmp",argv[2],num);
       }
       else if (num<1000)
       { sprintf(filename1,"%s_0%d.bmp",argv[1],num);
         sprintf(filename2,"%s_0%d.bmp",argv[2],num);
       }
       else
       { sprintf(filename1,"%s_%d.bmp",argv[1],num);
         sprintf(filename2,"%s_%d.bmp",argv[2],num);
       }
   }
   else
   {   sprintf(filename1,"%s",argv[1],num);
       sprintf(filename2,"%s",argv[2],num);
   }
   
   if(cont==0)
   {
      if((fptri1=fopen(argv[1],"rb"))==NULL)
      { printf("  compare %s vs %s\n",argv[1],argv[2]);
        printf("      Error open input file1 %s\n\n",argv[1]);
        exit(0);}
      if((fptri2=fopen(argv[2],"rb"))==NULL)
      { printf("  compare %s vs %s\n",argv[1],argv[2]);
        printf("      Error open input file2 %s\n\n",argv[2]);
        exit(0);}
   }
   else
   {
      if((fptri1=fopen(filename1,"rb"))==NULL)
      {  if((fptri2=fopen(filename2,"rb"))!=NULL)
         {    printf("  compare %s vs %s\n",filename1,filename2);
              printf("      Error open input file1 : %s\n\n",filename1);
              exit(0) ;
         }
         else
         {   printf("\n");
             exit(0) ;
         }
   
      }
   
      if((fptri2=fopen(filename2,"rb"))==NULL)
      {  if((fptri1=fopen(filename1,"rb"))!=NULL)
         {    printf("  compare %s vs %s\n",filename1,filename2);
              printf("      Error open input file2 : %s\n\n",filename2);
              exit(0);
         }
         else
         {   printf("\n");
             exit(0) ;
         }
      }
   
   
   
   
   
   
   }
   
   
   fseek(fptri1,18,SEEK_SET);
   fread(&width1,sizeof(char),4,fptri1);
   fread(&height1,sizeof(char),4,fptri1);
   
   fseek(fptri2,18,SEEK_SET);
   fread(&width2,sizeof(char),4,fptri2);
   fread(&height2,sizeof(char),4,fptri2);
   
   
   if((width1!=width2) || (height1!=height2))
   { printf("Error : width or height error\n");
     exit(0);}
   
   printf("  compare %s vs %s\n",filename1,filename2);
   
   fseek(fptri1,54,SEEK_SET);
   fseek(fptri2,54,SEEK_SET);
   c1=0;
   c2=0;
   int r0, r1, g0, g1, b0, b1;
   int r_diff, g_diff, b_diff;
   
   
   f_log   = fopen("all.log", "wb");
   char cmd[1025];
   char arr_diff_R[]  ="diff_R.rgb"  ;
   char arr_diff_G[]  ="diff_G.rgb"  ;
   char arr_diff_B[]  ="diff_B.rgb"  ;
// char arr_diff_RGB[]="diff_RGB.rgb";
   f_diff_R   = fopen(arr_diff_R  ,"wb");
   f_diff_G   = fopen(arr_diff_G  ,"wb");
   f_diff_B   = fopen(arr_diff_B  ,"wb");
// f_diff_RGB = fopen(arr_diff_RGB,"wb");
   
   
   
   for (h=0;h<height1;h++)
   {
       for (w=0;w<width1;w++)
       {  
          fread(&c1,sizeof(char),3,fptri1);
          fread(&c2,sizeof(char),3,fptri2);
          r0 = (c1&0xFF0000)>>16;
          r1 = (c2&0xFF0000)>>16;

          g0 = (c1&0x00FF00)>>8;
          g1 = (c2&0x00FF00)>>8;

          b0 = (c1&0x0000FF)>>0;
          b1 = (c2&0x0000FF)>>0;

          r_diff=abs(r0-r1);
          g_diff=abs(g0-g1);
          b_diff=abs(b0-b1);


          if(c1!=c2)
          { 
            fprintf(f_log, "(y,x)=%04d,%04d : %06x != %06x, r_diff=%02d(%02d%), g_diff=%02d(%02d%), b_diff=%02d(%02d%)\n", height1-h-1, w, c1, c2, 
                            r_diff, (int)round(100*(float)r_diff/r0), 
                            g_diff, (int)round(100*(float)g_diff/g0), 
                            b_diff, (int)round(100*(float)b_diff/b0)
                   );
//          printf("Error : data compare error : %x vs %x (w=%d, h=%d)\n",c1,c2,w,height1-h-1);
//          err_cnt = err_cnt+1;
//          if(err_cnt==10)
//          { h = height1;
//            w = width1;
//          }
          }

if((height1-h-1==1934) &&  (w==178))
{
printf("y=%04d, x=%04d, r_diff=%02d\n", height1-h-1, w, r_diff);
getchar();
}



int enhance_factor=16;


          int r_diffv = enhance_factor*r_diff;
          int g_diffv = enhance_factor*g_diff;
          int b_diffv = enhance_factor*b_diff;

          r_diffv = r_diffv>255 ? 255 : r_diffv;
          g_diffv = g_diffv>255 ? 255 : g_diffv;
          b_diffv = b_diffv>255 ? 255 : b_diffv;

if((height1-h-1==1934) &&  (w==178))
{
printf("r_diffv=%d\n", r_diffv);
getchar();
}
          if((h==height1-1) && (w==width1-1)) 
          {
             if(r0==r1)fprintf(f_diff_R  , "000000"); else fprintf(f_diff_R  , "%02x0000"     , r_diffv);
             if(g0==g1)fprintf(f_diff_G  , "000000"); else fprintf(f_diff_G  , "00%02x00"     , g_diffv);
             if(b0==b1)fprintf(f_diff_B  , "000000"); else fprintf(f_diff_B  , "0000%02x"     , b_diffv);
//           if(c1==c2)fprintf(f_diff_RGB, "000000"); else fprintf(f_diff_RGB, "%02x%02x%02x" , r_diffv, g_diffv, b_diffv);
          }
          else
          {
             if(r0==r1)fprintf(f_diff_R  , "000000\n"); else fprintf(f_diff_R  , "%02x0000\n"     , r_diffv);
             if(g0==g1)fprintf(f_diff_G  , "000000\n"); else fprintf(f_diff_G  , "00%02x00\n"     , g_diffv);
             if(b0==b1)fprintf(f_diff_B  , "000000\n"); else fprintf(f_diff_B  , "0000%02x\n"     , b_diffv);
//           if(c1==c2)fprintf(f_diff_RGB, "000000\n"); else fprintf(f_diff_RGB, "%02x%02x%02x\n" , r_diffv, g_diffv, b_diffv);
if((height1-h-1==1934) &&  (w==178))
{
printf("h=%d, r_diffv=%d\n", h, r_diffv);
getchar();
}
          }
       }
   }
   
   fclose(f_log);
   fclose(f_diff_R);
   fclose(f_diff_G);
   fclose(f_diff_B);
// fclose(f_diff_RGB);
getchar();
   
   f_diff_R   = fopen(arr_diff_R  ,"rb");
   f_diff_G   = fopen(arr_diff_G  ,"rb");
   f_diff_B   = fopen(arr_diff_B  ,"rb");
// f_diff_RGB = fopen(arr_diff_RGB,"rb");
   
// line_reverse(f_diff_R); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diff_R);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diff_R, arr_diff_R, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diff_R, arr_diff_R, width1, height1);
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diff_R, arr_diff_R, width1, height1);
   system(cmd);
   
// line_reverse(f_diff_G); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diff_G);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diff_G, arr_diff_G, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diff_G, arr_diff_G, width1, height1);
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diff_G, arr_diff_G, width1, height1);
   system(cmd);
   
// line_reverse(f_diff_B); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diff_B);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diff_B, arr_diff_B, width1, height1);
// sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d UD", arr_diff_B, arr_diff_B, width1, height1);
   sprintf(cmd, "tool/source_rgb2bmp/rgb2bmp_ud_cont.exe %s %s %d %d   ", arr_diff_B, arr_diff_B, width1, height1);
   system(cmd);
   
// line_reverse(f_diff_RGB); // reversed file : line_reverse.txt
// rename("line_reverse.txt", arr_diff_RGB);
// sprintf(cmd, "tool/rgb2bmp_arg3 %s %s %d %d", arr_diff_RGB, arr_diff_RGB, width1, height1);
// system(cmd);
   
   fclose(fptri1);
   fclose(fptri2);
   
   num++;
   }
}
 
 
int line_reverse(FILE *f_ori)
{

     long cnt;
     int  cnt_byte=0;
     char ch;
     char R_lsb, R_msb, G_lsb, G_msb, B_lsb, B_msb;
     FILE *f_tmp = fopen("line_reverse.txt", "w");
     cnt = count_characters(f_ori);

        /*
            Make the pointer fp1 to point at the
            last character of the file
        */
        fseek(f_ori, -1L, 2);
        printf("Number of characters to be copied %d\n", ftell(f_ori));

        while (cnt)
        {
                 if(cnt_byte==0) B_lsb = fgetc(f_ori);
            else if(cnt_byte==1) B_msb = fgetc(f_ori);
            else if(cnt_byte==2) G_lsb = fgetc(f_ori);
            else if(cnt_byte==3) G_msb = fgetc(f_ori);
            else if(cnt_byte==4) R_lsb = fgetc(f_ori);
            else if(cnt_byte==5) R_msb = fgetc(f_ori);
            else if(cnt_byte==6) ch    = fgetc(f_ori);

            if(cnt_byte==5) fprintf(f_tmp, "%c%c%c%c%c%c\n", R_msb, R_lsb, G_msb, G_lsb, B_msb, B_lsb);

            if(cnt_byte==6) cnt_byte=0; // when cnt_byte==6, it is new line symbol
            else            cnt_byte++;

            fseek(f_ori, -2L, 1); // shifts the pointer to the previous character
            cnt--;
        }

     printf("\n**File copied successfully in reverse order**\n");
     fclose(f_tmp);
}

 
int char_reverse(FILE *f_ori)
{

     long cnt;
     char ch;
     FILE *f_tmp = fopen("File_2.txt", "w");
     cnt = count_characters(f_ori);

        /*
            Make the pointer fp1 to point at the
            last character of the file
        */
        fseek(f_ori, -1L, 2);
        printf("Number of characters to be copied %d\n", ftell(f_ori));

        while (cnt)
        {
            ch = fgetc(f_ori);
            fputc(ch, f_tmp);
            fseek(f_ori, -2L, 1); // shifts the pointer to the previous character
            cnt--;
        }
        printf("\n**File copied successfully in reverse order**\n");
     fclose(f_tmp);
}


/*
    Count the total number of characters in the file
    that *f points to
*/
long count_characters(FILE *f)
{
    fseek(f, -1L, 2);
    /*
        returns the position of the 
        last element of the file
    */
    long last_pos = ftell(f);
    last_pos++;
    return last_pos;
}
